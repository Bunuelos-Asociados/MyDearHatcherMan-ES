


    ####
    ##                                      ##
    ##  F95Zone Paloslios Renpy Translator  ##
    ##     https://ko-fi.com/paloslios      ##
    ##                                      ##
    ####



# game/days1.rpy:3
translate Paloslios day1_ec8d218b:

    # "My body is aching… It feels like someone is on top of me…"
    "Me duele el cuerpo... Se siente como si alguien estuviera encima de mí..."

# game/days1.rpy:9
translate Paloslios day1_eacca17b:

    # "Oh god."
    "Oh dios."

# game/days1.rpy:9
translate Paloslios day1_2b06cf9f:

    # "How long did I sleep for? It seemed way too bright to be early in the morning."
    "¿Cuánto tiempo dormí? Parecía demasiado brillante para ser temprano en la mañana."

# game/days1.rpy:9
translate Paloslios day1_d82533b2:

    # "I guess it must’ve been incredibly late when I slept."
    "Supongo que debió ser increíblemente tarde cuando dormí."

# game/days1.rpy:9
translate Paloslios day1_ce617998:

    # "…"
    "…"

# game/days1.rpy:9
translate Paloslios day1_62eb7d38:

    # "Last night…"
    "Anoche…"

# game/days1.rpy:9
translate Paloslios day1_4a17b8f6:

    # "Memories started flooding back to the encounter I had with that stranger in the woods."
    "Los recuerdos comenzaron a inundar el encuentro que tuve con ese extraño en el bosque."

# game/days1.rpy:9
translate Paloslios day1_cbb35cba:

    # "I feel some sort of mix of comforting jitters sinking in."
    "Siento una especie de mezcla de nerviosismo reconfortante."

# game/days1.rpy:9
translate Paloslios day1_61781469:

    # "I had only moved in a few weeks ago..."
    "Me había mudado hace sólo unas semanas..."

# game/days1.rpy:9
translate Paloslios day1_d4bbcded:

    # "but now knowing that he has been in the woods the entire time I have been exploring them, it was a little uneasy to process."
    "pero ahora sabiendo que él ha estado en el bosque todo el tiempo que los estuve explorando, fue un poco incómodo procesarlo."

# game/days1.rpy:9
translate Paloslios day1_0834b48f:

    # "It’s like a part of my privacy has been exposed."
    "Es como si una parte de mi privacidad hubiera quedado expuesta."

# game/days1.rpy:9
translate Paloslios day1_68550445:

    # "To be fair, I do feel a little silly thinking that."
    "Para ser justos, me siento un poco tonto al pensar eso."

# game/days1.rpy:9
translate Paloslios day1_c7a9328d:

    # "I didn’t own the woods. If anything, I invaded his privacy by going off my usual path."
    "No era dueño del bosque. En todo caso, invadí su privacidad al desviarme de mi camino habitual."

# game/days1.rpy:9
translate Paloslios day1_ab6502c8:

    # "Although I haven’t lived here for very long, I am surprised I haven’t heard about a man living in the forest."
    "Aunque no he vivido aquí por mucho tiempo, me sorprende no haber oído hablar de un hombre que viva en el bosque."

# game/days1.rpy:9
translate Paloslios day1_067c50cf:

    # "Then again, it's not like I am really chatty with the neighbors to inform me about it."
    "Por otra parte, no es que realmente hable con los vecinos para informarme al respecto."

# game/days1.rpy:9
translate Paloslios day1_44a5e2d6:

    # "Was I thinking too much about this? Am I being insensitive?"
    "¿Estaba pensando demasiado en esto? ¿Estoy siendo insensible?"

# game/days1.rpy:9
translate Paloslios day1_c3089147:

    # "Should I be feeling like I wanna run into him again?"
    "¿Debería sentir que quiero toparme con él otra vez?"

# game/days1.rpy:9
translate Paloslios day1_ce617998_1:

    # "…"
    "…"

# game/days1.rpy:45
translate Paloslios day1_481e2f17:

    # u "I didn’t ask for his name…"
    u "No pregunté su nombre..."

# game/days1.rpy:49
translate Paloslios day1_593807b6:

    # "Before doing anything, I wanted to catch up on what has been happening."
    "Antes de hacer nada, quería ponerme al día con lo que ha estado sucediendo."

# game/days1.rpy:50
translate Paloslios day1_3fa35039:

    # "I only see one message. It was an unknown number…"
    "Solo veo un mensaje. Era un número desconocido..."

# game/days1.rpy:54
translate Paloslios day1_0aa47e6d:

    # e "{i}'Hey.'{/i}"
    e "{i}'Oye.'{/i}"

# game/days1.rpy:55
translate Paloslios day1_8a738886:

    # e "{i}'Do you know the chapter we are studying for English?'{/i}"
    e "{i}'¿Conoces el capítulo que estamos estudiando para inglés?'{/i}"

# game/days1.rpy:57
translate Paloslios day1_07f905e4:

    # e "{i}'This is Erika btw.'{/i}"
    e "{i}'Esta es Erika por cierto.'{/i}"

# game/days1.rpy:58
translate Paloslios day1_59ca6a00:

    # u "Oh."
    u "Ah."

# game/days1.rpy:59
translate Paloslios day1_943d64f4:

    # "Erika, I remember her. She is part of my class."
    "Erika, la recuerdo. Ella es parte de mi clase."

# game/days1.rpy:59
translate Paloslios day1_39889d5b:

    # "I could recall we exchanged phone numbers because our professor recommended it."
    "Recuerdo que intercambiamos números de teléfono porque nuestro profesor lo recomendó."

# game/days1.rpy:59
translate Paloslios day1_ccd69e49:

    # "She was the one who approached me."
    "Ella fue quien se acercó a mí."

# game/days1.rpy:59
translate Paloslios day1_40ec35e3:

    # "Didn’t talk to her a lot. She didn’t seem like the type, but would casually answer questions in class."
    "No hablé mucho con ella. Ella no parecía ese tipo de personas, pero respondía preguntas casualmente en clase."

# game/days1.rpy:59
translate Paloslios day1_a18ea5ef:

    # "One thing that stuck out, however, was that she had an incredible style."
    "Sin embargo, algo que destacó fue que tenía un estilo increíble."

# game/days1.rpy:59
translate Paloslios day1_98c3f1c9:

    # "She had an eye for colors and patterns from what I could tell."
    "Por lo que pude ver, tenía buen ojo para los colores y patrones."

# game/days1.rpy:59
translate Paloslios day1_124a7ee5:

    # "It was surprising that she wasn’t taking a fashion course but instead, an interior design course."
    "Fue sorprendente que no estuviera tomando un curso de moda sino uno de diseño de interiores."

# game/days1.rpy:59
translate Paloslios day1_ff750583:

    # "Erika was cool and seemed like she had her shit together, unlike me."
    "Erika era genial y parecía que tenía todo bajo control, a diferencia de mí."

# game/days1.rpy:78
translate Paloslios day1_9eeefdcb:

    # u "{i}'Chapter 4, I believe.'{/i}"
    u "{i}'Capítulo 4, creo.'{/i}"

# game/days1.rpy:80
translate Paloslios day1_5c1ea4ed:

    # "With a groan, I forced myself up from the comfort of my bed."
    "Con un gemido, me obligué a levantarme de la comodidad de mi cama."

# game/days1.rpy:80
translate Paloslios day1_6d1da93c:

    # "To be honest, it seemed better to do something than be slacking around in my sheets."
    "Para ser honesto, parecía mejor hacer algo que estar holgazaneando entre las sábanas."

# game/days1.rpy:80
translate Paloslios day1_2588ccab:

    # "This has been the first time I have been motivated to do anything in a while."
    "Esta ha sido la primera vez en mucho tiempo que me siento motivado para hacer algo."

# game/days1.rpy:80
translate Paloslios day1_ce617998_2:

    # "…"
    "…"

# game/days1.rpy:80
translate Paloslios day1_ca1019c3:

    # "That’s kinda sad."
    "Eso es un poco triste."

# game/days1.rpy:97
translate Paloslios day1_8c30ae22:

    # "{i}Ding~!{/i}"
    "{i}¡Ding~!{/i}"

# game/days1.rpy:99
translate Paloslios day1_5ea415b0:

    # e "{i}'Thanks… :)??'{/i}"
    e "{i}'Gracias... :)??'{/i}"

# game/days1.rpy:100
translate Paloslios day1_0a2707f9:

    # e "{i}'Sorry. Can you tell I don’t text often?'{/i}"
    e "{i}'Lo siento. ¿Te das cuenta de que no envío mensajes de texto con frecuencia?'{/i}"

# game/days1.rpy:102
translate Paloslios day1_57b2d904:

    # "That made me smile, just a tad."
    "Eso me hizo sonreír, sólo un poco."

# game/days1.rpy:106
translate Paloslios day1_7c483b53:

    # u "I can check that later."
    u "Puedo comprobarlo más tarde."

# game/days1.rpy:110
translate Paloslios day1_5c1ea4ed_1:

    # "With a groan, I forced myself up from the comfort of my bed."
    "Con un gemido, me obligué a levantarme de la comodidad de mi cama."

# game/days1.rpy:111
translate Paloslios day1_6d1da93c_1:

    # "To be honest, it seemed better to do something than be slacking around in my sheets."
    "Para ser honesto, parecía mejor hacer algo que estar holgazaneando entre las sábanas."

# game/days1.rpy:112
translate Paloslios day1_2588ccab_1:

    # "This has been the first time I have been motivated to do anything in a while."
    "Esta ha sido la primera vez en mucho tiempo que me siento motivado para hacer algo."

# game/days1.rpy:113
translate Paloslios day1_ce617998_3:

    # "…"
    "…"

# game/days1.rpy:114
translate Paloslios day1_ca1019c3_1:

    # "That’s kinda sad."
    "Eso es un poco triste."

# game/days1.rpy:120
translate Paloslios day1_41859944:

    # "It seems like a stupid decision to go back to the forest just to thank some stranger."
    "Parece una decisión estúpida volver al bosque sólo para agradecer a un extraño."

# game/days1.rpy:120
translate Paloslios day1_ac13e4da:

    # "Dangerous, some might say."
    "Peligroso, dirían algunos."

# game/days1.rpy:120
translate Paloslios day1_458374f1:

    # "I mean, at least the sun was still out, so it wouldn’t be as bad as staying in the woods at night, right?"
    "Quiero decir, al menos todavía había sol, así que no sería tan malo como quedarse en el bosque por la noche, ¿verdad?"

# game/days1.rpy:120
translate Paloslios day1_b5e8e567:

    # "I stuffed my phone into my pocket and prepared to get ready."
    "Metí mi teléfono en mi bolsillo y me preparé para prepararme."

# game/days1.rpy:120
translate Paloslios day1_aec00c2f:

    # "I walked back into the familiar path. The cool air was sharp as ever, I could feel it nipping at the tip of my nose."
    "Regresé al camino familiar. El aire fresco era tan intenso como siempre, podía sentirlo mordisqueando la punta de mi nariz."

# game/days1.rpy:120
translate Paloslios day1_6f1f21a7:

    # "I tried to recall the path I took that initially got me lost yesterday."
    "Intenté recordar el camino que tomé y que inicialmente me hizo perder ayer."

# game/days1.rpy:120
translate Paloslios day1_e371f0fa:

    # "It didn’t take long for me to fall back into a daze, feeling sensely strayed."
    "No pasó mucho tiempo antes de que volviera a quedar aturdido, sintiéndome extraviado."

# game/days1.rpy:138
translate Paloslios day1_a88a8af0:

    # u "Alright, [name]. Just thank him and you can go on your merry way and get some shut eye. Simple as that."
    u "Muy bien, [name]. Simplemente agradécele y podrás seguir tu camino feliz y cerrar los ojos. Así de simple."

# game/days1.rpy:140
translate Paloslios day1_95394350:

    # "Thoughts started to speculate in my head the more I paced around in a frantic circle."
    "Los pensamientos comenzaron a especular en mi cabeza cuanto más caminaba en un círculo frenético."

# game/days1.rpy:140
translate Paloslios day1_0de01e48:

    # "Why am I being stupid?"
    "¿Por qué estoy siendo estúpido?"

# game/days1.rpy:140
translate Paloslios day1_46728185:

    # "He should be here, right?"
    "Él debería estar aquí, ¿verdad?"

# game/days1.rpy:140
translate Paloslios day1_2cd27623:

    # "Why did I think this was a good idea?"
    "¿Por qué pensé que era una buena idea?"

# game/days1.rpy:140
translate Paloslios day1_69fc2c97:

    # "It would be nice to have someone to share the woods with."
    "Sería bueno tener alguien con quien compartir el bosque."

# game/days1.rpy:140
translate Paloslios day1_ce617998_4:

    # "…"
    "…"

# game/days1.rpy:140
translate Paloslios day1_19d574c2:

    # "What if he hurts me? Like {i}he{/i} did-"
    "¿Y si me lastima? Como lo hizo {i}él{/i}-"

# game/days1.rpy:157
translate Paloslios day1_1892b8dc:

    # a "Oh. You’re here again."
    a "Ah. Estás aquí otra vez."

# game/days1.rpy:159
translate Paloslios day1_66ec9fd9:

    # "Oh thank god!"
    "¡Ay gracias a Dios!"

# game/days1.rpy:161
translate Paloslios day1_42b92a4d:

    # "It might’ve been my desperation, but the sound of his voice took off a huge wave of relief."
    "Podría haber sido mi desesperación, pero el sonido de su voz provocó una gran ola de alivio."

# game/days1.rpy:162
translate Paloslios day1_9d5f34ea:

    # "I turned around, too eagerly, seeing a smug expression on his face. He made me… happy, in a way?"
    "Me di vuelta con demasiada impaciencia y vi una expresión engreída en su rostro. Él me hizo... ¿feliz, en cierto modo?"

# game/days1.rpy:166
translate Paloslios day1_0018420b:

    # a "You seem to get easily lost. What if I wasn’t here to help ya out, {i}doe-eyes?{/i}"
    a "Parece que te pierdes fácilmente. ¿Qué pasaría si no estuviera aquí para ayudarte, {i}ojos de cierva?{/i}"

# game/days1.rpy:168
translate Paloslios day1_fbe6c79a:

    # "His comment made me play with the hem of my sweater, I could feel my cheeks starting to burn."
    "Su comentario me hizo jugar con el dobladillo de mi suéter, podía sentir mis mejillas empezando a arder."

# game/days1.rpy:170
translate Paloslios day1_be7f3b65:

    # "Hopefully he didn’t notice."
    "Ojalá no se haya dado cuenta."

# game/days1.rpy:172
translate Paloslios day1_0fcb3cd4:

    # u "W-Well, I actually came to see you…"
    u "B-Bueno, en realidad vine a verte..."

# game/days1.rpy:174
translate Paloslios day1_5d9574ed:

    # "Why did I say it like that?"
    "¿Por qué lo dije así?"

# game/days1.rpy:177
translate Paloslios day1_b201c077:

    # u "I wanted to thank you. Properly I mean-"
    u "Quería agradecerte. Correctamente quiero decir-"

# game/days1.rpy:179
translate Paloslios day1_3042ca84:

    # u "I know I already did last night but I might have come off as crass, and I still feel bad about that whole ordeal."
    u "Sé que ya lo hice anoche, pero puede que haya parecido grosero y todavía me siento mal por toda esa terrible experiencia."

# game/days1.rpy:181
translate Paloslios day1_348f3dc5:

    # "I started to ramble at this point. I need to get this over with before I come off as hysterical."
    "Empecé a divagar en este punto. Necesito terminar con esto antes de ponerme histérico."

# game/days1.rpy:183
translate Paloslios day1_01aed566:

    # u "So Um… Thank you… uh-"
    u "Entonces, um… gracias… uh-"

# game/days1.rpy:187
translate Paloslios day1_0410eb62:

    # a "Alan."
    a "Alan."

# game/days1.rpy:189
translate Paloslios day1_e7c5bf55:

    # u "I’m sorry?"
    u "¿Lo lamento?"

# game/days1.rpy:195
translate Paloslios day1_05a4dbb6:

    # a "My name is Alan. Might as well get it out of the way."
    a "Mi nombre es Alan. También podría quitarlo del camino."

# game/days1.rpy:197
translate Paloslios day1_e4e8224d:

    # u "Oh. Well, thanks for helping me out… Alan."
    u "Oh. Bueno, gracias por ayudarme… Alan."

# game/days1.rpy:199
translate Paloslios day1_0a00ee2f:

    # "I gave his name a try. It came out softer than how I usually speak."
    "Probé su nombre. Salió más suave de lo que suelo hablar."

# game/days1.rpy:203
translate Paloslios day1_e473e856:

    # "I noticed him begin to smile, avoiding eye contact."
    "Lo noté comenzar a sonreír, evitando el contacto visual."

# game/days1.rpy:205
translate Paloslios day1_d57d37d1:

    # "I was beginning to feel the silence between us start to grow."
    "Estaba empezando a sentir que el silencio entre nosotros comenzaba a crecer."

# game/days1.rpy:209
translate Paloslios day1_fa74080d:

    # a "No problem. Besides, it is really sweet of you to come back just to tell me that."
    a "Ningún problema. Además, es muy amable de tu parte volver sólo para decirme eso."

# game/days1.rpy:211
translate Paloslios day1_8e5f6bdf:

    # "Oh. He was flirting."
    "Oh. Estaba coqueteando."

# game/days1.rpy:215
translate Paloslios day1_b49c3e16:

    # "It was kinda cute how he became so bashful then flirtatious so suddenly."
    "Fue un poco lindo cómo se volvió tan tímido y luego coqueto tan repentinamente."

# game/days1.rpy:216
translate Paloslios day1_6193702b:

    # "I couldn't help but to smile back at him."
    "No pude evitar devolverle la sonrisa."

# game/days1.rpy:218
translate Paloslios day1_296abda5:

    # "Any kind of attention like that makes me feel weary."
    "Cualquier tipo de atención como esa me hace sentir cansado."

# game/days1.rpy:219
translate Paloslios day1_e421da50:

    # "I promised myself I wouldn’t get into a new relationship. Not until I feel ready…"
    "Me prometí a mí mismo que no entablaría una nueva relación. No hasta que me sienta listo..."

# game/days1.rpy:220
translate Paloslios day1_b2adb411:

    # "I only replied back with a nervous laugh."
    "Solo respondí con una risa nerviosa."

# game/days1.rpy:224
translate Paloslios day1_277b2634:

    # "We began to start a whole different conversation from there."
    "A partir de ahí comenzamos a iniciar una conversación completamente diferente."

# game/days1.rpy:224
translate Paloslios day1_7fe21387:

    # "At first, it was just regular small talk. Most of it is about me, of course."
    "Al principio, fue sólo una pequeña charla normal. La mayor parte es sobre mí, por supuesto."

# game/days1.rpy:224
translate Paloslios day1_f12b0d1f:

    # "I told him what I did for a living and what I was currently studying."
    "Le conté a qué me dedicaba y qué estaba estudiando actualmente."

# game/days1.rpy:224
translate Paloslios day1_1c08af1e:

    # "He seemed to be a good listener, or at least I think he was trying to be."
    "Parecía saber escuchar, o al menos creo que intentaba serlo."

# game/days1.rpy:224
translate Paloslios day1_b1ed178c:

    # "It became evident that I kinda ran out of things to talk about."
    "Se hizo evidente que me quedé sin cosas de qué hablar."

# game/days1.rpy:224
translate Paloslios day1_490ca072:

    # "It was only fair to ask about him, right? I don’t wanna make it seem that I only liked talking about myself."
    "Era justo preguntar por él, ¿verdad? No quiero que parezca que sólo me gustaba hablar de mí."

# game/days1.rpy:239
translate Paloslios day1_f3fc80d2:

    # u "Not to sound rude or anything but…"
    u "No quiero sonar grosero ni nada, pero..."

# game/days1.rpy:241
translate Paloslios day1_32fb53c2:

    # a "Hm?"
    a "¿Mmm?"

# game/days1.rpy:243
translate Paloslios day1_04fdc7ff:

    # u "I’m a little… Curious about your whole… Thing here."
    u "Tengo un poco... de curiosidad por todo vuestro... asunto aquí."

# game/days1.rpy:245
translate Paloslios day1_7891e355:

    # a "Oh."
    a "Ah."

# game/days1.rpy:247
translate Paloslios day1_5790ad1e:

    # u "I know I just moved in, and it’s none of my business but why do you live all the way out here?"
    u "Sé que me acabo de mudar y no es de mi incumbencia, pero ¿por qué vives hasta aquí?"

# game/days1.rpy:248
translate Paloslios day1_79c6bf4a:

    # u "How come no one has ever told me about you?"
    u "¿Cómo es que nadie me ha hablado nunca de ti?"

# game/days1.rpy:250
translate Paloslios day1_cd373e13:

    # "He seemed to give some thought to my questions. He simply gave me a shrug."
    "Pareció pensar un poco en mis preguntas. Él simplemente me encogió de hombros."

# game/days1.rpy:254
translate Paloslios day1_db61b35b:

    # a "Dunno. I always figured I lived… better? On my own, I guess? At least, that’s what I think…"
    a "No sé. Siempre pensé que vivía… ¿mejor? Por mi cuenta, supongo. Al menos eso es lo que pienso..."

# game/days1.rpy:256
translate Paloslios day1_2aaec0e0:

    # "So maybe he was a bit of a hermit? I totally don’t mean to judge him."
    "Entonces, ¿tal vez era un poco ermitaño? No es mi intención juzgarlo en absoluto."

# game/days1.rpy:256
translate Paloslios day1_e0207ef3:

    # "In a way, I kinda do feel for him not wanting to interact with others. He was just…"
    "En cierto modo, siento que él no quiera interactuar con los demás. Él solo era…"

# game/days1.rpy:256
translate Paloslios day1_e98bf3f0:

    # "A little more on the opposite end."
    "Un poco más en el extremo opuesto."

# game/days1.rpy:256
translate Paloslios day1_a21ad544:

    # "Maybe he thinks I’m the weird one for wanting to interact with him."
    "Tal vez piense que soy la rara por querer interactuar con él."

# game/days1.rpy:256
translate Paloslios day1_5b66b921:

    # "It’s not everyday someone just comes back to thank you for helping them out of the woods."
    "No todos los días alguien regresa para agradecerle por ayudarlo a salir del peligro."

# game/days1.rpy:256
translate Paloslios day1_0c6061af:

    # "For a loner, he sure was easy to talk to."
    "Para ser un hombre solitario, era fácil hablar con él."

# game/days1.rpy:256
translate Paloslios day1_befc4115:

    # "He was the one to first start a conversation better than I ever could."
    "Él fue el primero en iniciar una conversación mejor que yo."

# game/days1.rpy:275
translate Paloslios day1_3a7fdc34:

    # a "H-Hey."
    a "O-oye."

# game/days1.rpy:277
translate Paloslios day1_d7c31a20:

    # "He snapped me out of it, like he knew I was about to get lost in my thoughts."
    "Me sacó de ahí, como si supiera que estaba a punto de perderme en mis pensamientos."

# game/days1.rpy:281
translate Paloslios day1_9601c275:

    # a "Wanna go check something out? I think you might like it."
    a "¿Quieres ir a ver algo? Creo que te puede gustar."

# game/days1.rpy:283
translate Paloslios day1_3d5a0df9:

    # "I blinked. The way he worded it sounded… Very vague."
    "Parpadeé. La forma en que lo expresó sonó... Muy vaga."

# game/days1.rpy:285
translate Paloslios day1_23c8634b:

    # u "I dunno. It depends. Are ya gonna trick me and plan my murder? Sounds very fishy of you, Alan."
    u "No se. Eso depende. ¿Vas a engañarme y planear mi asesinato? Suena muy sospechoso de tu parte, Alan."

# game/days1.rpy:289
translate Paloslios day1_74cbe66a:

    # "I joked, and he seemed to get a good laugh out of it."
    "Bromeé y él pareció reírse mucho."

# game/days1.rpy:290
translate Paloslios day1_de783f2e:

    # "It was not a very good joke, but it felt good to just laugh with someone. Maybe I needed this…"
    "No fue una broma muy buena, pero se sentía bien simplemente reír con alguien. Tal vez necesitaba esto..."

# game/days1.rpy:291
translate Paloslios day1_f713571d:

    # "I just needed to talk to someone."
    "Sólo necesitaba hablar con alguien."

# game/days1.rpy:293
translate Paloslios day1_e3795b0f:

    # u "I mean… Now you got me curious. Might as well, right?"
    u "Quiero decir… Ahora me tienes curiosidad. Podría también, ¿verdad?"

# game/days1.rpy:297
translate Paloslios day1_ef85c08c:

    # a "Good."
    a "Bien."

# game/days1.rpy:299
translate Paloslios day1_82910b24:

    # "He seemed extremely pleased that I agreed. He took hold of my shoulder to guide me to the direction he planned to take me."
    "Parecía muy contento de que yo aceptara. Me agarró del hombro para guiarme hacia la dirección que planeaba llevarme."

# game/days1.rpy:299
translate Paloslios day1_d60267bc:

    # "We both took our time walking through the forest, having a whole casual conversation to make it up for it."
    "Ambos nos tomamos nuestro tiempo para caminar por el bosque, teniendo toda una conversación informal para compensarlo."

# game/days1.rpy:299
translate Paloslios day1_bf4d825c:

    # "It felt like being reunited with an old friend, and trying to catch up on your lives together. It was nice."
    "Fue como reunirse con un viejo amigo y tratar de ponerse al día con sus vidas juntos. Fue agradable."

# game/days1.rpy:299
translate Paloslios day1_51aab373:

    # "I began to share some stuff to Alan that I haven’t been able to talk about for a while."
    "Comencé a compartir algunas cosas con Alan de las que no había podido hablar por un tiempo."

# game/days1.rpy:299
translate Paloslios day1_f8840147:

    # "In return, he told me little things about himself."
    "A cambio, me contó pequeñas cosas sobre sí mismo."

# game/days1.rpy:317
translate Paloslios day1_3bb98830:

    # "I took notice of him trying to crush crunchy leaves under his shoes, sometimes getting bummed out if one didn’t crunch."
    "Me di cuenta de que intentaba aplastar hojas crujientes debajo de sus zapatos, y a veces se desanimaba si una no las crujía."

# game/days1.rpy:319
translate Paloslios day1_ec7dadd5:

    # "It was kinda cute."
    "Fue algo lindo."

# game/days1.rpy:319
translate Paloslios day1_f24f747a:

    # "I noticed his skin looked slightly more sickly pale. Tiny, but still noticeable scratches across his cheeks."
    "Noté que su piel parecía un poco más pálida y enfermiza. Pequeños, pero aún visibles rasguños en sus mejillas."

# game/days1.rpy:319
translate Paloslios day1_5756762e:

    # "And his eyes bore dark circles. It almost looked like he was about to collapse but he looked so gentle."
    "Y sus ojos tenían ojeras. Casi parecía que estaba a punto de colapsar, pero se veía muy gentil."

# game/days1.rpy:319
translate Paloslios day1_2eb85e82:

    # "He seemed to have noticed that I was looking at him."
    "Parecía haber notado que lo estaba mirando."

# game/days1.rpy:319
translate Paloslios day1_d3075aa0:

    # "Oh no. I got caught."
    "Oh, no. Me atraparon."

# game/days1.rpy:319
translate Paloslios day1_8ed6cccb:

    # "I ducked my head, scratching the side of my cheek."
    "Agaché la cabeza y me rasqué un costado de la mejilla."

# game/days1.rpy:319
translate Paloslios day1_186662b6:

    # "Before I could come up with an excuse that I totally wasn’t staring at him, Alan pushed my head down, getting onto my knees, rather painfully."
    "Antes de que pudiera encontrar una excusa de que no lo estaba mirando, Alan empujó mi cabeza hacia abajo y se puso de rodillas, con bastante dolor."

# game/days1.rpy:336
translate Paloslios day1_54c383f8:

    # u "What the h-"
    u "¿Qué diablos?"

# game/days1.rpy:338
translate Paloslios day1_f55d93b2:

    # a "Shh!"
    a "¡Shh!"

# game/days1.rpy:345
translate Paloslios day1_febd798a:

    # "Alan crouched down beside me, carefully moving closer to what seemed like a small stream,"
    "Alan se agachó a mi lado y se acercó con cuidado a lo que parecía un pequeño arroyo."

# game/days1.rpy:345
translate Paloslios day1_9ce785ad:

    # "with wildflowers and vegetation, almost like a mini-meadow, covering the entire land."
    "con flores silvestres y vegetación, casi como una mini pradera, que cubre todo el terreno."

# game/days1.rpy:353
translate Paloslios day1_f739ef30:

    # "Then I see a deer."
    "Entonces veo un ciervo."

# game/days1.rpy:353
translate Paloslios day1_3496e32c:

    # "It was happily nibbling on some grass, and on occasion would twitch its cute, fluffy tail."
    "Estaba felizmente mordisqueando un poco de hierba y, en ocasiones, movía su linda y esponjosa cola."

# game/days1.rpy:353
translate Paloslios day1_7c401441:

    # "Both me and Alan didn’t move a muscle, so as to not scare the cute creature, but we still enjoyed the view."
    "Tanto Alan como yo no movimos un músculo para no asustar a la linda criatura, pero aún así disfrutamos de la vista."

# game/days1.rpy:362
translate Paloslios day1_97c5b913:

    # a "Lil’ cutie, ain’t he? I always come here to see if he is around."
    a "Pequeña monada, ¿no? Siempre vengo aquí para ver si está por aquí."

# game/days1.rpy:364
translate Paloslios day1_d177f477:

    # "That was adorable. Who knew Alan had such a sensitive soul? At least that’s what I thought."
    "Eso fue adorable. ¿Quién diría que Alan tenía un alma tan sensible? Al menos eso es lo que pensé."

# game/days1.rpy:366
translate Paloslios day1_3c25b553:

    # a "It may not come as a surprise to you, but my favorite animals are deers."
    a "Puede que no te sorprenda, pero mis animales favoritos son los ciervos."

# game/days1.rpy:368
translate Paloslios day1_0a19dd0b:

    # u "Is that why you called me, “doe-eyes” before? Do I remind you of a deer, Alan?"
    u "¿Es por eso que me llamaste \"ojos de cierva\" antes? ¿Te recuerdo a un ciervo, Alan?"

# game/days1.rpy:370
translate Paloslios day1_755562a9:

    # "Alan stayed quiet, a little taken aback by my question."
    "Alan se quedó callado, un poco desconcertado por mi pregunta."

# game/days1.rpy:371
translate Paloslios day1_081d31d9:

    # "However, another sound stopped him from responding."
    "Sin embargo, otro sonido le impidió responder."

# game/days1.rpy:373
translate Paloslios day1_3ddb3faa:

    # "He got lucky."
    "Tuvo suerte."

# game/days1.rpy:375
translate Paloslios day1_ac7d9f2c:

    # a "Huh. They’re new."
    a "Eh. Son nuevos."

# game/days1.rpy:379
translate Paloslios day1_9bcdd223:

    # "Another deer emerged from the wood, joining in."
    "Otro ciervo surgió del bosque y se unió."

# game/days1.rpy:380
translate Paloslios day1_4fd5254d:

    # "I couldn’t deny that it was rather an adorable sight to see."
    "No podía negar que era un espectáculo adorable de ver."

# game/days1.rpy:382
translate Paloslios day1_acbb43ea:

    # a "… Maybe it’s more than one reason…"
    a "…Tal vez sea más de una razón…"

# game/days1.rpy:384
translate Paloslios day1_08d8b0b5:

    # u "What was that?"
    u "¿Qué fue eso?"

# game/days1.rpy:386
translate Paloslios day1_1907072d:

    # "It was barely a whisper, I could only manage to hear a few words from him."
    "Fue apenas un susurro, sólo logré escuchar unas pocas palabras de él."

# game/days1.rpy:388
translate Paloslios day1_7dae9f70:

    # a "N-Nothing… Anyway, wanna grab a bite to eat? I know there is a store not that far from here."
    a "N-Nada... De todos modos, ¿quieres comer algo? Sé que hay una tienda no muy lejos de aquí."

# game/days1.rpy:390
translate Paloslios day1_1a0da753:

    # u "Why not? I am getting peckish."
    u "¿Por qué no? Me estoy poniendo hambriento."

# game/days1.rpy:398
translate Paloslios day1_082b1e3c:

    # "He swiftly got to his feet again, not bothering to dust off his clothes."
    "Rápidamente se puso de pie otra vez, sin molestarse en quitarse el polvo de la ropa."

# game/days1.rpy:399
translate Paloslios day1_4dc01c1e:

    # "He still had the decency to hold out his hand for me to get up."
    "Todavía tuvo la decencia de tenderme la mano para que me levantara."

# game/days1.rpy:401
translate Paloslios day1_3cb3dd98:

    # a "Alright. We probably won’t take long if we get going now."
    a "Está bien. Probablemente no tardemos mucho si nos ponemos en marcha ahora."

# game/days1.rpy:403
translate Paloslios day1_225d4862:

    # "Much like before, he kept holding my hand through the entire walk back to civilization."
    "Al igual que antes, siguió sosteniendo mi mano durante todo el camino de regreso a la civilización."

# game/days1.rpy:404
translate Paloslios day1_d6aace92:

    # "It stopped feeling so foreign, as if I knew Alan and trusted him enough to hold hands."
    "Dejé de sentirme tan extraño, como si conociera a Alan y confiara en él lo suficiente como para tomarme de la mano."

# game/days1.rpy:405
translate Paloslios day1_33087a86:

    # "I don’t know why he made me feel so safe. I feel melodramatic thinking about it."
    "No sé por qué me hizo sentir tan segura. Me siento melodramático al pensar en ello."

# game/days1.rpy:406
translate Paloslios day1_555802dd:

    # "Everything seemed to get blurry and I could feel my stomach doing flips."
    "Todo pareció volverse borroso y podía sentir mi estómago dando vueltas."

# game/days1.rpy:412
translate Paloslios day1_8d8b10eb:

    # "It was then that the obnoxiously bright lights of the store pulled me out of the trance."
    "Fue entonces cuando las desagradablemente brillantes luces de la tienda me sacaron del trance."

# game/days1.rpy:412
translate Paloslios day1_2632c8fb:

    # "There were a couple of people in this small store, most of them adults collecting some boxes of beer."
    "Había un par de personas en esta pequeña tienda, la mayoría adultos recogiendo algunas cajas de cerveza."

# game/days1.rpy:421
translate Paloslios day1_56a28d06:

    # "Alan started scanning around, as if to memorize where everything was."
    "Alan comenzó a escanear a su alrededor, como para memorizar dónde estaba todo."

# game/days1.rpy:423
translate Paloslios day1_3f9e92c9:

    # "His attention was immediately caught by the ice isle, his smile brightening like a child."
    "Su atención fue inmediatamente captada por la isla de hielo, su sonrisa se iluminó como la de un niño."

# game/days1.rpy:425
translate Paloslios day1_953c8966:

    # a "Pick anything you want, it’s on me."
    a "Elige lo que quieras, depende de mí."

# game/days1.rpy:427
translate Paloslios day1_8754e33c:

    # "How generous of him! I looked around and decided to get…"
    "¡Qué generoso de su parte! Miré a mi alrededor y decidí ir..."

# game/days1.rpy:432
translate Paloslios day1_2bfd58d8:

    # "I reached in the cold freezer, grabbing myself whatever seemed most appealing."
    "Metí la mano en el frío congelador y cogí lo que me pareció más atractivo."

# game/days1.rpy:434
translate Paloslios day1_142e1027:

    # "Alan flashed me a smile, he seemed giddy that we got the same thing."
    "Alan me sonrió, parecía mareado de que tuviéramos lo mismo."

# game/days1.rpy:438
translate Paloslios day1_a7a64fa4:

    # "I quickly ran to the side of the store, grabbing myself a huge cup of frozen-syrupy goodness. They were fairly cheap."
    "Rápidamente corrí hacia un lado de la tienda y tomé una taza enorme de almíbar helado. Eran bastante baratos."

# game/days1.rpy:441
translate Paloslios day1_deb43a00:

    # "I walked up towards the soda fountain. I was craving something more refreshing than anything."
    "Caminé hacia la fuente de refrescos. Estaba deseando algo más refrescante que cualquier otra cosa."

# game/days1.rpy:443
translate Paloslios day1_da9d6d5e:

    # a "Got everything?"
    a "¿Tienes todo?"

# game/days1.rpy:445
translate Paloslios day1_79d4b01f:

    # u "Yeah! Let’s go."
    u "¡Sí! Vamos."

# game/days1.rpy:451
translate Paloslios day1_962e8a6e:

    # "We left the store, basking in our glorious treats. Alan proceeded to scarf his ice cream down."
    "Salimos de la tienda, disfrutando de nuestras gloriosas delicias. Alan procedió a devorar su helado."

# game/days1.rpy:453
translate Paloslios day1_01f0cab5:

    # u "You’re gonna choke yourself eating it like that."
    u "Te vas a ahogar comiéndolo así."

# game/days1.rpy:455
translate Paloslios day1_f49799b0:

    # a "Then that’s how I wanna go… Here lies Alan. Death by ice cream."
    a "Entonces así es como quiero ir... Aquí yace Alan. Muerte por helado."

# game/days1.rpy:457
translate Paloslios day1_c5cf4575:

    # "He dramatically put his hands on his heart and lowered his head all gloomy."
    "Se puso dramáticamente las manos en el corazón y bajó la cabeza todo sombrío."

# game/days1.rpy:458
translate Paloslios day1_ff29bf78:

    # "I snorted and playfully pushed him, though I could barely manage to make him lose his footing."
    "Resoplé y lo empujé juguetonamente, aunque apenas pude lograr que perdiera el equilibrio."

# game/days1.rpy:460
translate Paloslios day1_227b0540:

    # u "People will think you died from lactose then."
    u "Entonces la gente pensará que moriste a causa de la lactosa."

# game/days1.rpy:464
translate Paloslios day1_178e30f8:

    # a "I mean… I kinda am lactose intolerant. Just a bit."
    a "Quiero decir… soy un poco intolerante a la lactosa. Sólo un poco."

# game/days1.rpy:466
translate Paloslios day1_97ae0dbe:

    # u "And you took that risk?"
    u "¿Y corriste ese riesgo?"

# game/days1.rpy:470
translate Paloslios day1_45a2317c:

    # a "I like to live on the edge."
    a "Me gusta vivir al límite."

# game/days1.rpy:472
translate Paloslios day1_46b7b77a:

    # "I roll my eyes."
    "Pongo los ojos en blanco."

# game/days1.rpy:476
translate Paloslios day1_c334af9b:

    # a "No, seriously. I stole five chocolate bars while nobody was looking."
    a "No, en serio. Robé cinco barras de chocolate mientras nadie miraba."

# game/days1.rpy:478
translate Paloslios day1_4b693328:

    # "WHAT?!"
    "¡¿QUÉ?!"

# game/days1.rpy:480
translate Paloslios day1_d9bf04ea:

    # u "You shoplifted?!"
    u "¿Robaste en una tienda?"

# game/days1.rpy:484
translate Paloslios day1_e5c02ac4:

    # "He gave me a proud smirk, unzipping his coat, showing me his loot."
    "Me dio una sonrisa orgullosa, se desabrochó el abrigo y me mostró su botín."

# game/days1.rpy:485
translate Paloslios day1_6bbb0258:

    # "I was dumbfounded. I couldn’t fucking believe it. This man just robbed a store."
    "Me quedé estupefacto. No podía creerlo. Este hombre acaba de robar una tienda."

# game/days1.rpy:486
translate Paloslios day1_07aae630:

    # "How did I not even notice him? He must’ve been real sneaky or quick."
    "¿Cómo ni siquiera me di cuenta de él? Debe haber sido muy astuto o rápido."

# game/days1.rpy:488
translate Paloslios day1_d2a91064:

    # a "You should see the look on your face right now."
    a "Deberías ver la expresión de tu cara ahora mismo."

# game/days1.rpy:490
translate Paloslios day1_72b01ede:

    # "He reached in, grabbing one from his stash."
    "Metió la mano y tomó uno de su alijo."

# game/days1.rpy:492
translate Paloslios day1_c654ab8e:

    # u "You can’t just-"
    u "No puedes simplemente-"

# game/days1.rpy:493
translate Paloslios day1_25eb9abb:

    # u "That isn’t-"
    u "Eso no es-"

# game/days1.rpy:497
translate Paloslios day1_383a619a:

    # a "I said it was on me, right? They aren’t gonna waste their time over some shit like stolen candy, besides…"
    a "Dije que era por mi cuenta, ¿verdad? No van a perder el tiempo con una mierda como caramelos robados, además..."

# game/days1.rpy:499
translate Paloslios day1_4986f59f:

    # "His fingers fidgeted with the wrapper, prying it open and taking a bite before nudging it towards me."
    "Sus dedos juguetearon con el envoltorio, abriéndolo y dándole un mordisco antes de empujarlo hacia mí."

# game/days1.rpy:501
translate Paloslios day1_aeb76086:

    # a "Stolen stuff tastes better."
    a "Las cosas robadas saben mejor."

# game/days1.rpy:503
translate Paloslios day1_d1b42718:

    # "Hesitantly, I reached over, and took the tiniest bite."
    "Vacilante, me acerqué y le di el más mínimo mordisco."

# game/days1.rpy:504
translate Paloslios day1_034b5524:

    # "I couldn’t explain it, but he was right. It was like the forbidden candy bar."
    "No podía explicarlo, pero tenía razón. Era como la barra de chocolate prohibida."

# game/days1.rpy:505
translate Paloslios day1_85f1db47:

    # "Still I feel kinda bad that he went out of his way to steal stuff for me."
    "Aún así me siento un poco mal porque se esforzó por robar cosas para mí."

# game/days1.rpy:509
translate Paloslios day1_f3d47bcf:

    # "It only seemed fair, right? It was the least I could do."
    "Parecía justo, ¿verdad? Era lo mínimo que podía hacer."

# game/days1.rpy:510
translate Paloslios day1_f51b7382:

    # "I motioned my [food] towards him. At first, he gave me a confusing look, but soon got the hint."
    "Le hice un gesto a mi [food] hacia él. Al principio me miró confuso, pero pronto captó la indirecta."

# game/days1.rpy:514
translate Paloslios day1_bd6d6379:

    # a "Ah…"
    a "Ah..."

# game/days1.rpy:516
translate Paloslios day1_ba8102c4:

    # "He leaned down, accepting my offer."
    "Se inclinó y aceptó mi oferta."

# game/days1.rpy:517
translate Paloslios day1_30d26af3:

    # "Unknowingly, he grazed the top of my hand as I held the ice cream."
    "Sin saberlo, rozó la parte superior de mi mano mientras sostenía el helado."

# game/days1.rpy:518
translate Paloslios day1_c19aa1ca:

    # "Or maybe he did… I could feel him tightening his grip slightly, as he looked up at me."
    "O tal vez lo hizo… Podía sentirlo apretar ligeramente su agarre, mientras me miraba."

# game/days1.rpy:520
translate Paloslios day1_5145ff48:

    # "I could feel the tips of my ears beginning to heat up. I could not look anywhere else besides his gaze."
    "Podía sentir las puntas de mis oídos comenzando a calentarse. No podía mirar a ningún otro lado además de su mirada."

# game/days1.rpy:522
translate Paloslios day1_cc51111a:

    # a "You have good taste, doe-eyes."
    a "Tienes buen gusto, ojos de cierva."

# game/days1.rpy:525
translate Paloslios day1_bd6d6379_1:

    # a "Ah…"
    a "Ah..."

# game/days1.rpy:527
translate Paloslios day1_ba8102c4_1:

    # "He leaned down, accepting my offer."
    "Se inclinó y aceptó mi oferta."

# game/days1.rpy:528
translate Paloslios day1_85faaba7:

    # "Unknowingly, he grazed the top of my hand as I held the cup."
    "Sin saberlo, rozó la parte superior de mi mano mientras sostenía la taza."

# game/days1.rpy:529
translate Paloslios day1_c19aa1ca_1:

    # "Or maybe he did… I could feel him tightening his grip slightly, as he looked up at me."
    "O tal vez lo hizo… Podía sentirlo apretar ligeramente su agarre, mientras me miraba."

# game/days1.rpy:531
translate Paloslios day1_5145ff48_1:

    # "I could feel the tips of my ears beginning to heat up. I could not look anywhere else besides his gaze."
    "Podía sentir las puntas de mis oídos comenzando a calentarse. No podía mirar a ningún otro lado además de su mirada."

# game/days1.rpy:533
translate Paloslios day1_cc51111a_1:

    # a "You have good taste, doe-eyes."
    a "Tienes buen gusto, ojos de cierva."

# game/days1.rpy:536
translate Paloslios day1_bd6d6379_2:

    # a "Ah…"
    a "Ah..."

# game/days1.rpy:538
translate Paloslios day1_ba8102c4_2:

    # "He leaned down, accepting my offer."
    "Se inclinó y aceptó mi oferta."

# game/days1.rpy:539
translate Paloslios day1_85faaba7_1:

    # "Unknowingly, he grazed the top of my hand as I held the cup."
    "Sin saberlo, rozó la parte superior de mi mano mientras sostenía la taza."

# game/days1.rpy:540
translate Paloslios day1_c19aa1ca_2:

    # "Or maybe he did… I could feel him tightening his grip slightly, as he looked up at me."
    "O tal vez lo hizo… Podía sentirlo apretar ligeramente su agarre, mientras me miraba."

# game/days1.rpy:542
translate Paloslios day1_5145ff48_2:

    # "I could feel the tips of my ears beginning to heat up. I could not look anywhere else besides his gaze."
    "Podía sentir las puntas de mis oídos comenzando a calentarse. No podía mirar a ningún otro lado además de su mirada."

# game/days1.rpy:544
translate Paloslios day1_cc51111a_2:

    # a "You have good taste, doe-eyes."
    a "Tienes buen gusto, ojos de cierva."

# game/days1.rpy:547
translate Paloslios day1_5130a88d:

    # "Might be a bad idea."
    "Puede que sea una mala idea."

# game/days1.rpy:550
translate Paloslios day1_b7239a69:

    # "He only smiled at me before walking away and continued to eat his forbidden chocolate bar."
    "Él solo me sonrió antes de alejarse y continuó comiendo su barra de chocolate prohibida."

# game/days1.rpy:552
translate Paloslios day1_8f368b33:

    # u "H-HEY!"
    u "¡Oye!"

# game/days1.rpy:561
translate Paloslios day1_f014b90c:

    # "I followed him soon after."
    "Lo seguí poco después."

# game/days1.rpy:561
translate Paloslios day1_fda86fd5:

    # "We walked all the way back to my house, eating the stolen candy."
    "Caminamos todo el camino de regreso a mi casa, comiendo los dulces robados."

# game/days1.rpy:561
translate Paloslios day1_cbf880b0:

    # "I got some sort of cheap thrill knowing we could’ve potentially gotten caught and Alan shared that feeling as well."
    "Sentí una especie de emoción barata al saber que potencialmente podríamos habernos atrapado y Alan también compartió ese sentimiento."

# game/days1.rpy:561
translate Paloslios day1_e8e5d6ad:

    # "Being with him was thrilling."
    "Estar con él fue emocionante."

# game/days1.rpy:576
translate Paloslios day1_7bf2554d:

    # "I didn’t notice how late it has gotten since I soon reached the comfort of my bed."
    "No me di cuenta de lo tarde que se había hecho ya que pronto llegué a la comodidad de mi cama."

# game/days1.rpy:576
translate Paloslios day1_facba693:

    # "I felt tired, sure. But I also feel… Satisfied? At ease?"
    "Me sentí cansado, seguro. Pero también me siento… ¿Satisfecho? ¿A gusto?"

# game/days1.rpy:576
translate Paloslios day1_09feb332:

    # "Whatever I felt. I knew I was going to see him again tomorrow…"
    "Lo que sea que sentí. Sabía que lo volvería a ver mañana..."

# game/script.rpy:62
translate Paloslios smenu_4fcd6144:

    # "Please type in your custom pronouns for each selection."
    "Escriba sus pronombres personalizados para cada selección."

# game/script.rpy:115
translate Paloslios prologue_0500792f:

    # "It was somewhat of an old habit of mine to walk. Every night I walked."
    "Caminar era una especie de vieja costumbre mía. Todas las noches caminaba."

# game/script.rpy:115
translate Paloslios prologue_9081912f:

    # "Due to the consistency of my routine, walking has helped me to put my mind at ease and numb out the fresh, cool nights."
    "Debido a la constancia de mi rutina, caminar me ha ayudado a tranquilizarme y adormecer las noches frescas y frescas."

# game/script.rpy:115
translate Paloslios prologue_1cca2c0e:

    # "Besides, it was a good source to wear me down before bed; I don’t have to rely on sleeping meds as much."
    "Además, era una buena fuente para desgastarme antes de acostarme; No tengo que depender tanto de medicamentos para dormir."

# game/script.rpy:115
translate Paloslios prologue_52223e7d:

    # "There was nothing fun about laying in bed, having my eyes glued to the ceiling, and dissociating."
    "No había nada divertido en estar acostado en la cama, con los ojos pegados al techo y disociando."

# game/script.rpy:115
translate Paloslios prologue_4e944045:

    # "I have become so familiar with the path, staring at the same damaged sidewalk, hitting a couple of pebbles with the tip of my shoes."
    "Me he familiarizado tanto con el camino, mirando la misma acera dañada, golpeando un par de piedras con la punta de mis zapatos."

# game/script.rpy:115
translate Paloslios prologue_e6306ca6:

    # "I would usually disappear into the woods for twenty minutes or so. I wouldn’t call myself a nature lover per se."
    "Normalmente desaparecía en el bosque durante unos veinte minutos. No me consideraría un amante de la naturaleza per se."

# game/script.rpy:115
translate Paloslios prologue_09366f7e:

    # "Hell, I could not imagine myself abandoning my phone."
    "Demonios, no podía imaginarme abandonando mi teléfono."

# game/script.rpy:115
translate Paloslios prologue_23709f8d:

    # "But at night, the woods were all I wanted."
    "Pero por la noche, lo único que quería era el bosque."

# game/script.rpy:115
translate Paloslios prologue_208293da:

    # "I don’t know why, but this has been the only place that gave me motivation to move, to get out of bed."
    "No sé por qué, pero este ha sido el único lugar que me ha dado motivación para moverme, para levantarme de la cama."

# game/script.rpy:115
translate Paloslios prologue_fefce49d:

    # "College hasn’t been too kind to me, and having just moved out on my own just recently made me feel all the more isolated."
    "La universidad no ha sido muy amable conmigo y haberme mudado sola hace poco me hizo sentir aún más aislado."

# game/script.rpy:115
translate Paloslios prologue_214eff39:

    # "Was there something wrong with me?"
    "¿Había algo mal en mí?"

# game/script.rpy:115
translate Paloslios prologue_b2b12159:

    # "No. Taking little walks to relax at night to sleep is normal."
    "No. Dar pequeños paseos para relajarse por la noche para dormir es normal."

# game/script.rpy:115
translate Paloslios prologue_0ea0e2a7:

    # "I never strayed from my path, it has practically become burned into my memory. And I was kinda proud of that."
    "Nunca me desvié de mi camino, prácticamente quedó grabado en mi memoria. Y estaba un poco orgulloso de eso."

# game/script.rpy:115
translate Paloslios prologue_bd31af32:

    # "It was like my own little secret hideout, where, if I could, one day just disappear from it all. However, today I feel bold."
    "Era como mi pequeño escondite secreto, donde, si podía, algún día desaparecería de todo. Sin embargo, hoy me siento audaz."

# game/script.rpy:115
translate Paloslios prologue_21fce2e1:

    # "And so, I wandered off from my usual path, heading to the wild."
    "Y así, me desvié de mi camino habitual y me dirigí a la naturaleza."

# game/script.rpy:150
translate Paloslios prologue_4fbb1554:

    # "At first, the new environment felt nice."
    "Al principio, el nuevo entorno me pareció agradable."

# game/script.rpy:151
translate Paloslios prologue_68979fd0:

    # "Without noticing, time kinda flew by and all my sense of direction withered away."
    "Sin darme cuenta, el tiempo pasó volando y todo mi sentido de orientación se marchitó."

# game/script.rpy:152
translate Paloslios prologue_902ed6d5:

    # "I now find myself confused."
    "Ahora me encuentro confundido."

# game/script.rpy:154
translate Paloslios prologue_2b8e32a5:

    # "And alone."
    "Y solo."

# game/script.rpy:160
translate Paloslios prologue_d5feaccd:

    # "In the woods."
    "En el bosque."

# game/script.rpy:162
translate Paloslios prologue_c86529ec:

    # u "Fuck…"
    u "Joder…"

# game/script.rpy:164
translate Paloslios prologue_2636b82b:

    # "I couldn’t recognize any noticeable landmarks to help my way out."
    "No pude reconocer ningún punto de referencia notable que me ayudara a salir."

# game/script.rpy:164
translate Paloslios prologue_1ca5bc21:

    # "Oh how funny is this?"
    "Ay que gracioso es esto?"

# game/script.rpy:164
translate Paloslios prologue_276832f6:

    # "I feel like the final girl of a campy slasher movie, being tracked down by the killer."
    "Me siento como la última chica de una película de terror cursi, siendo perseguida por el asesino."

# game/script.rpy:172
translate Paloslios prologue_14d73d3b:

    # u "Fuck, I am so stupid. Stupid. Stupid. Stupid. Of course I was going to end up lost!"
    u "Joder, soy tan estúpido. Estúpido. Estúpido. Estúpido. ¡Por supuesto que iba a terminar perdido!"

# game/script.rpy:174
translate Paloslios prologue_378aaef7:

    # "Great! Not only am I lost, it’s dark, no stars, only the faint light of the moon not doing much help; But I am losing sleep as we know it."
    "¡Excelente! No sólo estoy perdido, sino que está oscuro, no hay estrellas, sólo la tenue luz de la luna no ayuda mucho; Pero estoy perdiendo el sueño tal como lo conocemos."

# game/script.rpy:174
translate Paloslios prologue_10c2c25b:

    # "I could feel the soles of my feet starting to ache."
    "Podía sentir que las plantas de mis pies empezaban a dolerme."

# game/script.rpy:174
translate Paloslios prologue_ee70ff5e:

    # "Perhaps now might be a good time to collect myself before I have a full-blown meltdown in the middle of the woods."
    "Quizás ahora sea un buen momento para recomponerme antes de sufrir un colapso total en medio del bosque."

# game/script.rpy:174
translate Paloslios prologue_db37d035:

    # "I lay my head low, feeling a heavy weight on me, I took a few deep breaths."
    "Apoyé la cabeza, sintiendo un gran peso sobre mí, respiré profundamente unas cuantas veces."

# game/script.rpy:186
translate Paloslios prologue_ec7f5988:

    # "Too late. I couldn’t help it but feel warm, frustrating tears run down my face."
    "Demasiado tarde. No pude evitar sentir lágrimas cálidas y frustrantes corriendo por mi rostro."

# game/script.rpy:187
translate Paloslios prologue_b60f861f:

    # "I let out a few soft sobs, forcing myself to stay as quiet as possible."
    "Dejé escapar unos cuantos sollozos suaves, obligándome a permanecer lo más callado posible."

# game/script.rpy:188
translate Paloslios prologue_beb3669e:

    # "For God’s sake, I really don’t know where the hell I am."
    "Por el amor de Dios, realmente no sé dónde diablos estoy."

# game/script.rpy:190
translate Paloslios prologue_60f00797:

    # "My hands creeped up to my arms, trying to give myself some sort of comfort."
    "Mis manos subieron hasta mis brazos, tratando de darme algún tipo de consuelo."

# game/script.rpy:191
translate Paloslios prologue_beb3669e_1:

    # "For God’s sake, I really don’t know where the hell I am."
    "Por el amor de Dios, realmente no sé dónde diablos estoy."

# game/script.rpy:193
translate Paloslios prologue_a763b8d0:

    # "{i}SNAP!!{/i}"
    "{i}¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡"

# game/script.rpy:195
translate Paloslios prologue_0009b186:

    # u "!!"
    u "!!"

# game/script.rpy:197
translate Paloslios prologue_18e42107:

    # "The deafening silence was abrupted by what seemed like… A twig? What the hell made that sound?"
    "El silencio ensordecedor fue interrumpido por lo que parecía… ¿Una ramita? ¿Qué diablos hizo ese sonido?"

# game/script.rpy:198
translate Paloslios prologue_1fb69bc1:

    # "I jumped, startled, I took a few steps back, nearly losing my balance. Wherever that sound came from, I didn’t see anything."
    "Salté sobresaltada, retrocedí unos pasos y casi pierdo el equilibrio. De donde vino ese sonido, no vi nada."

# game/script.rpy:200
translate Paloslios prologue_7abec3db:

    # a "Aww... Don’t cry..."
    a "Ay... no llores..."

# game/script.rpy:202
translate Paloslios prologue_d86ed196:

    # "A muffled voice came behind me. I quickly turn around and see… A person."
    "Una voz apagada vino detrás de mí. Rápidamente me doy la vuelta y veo… Una persona."

# game/script.rpy:206
translate Paloslios prologue_0f445015:

    # "I still could not make out his features well. His hair was wild, sticking out from the top of his head."
    "Todavía no podía distinguir bien sus rasgos. Su cabello estaba revuelto y sobresalía desde la parte superior de su cabeza."

# game/script.rpy:207
translate Paloslios prologue_9b62f34d:

    # "He was holding something. A hatchet… Am I about to get murdered? My muscles tensed up as I prepared to make a break for it."
    "Estaba sosteniendo algo. Un hacha… ¿Estoy a punto de ser asesinado? Mis músculos se tensaron mientras me preparaba para escapar."

# game/script.rpy:208
translate Paloslios prologue_08981f40:

    # "He seemed to notice my mannerism."
    "Pareció notar mi manierismo."

# game/script.rpy:216
translate Paloslios prologue_3a7fdc34:

    # a "H-Hey."
    a "O-oye."

# game/script.rpy:218
translate Paloslios prologue_e03b34e1:

    # "He held up his hands, letting the hatchet slip from his fingers and into the grass."
    "Levantó las manos y dejó que el hacha se deslizara de sus dedos hacia la hierba."

# game/script.rpy:219
translate Paloslios prologue_cf01f9ea:

    # "His movements were slow and harmless."
    "Sus movimientos eran lentos e inofensivos."

# game/script.rpy:221
translate Paloslios prologue_27a93848:

    # a "Take it easy…"
    a "Tómatelo con calma…"

# game/script.rpy:223
translate Paloslios prologue_61fe1561:

    # u "Who the hell are you?"
    u "¿Quién diablos eres tú?"

# game/script.rpy:227
translate Paloslios prologue_f85bf496:

    # a "Just some guy trying to help ya out. That’s it."
    a "Sólo un tipo que intenta ayudarte. Eso es todo."

# game/script.rpy:229
translate Paloslios prologue_7da3bdaf:

    # "... That wasn’t very comforting at all."
    "... Eso no fue nada reconfortante."

# game/script.rpy:231
translate Paloslios prologue_e23166e3:

    # "Especially now that he reached over to the ground, retrieving his hatchet and casually swung it over his shoulder."
    "Especialmente ahora que se acercó al suelo, recuperó su hacha y la colgó casualmente sobre su hombro."

# game/script.rpy:232
translate Paloslios prologue_c8c18174:

    # "Why the hell did he sneak up to me like that? Why was he in the woods? Has he been following me?"
    "¿Por qué diablos se acercó sigilosamente a mí de esa manera? ¿Por qué estaba en el bosque? ¿Me ha estado siguiendo?"

# game/script.rpy:234
translate Paloslios prologue_7b1c1392:

    # u "..."
    u "..."

# game/script.rpy:235
translate Paloslios prologue_47218372:

    # u "Where did you even come from?"
    u "¿De dónde vienes?"

# game/script.rpy:239
translate Paloslios prologue_79fdf728:

    # a "I live here actually. Just a couple of miles. Got my own place and everything-"
    a "Vivo aquí en realidad. Sólo un par de millas. Tengo mi propio lugar y todo."

# game/script.rpy:240
translate Paloslios prologue_c16ca251:

    # u "Why do you have an axe?! Also, I wasn’t crying…"
    u "¡¿Por qué tienes un hacha?! Además no estaba llorando..."

# game/script.rpy:244
translate Paloslios prologue_b28559f4:

    # a "It’s a hatchet, first of all."
    a "Es un hacha, ante todo."

# game/script.rpy:246
translate Paloslios prologue_b4332b4e:

    # u "…"
    u "…"

# game/script.rpy:247
translate Paloslios prologue_37fe551f:

    # u "Sure."
    u "Seguro."

# game/script.rpy:251
translate Paloslios prologue_9ec1a989:

    # a "Heheh."
    a "Jejeje."

# game/script.rpy:253
translate Paloslios prologue_a20cefa7:

    # "..."
    "..."

# game/script.rpy:255
translate Paloslios prologue_26d3c79a:

    # u "Are you gonna murder me?"
    u "¿Me vas a asesinar?"

# game/script.rpy:259
translate Paloslios prologue_e97c88fe:

    # a "What? No. I was getting some firewood. It is starting to get cold ‘round here."
    a "¿Qué? No. Estaba buscando leña. Está empezando a hacer frío por aquí."

# game/script.rpy:263
translate Paloslios prologue_3bfe4bf6:

    # "I was still trying to come down from the adrenaline, I didn't even notice the chilly breeze."
    "Todavía estaba tratando de bajar la adrenalina, ni siquiera noté la brisa helada."

# game/script.rpy:264
translate Paloslios prologue_cd3a6340:

    # "I started connecting the dots. He was probably telling the truth. I am not at all experienced in… Forest living?"
    "Empecé a conectar los puntos. Probablemente estaba diciendo la verdad. No tengo ninguna experiencia en... ¿Vida en el bosque?"

# game/script.rpy:265
translate Paloslios prologue_84ffb01d:

    # "Who am I to tell him that he doesn’t know what he’s talking about?"
    "¿Quién soy yo para decirle que no sabe de lo que habla?"

# game/script.rpy:267
translate Paloslios prologue_d01b27f9:

    # u "… So why exactly did you come here?"
    u "… Entonces, ¿exactamente por qué viniste aquí?"

# game/script.rpy:271
translate Paloslios prologue_2feee4e4:

    # a "Well- You wanna get outta here don’t you? I know my way around."
    a "Bueno, quieres salir de aquí, ¿no? Conozco mi camino."

# game/script.rpy:275
translate Paloslios prologue_9246fcab:

    # "Maybe I am being too paranoid. He doesn’t seem like he has any intention of hurting someone."
    "Quizás estoy siendo demasiado paranoico. No parece que tenga ninguna intención de lastimar a alguien."

# game/script.rpy:276
translate Paloslios prologue_ff42d8c9:

    # "See [name]? Not everyone is out to get you. Just follow him so he can take you back home…"
    "¿Ves [name]? No todo el mundo quiere atraparte. Sólo síguelo para que pueda llevarte de regreso a casa..."

# game/script.rpy:280
translate Paloslios prologue_a3929ce9:

    # a "In case you’re still skeptical, you can go behind me."
    a "En caso de que todavía tengas dudas, puedes ir detrás de mí."

# game/script.rpy:286
translate Paloslios prologue_6cb01962:

    # "He offered out his hand. Of course, I hesitated, but I took it anyway."
    "Extendió su mano. Por supuesto, dudé, pero lo acepté de todos modos."

# game/script.rpy:287
translate Paloslios prologue_8c02d64d:

    # "I could feel his fingerless gloves as he gave my hand a tight squeeze. He had some coarseness, but it didn’t bother me."
    "Podía sentir sus guantes sin dedos cuando me apretó la mano con fuerza. Tenía algo de grosería, pero no me molestó."

# game/script.rpy:288
translate Paloslios prologue_135066ed:

    # "It took us a good while to get back. I must’ve really wandered way far off than expected."
    "Nos tomó un buen tiempo regresar. Realmente debo haberme alejado mucho más de lo esperado."

# game/script.rpy:290
translate Paloslios prologue_1896fdf9:

    # "The trees were becoming less dense, and I could see his traits more and more. His eyes were particularly striking."
    "Los árboles se estaban volviendo menos densos y podía ver sus rasgos cada vez más. Sus ojos eran particularmente llamativos."

# game/script.rpy:291
translate Paloslios prologue_feaa250c:

    # "They were both different… I shouldn’t be staring, seems kinda rude. In fact, the whole time I have been acting rude, huh?"
    "Ambos eran diferentes... No debería estar mirándolos, parece un poco grosero. De hecho, todo el tiempo he estado actuando de manera grosera, ¿eh?"

# game/script.rpy:293
translate Paloslios prologue_96faea70:

    # u "Hey… Um…"
    u "Oye... um..."

# game/script.rpy:296
translate Paloslios prologue_32fb53c2:

    # a "Hm?"
    a "¿Mmm?"

# game/script.rpy:298
translate Paloslios prologue_f98dec76:

    # u "Sorry for being kinda reluctant back there… hah…"
    u "Perdón por ser un poco reacio allí atrás... ja..."

# game/script.rpy:302
translate Paloslios prologue_32d7116e:

    # "He simply shrugged and smiled at me."
    "Él simplemente se encogió de hombros y me sonrió."

# game/script.rpy:306
translate Paloslios prologue_c8e6811b:

    # a "Eh- I don’t blame you."
    a "Eh-no te culpo."

# game/script.rpy:307
translate Paloslios prologue_8ba0da5d:

    # a "I mean, if I was in your position, I would've probably freaked out if I saw some random guy with an axe approach me, as well."
    a "Quiero decir, si estuviera en tu posición, probablemente también me habría asustado si hubiera visto a algún tipo al azar con un hacha acercarse a mí."

# game/script.rpy:311
translate Paloslios prologue_2f55bee2:

    # u "Hatchet."
    u "Hacha."

# game/script.rpy:315
translate Paloslios prologue_ebb2afb6:

    # a "Sure."
    a "Seguro."

# game/script.rpy:317
translate Paloslios prologue_634dca30:

    # "That seemed to get a laugh out of him and let out some tension as well. It’s been a while since I laughed."
    "Eso pareció hacerle reír y también dejó escapar algo de tensión. Ha pasado un tiempo desde que me reí."

# game/script.rpy:317
translate Paloslios prologue_279c8eba:

    # "Nowadays it’s been feeling like I have been so isolated, I am surprised I could achieve a conversation with him, let alone other people."
    "Hoy en día me siento tan aislado que me sorprende poder entablar una conversación con él, y mucho menos con otras personas."

# game/script.rpy:317
translate Paloslios prologue_798499e8:

    # "With time, the dirt path merged with the edge of the sidewalk. Thank god we made it! What a relief!"
    "Con el tiempo, el camino de tierra se fusionó con el borde de la acera. ¡Gracias a Dios lo logramos! ¡Qué alivio!"

# game/script.rpy:329
translate Paloslios prologue_3503e1ff:

    # a "There ya go!"
    a "¡Ahí tienes!"

# game/script.rpy:331
translate Paloslios prologue_bbf95efd:

    # u "Oh my god! Thanks!"
    u "¡Ay dios mío! ¡Gracias!"

# game/script.rpy:333
translate Paloslios prologue_77caf252:

    # "I didn’t notice that I was still holding his hand. He gave me a small smile before I stuffed my hands into my pockets."
    "No me di cuenta de que todavía estaba sosteniendo su mano. Me dio una pequeña sonrisa antes de meter las manos en los bolsillos."

# game/script.rpy:334
translate Paloslios prologue_c417d757:

    # "Other than having a breakdown in the woods, this entire experience wasn’t that bad."
    "Aparte de sufrir una avería en el bosque, toda esta experiencia no fue tan mala."

# game/script.rpy:338
translate Paloslios prologue_83cfc354:

    # a "I’ll see ya around, then."
    a "Entonces nos vemos por ahí."

# game/script.rpy:340
translate Paloslios prologue_eb6a297d:

    # "He continued to stand in his place while I turned my back from the woods, walking into my neighborhood once again."
    "Continuó de pie en su lugar mientras yo le daba la espalda al bosque y caminaba hacia mi vecindario una vez más."

# game/script.rpy:341
translate Paloslios prologue_e665abcd:

    # "Stopping at the front door, I gave him one last wave. I couldn’t really tell from the distance, but he seemed to wave back."
    "Me detuve en la puerta principal y le saludé por última vez. Realmente no podía decirlo desde la distancia, pero él pareció devolverme el saludo."

# game/script.rpy:347
translate Paloslios prologue_dcfb295d:

    # u "I’m so tired…"
    u "Estoy tan cansada..."

# game/script.rpy:349
translate Paloslios prologue_b2a0c40e:

    # "Exhausted, I immediately threw myself onto my bed, finally able to get some rest."
    "Agotado, inmediatamente me tiré en la cama y finalmente pude descansar un poco."

# game/script.rpy:350
translate Paloslios prologue_7ebe179e:

    # "My eyes… They feel heavy… That stranger he seemed… Nice."
    "Mis ojos… Se sienten pesados… Ese extraño que parecía… Lindo."

# game/script.rpy:352
translate Paloslios prologue_e6499691:

    # u "I didn’t catch his name…"
    u "No entendí su nombre..."

# game/script.rpy:354
translate Paloslios prologue_bca654ab:

    # "I’ll ask him tomorrow."
    "Le preguntaré mañana."

# game/days2.rpy:5
translate Paloslios day2_8b258704:

    # u "Huh?"
    u "¿Eh?"

# game/days2.rpy:6
translate Paloslios day2_43803bfd:

    # "I open my eyes, but I can’t see anything…"
    "Abro los ojos, pero no veo nada..."

# game/days2.rpy:6
translate Paloslios day2_2e295e2b:

    # "I try to feel around, but nothing appears to be in front of me."
    "Intento palpar a mi alrededor, pero no parece haber nada delante de mí."

# game/days2.rpy:16
translate Paloslios day2_f8a833dc:

    # "?!"
    "?!"

# game/days2.rpy:16
translate Paloslios day2_c58e08a3:

    # "Fingers start tightening around my throat…"
    "Los dedos comienzan a apretarse alrededor de mi garganta..."

# game/days2.rpy:16
translate Paloslios day2_71b7dec6:

    # "I started to claw desperately, my lungs feel like they are about to collapse."
    "Empecé a arañar desesperadamente, mis pulmones se sienten como si estuvieran a punto de colapsar."

# game/days2.rpy:36
translate Paloslios day2_ce617998:

    # "…"
    "…"

# game/days2.rpy:37
translate Paloslios day2_02468116:

    # u "Holy shit…"
    u "Santa mierda..."

# game/days2.rpy:39
translate Paloslios day2_d0c5ff5b:

    # "What a way to start the morning."
    "Qué manera de empezar la mañana."

# game/days2.rpy:44
translate Paloslios day2_a5322abb:

    # "It’s too early for this."
    "Es demasiado pronto para esto."

# game/days2.rpy:46
translate Paloslios day2_de5fb9d9:

    # "For fuck’s sake, it isn’t even a person that woke me up, instead it was some goddamn emergency alert."
    "Joder, ni siquiera fue una persona la que me despertó, sino una maldita alerta de emergencia."

# game/days2.rpy:47
translate Paloslios day2_06d8d47f:

    # "Something about another missing person. Seems like it is out of my control."
    "Algo sobre otra persona desaparecida. Parece que está fuera de mi control."

# game/days2.rpy:48
translate Paloslios day2_d8ecb65e:

    # "My head was pounding and I felt incredibly drained."
    "Me palpitaba la cabeza y me sentía increíblemente agotado."

# game/days2.rpy:49
translate Paloslios day2_03796630:

    # "The time reminded me that I got only a measly three hours of sleep last night, a half empty bottle of sleeping meds on its side."
    "El tiempo me recordó que anoche solo dormí unas míseras tres horas, con un frasco medio vacío de medicamentos para dormir de lado."

# game/days2.rpy:50
translate Paloslios day2_da6e48bd:

    # "I did NOT want to get up."
    "NO quería levantarme."

# game/days2.rpy:52
translate Paloslios day2_ce617998_1:

    # "…"
    "…"

# game/days2.rpy:52
translate Paloslios day2_9da9534c:

    # "I wanted to see Alan, though…"
    "Aunque quería ver a Alan..."

# game/days2.rpy:52
translate Paloslios day2_db23de2e:

    # "I wonder what he was gonna plan today."
    "Me pregunto qué iba a planear hoy."

# game/days2.rpy:52
translate Paloslios day2_36eb6929:

    # "He had a knack for keeping me on my toes and surprising me."
    "Tenía una habilidad especial para mantenerme alerta y sorprenderme."

# game/days2.rpy:52
translate Paloslios day2_a0f16db5:

    # "He makes me feel warmth every time I think about him. He was kinda strange, but it was charming in a way."
    "Me hace sentir calidez cada vez que pienso en él. Era un poco extraño, pero en cierto modo encantador."

# game/days2.rpy:52
translate Paloslios day2_5c3d3e58:

    # "Well if I was ever going to see him, I might as well get ready."
    "Bueno, si alguna vez iba a verlo, sería mejor que me preparara."

# game/days2.rpy:69
translate Paloslios day2_7ea6239b:

    # "Despite the rough morning, I didn’t feel quite as tired as I did before."
    "A pesar de la dura mañana, no me sentía tan cansado como antes."

# game/days2.rpy:69
translate Paloslios day2_49a549ad:

    # "It could be because I was pretty much looking forward to meeting up with the local cryptic man I met just two days ago."
    "Podría ser porque tenía muchas ganas de reunirme con el hombre críptico local que conocí hace apenas dos días."

# game/days2.rpy:79
translate Paloslios day2_c2d84205:

    # "It was certainly worth getting lost in the woods just to hang out with Alan."
    "Ciertamente valió la pena perderse en el bosque sólo para pasar el rato con Alan."

# game/days2.rpy:79
translate Paloslios day2_53b87790:

    # "Much better than wasting my time being cooped up inside my home, water bottles and dirty laundry taking up the space."
    "Mucho mejor que perder el tiempo encerrado dentro de mi casa, con botellas de agua y ropa sucia ocupando el espacio."

# game/days2.rpy:87
translate Paloslios day2_0cdd9400:

    # "Right on cue, I see Alan from the distance, waiting for me, I presume. He appeared to be playing around with his hatchet before noticing my presence."
    "En ese momento, veo a Alan desde la distancia, esperándome, supongo. Parecía estar jugando con su hacha antes de notar mi presencia."

# game/days2.rpy:92
translate Paloslios day2_850d14b3:

    # "He cutely waved at me with the biggest grin on his face."
    "Me saludó tiernamente con la mayor sonrisa en su rostro."

# game/days2.rpy:92
translate Paloslios day2_13506e03:

    # "Did he always have sharp molars?"
    "¿Siempre tuvo molares afilados?"

# game/days2.rpy:102
translate Paloslios day2_d66756d3:

    # a "[name]! You made it!"
    a "[name]! ¡Lo lograste!"

# game/days2.rpy:104
translate Paloslios day2_465be919:

    # u "Hey, Alan. Sorry if I was late."
    u "Hola, Alan. Lo siento si llegué tarde."

# game/days2.rpy:109
translate Paloslios day2_7d8be7c8:

    # a "Not really. You’re right on time actually."
    a "No precisamente. De hecho, llegas justo a tiempo."

# game/days2.rpy:111
translate Paloslios day2_1fc5f9c8:

    # u "Really? Huh."
    u "¿En realidad? Eh."

# game/days2.rpy:113
translate Paloslios day2_d0ad1860:

    # "I figured because of my lack of sleep, I would’ve arrived later than expected."
    "Pensé que debido a mi falta de sueño, habría llegado más tarde de lo esperado."

# game/days2.rpy:117
translate Paloslios day2_fee70918:

    # "Alan rested his hands on his knees, trying to get at my eye level. He was really close…"
    "Alan apoyó las manos en las rodillas, tratando de llegar al nivel de mis ojos. Estaba muy cerca..."

# game/days2.rpy:121
translate Paloslios day2_4dd086a7:

    # a "Ready for what I have planned for today?"
    a "¿Listo para lo que tengo planeado para hoy?"

# game/days2.rpy:123
translate Paloslios day2_9284e23c:

    # "He flashed me a hopeful smile. How could I say no to his excitement?"
    "Me dedicó una sonrisa esperanzada. ¿Cómo podría decir que no a su entusiasmo?"

# game/days2.rpy:125
translate Paloslios day2_e5e317d0:

    # u "Yeah let’s-"
    u "Sí, vamos-"

# game/days2.rpy:133
translate Paloslios day2_a1bc9207:

    # "Before I could answer, my phone went off."
    "Antes de que pudiera contestar, mi teléfono sonó."

# game/days2.rpy:135
translate Paloslios day2_1c58b700:

    # u "Ah! Sorry!"
    u "¡Ah! ¡Lo siento!"

# game/days2.rpy:137
translate Paloslios day2_8dc4ce0c:

    # "It feels rude to answer a phone call while Alan is around, waiting for me to answer."
    "Se siente de mala educación contestar una llamada telefónica mientras Alan está cerca, esperando que responda."

# game/days2.rpy:138
translate Paloslios day2_dfc0d579:

    # "But what if the call was something important?"
    "Pero ¿y si la llamada fuera algo importante?"

# game/days2.rpy:140
translate Paloslios day2_ca95b42c:

    # e "Hey."
    e "Ey."

# game/days2.rpy:142
translate Paloslios day2_a9d0590d:

    # u "Hey, what’s up?"
    u "¿Hola! Qué tal?"

# game/days2.rpy:146
translate Paloslios day2_d1a6a390:

    # "Immediately after speaking, I looked over to Alan, who seemed to have an annoyed expression on his face."
    "Inmediatamente después de hablar, miré a Alan, quien parecía tener una expresión de molestia en su rostro."

# game/days2.rpy:148
translate Paloslios day2_44be39c4:

    # e "Sorry if I am bothering you at the moment."
    e "Perdón si te estoy molestando en este momento."

# game/days2.rpy:149
translate Paloslios day2_849eba4c:

    # e "I know it’s the end of the week and trust me, I want nothing more than to shun the rest of the world as well but…"
    e "Sé que es fin de semana y, créeme, no quiero nada más que evitar al resto del mundo también, pero..."

# game/days2.rpy:151
translate Paloslios day2_562bf0c5:

    # u "But?"
    u "¿Pero?"

# game/days2.rpy:153
translate Paloslios day2_4c964a91:

    # e "… I want you to meet me at the park. Is that ok?"
    e "… Quiero que nos reúnas conmigo en el parque. ¿Está bien?"

# game/days2.rpy:155
translate Paloslios day2_118a22e1:

    # u "Uh…"
    u "Eh..."

# game/days2.rpy:157
translate Paloslios day2_d9b57e8c:

    # "I don’t see why not. Erika might’ve needed something from me."
    "No veo por qué no. Erika podría haber necesitado algo de mí."

# game/days2.rpy:158
translate Paloslios day2_1b7660ca:

    # "It wouldn’t be cool to leave her like that."
    "No estaría bien dejarla así."

# game/days2.rpy:160
translate Paloslios day2_647f1223:

    # u "Sure thing. Can I bring a friend over?"
    u "Claro. ¿Puedo traer a un amigo?"

# game/days2.rpy:164
translate Paloslios day2_53683ab0:

    # "My eyes hovered over to Alan."
    "Mis ojos se posaron en Alan."

# game/days2.rpy:165
translate Paloslios day2_80fbcc0f:

    # "His annoyed face now brightened when I mentioned him."
    "Su rostro molesto ahora se iluminó cuando lo mencioné."

# game/days2.rpy:169
translate Paloslios day2_6fe57ecb:

    # "Although, once I took my eyes off of him, I could’ve sworn that his smile dropped once again."
    "Aunque, una vez que le quité los ojos de encima, podría haber jurado que su sonrisa desapareció una vez más."

# game/days2.rpy:171
translate Paloslios day2_71d4f26f:

    # e "As long as you get your hermit ass over here, I don’t see the harm."
    e "Mientras traigas tu trasero ermitaño aquí, no veo ningún daño."

# game/days2.rpy:173
translate Paloslios day2_bcf3395d:

    # e "Don’t be late or I’ll end up ditching ya."
    e "No llegues tarde o terminaré dejándote."

# game/days2.rpy:175
translate Paloslios day2_e9bb2018:

    # "I couldn’t tell if she was joking or not. She has a strange sense of humor that sometimes flew over my head."
    "No podía decir si estaba bromeando o no. Tiene un extraño sentido del humor que a veces me pasaba por la cabeza."

# game/days2.rpy:178
translate Paloslios day2_c88f36fa:

    # "We both hung up and I looked back to Alan. His displeased face was replaced by a curious one."
    "Ambos colgamos y miré a Alan. Su cara de disgusto fue reemplazada por una de curiosidad."

# game/days2.rpy:180
translate Paloslios day2_741395d9:

    # a "Woah…"
    a "Vaya..."

# game/days2.rpy:182
translate Paloslios day2_82a4e2f7:

    # "He appeared to be looking at my phone."
    "Parecía estar mirando mi teléfono."

# game/days2.rpy:184
translate Paloslios day2_07a093bd:

    # a "Guess I have been gone for a while…"
    a "Supongo que me fui por un tiempo..."

# game/days2.rpy:186
translate Paloslios day2_82cb5263:

    # u "What? My phone? You’ve never seen a phone before?"
    u "¿Qué? ¿Mi teléfono? ¿Nunca antes has visto un teléfono?"

# game/days2.rpy:188
translate Paloslios day2_6fa7c2c6:

    # a "Oh no, not that. I do have a phone but…"
    a "Ah no, eso no. Tengo un teléfono pero..."

# game/days2.rpy:190
translate Paloslios day2_a8af7a37:

    # "Alan proceeds to reach in his back pocket, pulling something out."
    "Alan procede a buscar en su bolsillo trasero y saca algo."

# game/days2.rpy:192
translate Paloslios day2_89030e0c:

    # "It was a phone. An old flip phone. I haven’t seen these bricks for what seemed like forever!"
    "Era un teléfono. Un viejo teléfono plegable. ¡No he visto estos ladrillos desde hace lo que me pareció una eternidad!"

# game/days2.rpy:194
translate Paloslios day2_8c57416d:

    # a "Mine isn’t as cool as yours."
    a "El mío no es tan genial como el tuyo."

# game/days2.rpy:198
translate Paloslios day2_65896f11:

    # "He smiled bashfully before putting his phone away."
    "Sonrió tímidamente antes de guardar su teléfono."

# game/days2.rpy:200
translate Paloslios day2_efe394bb:

    # u "Wow. You need to get caught up with the current times, Alan. Our phones do much more stuff now."
    u "Guau. Necesitas ponerte al día con los tiempos actuales, Alan. Nuestros teléfonos hacen muchas más cosas ahora."

# game/days2.rpy:204
translate Paloslios day2_2d9cf1c3:

    # a "Aaah."
    a "Aaah."

# game/days2.rpy:206
translate Paloslios day2_29d74a18:

    # a "That’s incredible…"
    a "Eso es increíble…"

# game/days2.rpy:208
translate Paloslios day2_8141b649:

    # "We both started to walk to the park, as I showed him all the apps I had."
    "Ambos comenzamos a caminar hacia el parque, mientras le mostraba todas las aplicaciones que tenía."

# game/days2.rpy:209
translate Paloslios day2_c0a82ae2:

    # "Being in the woods, there wasn’t any steady signal so showing him any type of social media was thrown out the window."
    "Al estar en el bosque, no había ninguna señal constante, por lo que mostrarle cualquier tipo de red social fue arrojado por la ventana."

# game/days2.rpy:211
translate Paloslios day2_b1378270:

    # "Nevertheless, he was still impressed as I bombarded him with this new information."
    "Sin embargo, todavía quedó impresionado cuando lo bombardeé con esta nueva información."

# game/days2.rpy:213
translate Paloslios day2_b7c02b6c:

    # "If what he said was true, then he must’ve been off of society for a long time. A really long time."
    "Si lo que dijo era cierto, entonces debió haber estado alejado de la sociedad durante mucho tiempo. Mucho tiempo."

# game/days2.rpy:215
translate Paloslios day2_839d3ea0:

    # "Why was he in the woods? What happened to him?"
    "¿Por qué estaba en el bosque? ¿Qué le pasó?"

# game/days2.rpy:217
translate Paloslios day2_181195ed:

    # "I did not realize that huge scar on his arm… Were those… Stitches?"
    "No me di cuenta de esa enorme cicatriz en su brazo… ¿Eran esos… puntos?"

# game/days2.rpy:219
translate Paloslios day2_ce617998_2:

    # "…"
    "…"

# game/days2.rpy:221
translate Paloslios day2_7e8ae2c5:

    # "Oh god Alan… What happened to you?"
    "Oh dios Alan… ¿Qué te pasó?"

# game/days2.rpy:230
translate Paloslios day2_3ac9b70c:

    # "Both me and Alan continued to talk about our day as we made our way to the park."
    "Tanto Alan como yo continuamos hablando sobre nuestro día mientras nos dirigíamos al parque."

# game/days2.rpy:231
translate Paloslios day2_3c1d57d3:

    # "I wonder why Erika wanted me to come. We didn’t have to study or do anything class related, which is what she usually calls me for-"
    "Me pregunto por qué Erika quería que viniera. No tuvimos que estudiar ni hacer nada relacionado con las clases, que es por lo que ella suele llamarme."

# game/days2.rpy:233
translate Paloslios day2_dd9bf531:

    # "She told me that she doesn't usually date classmates or hang out with them outside of class because, well..."
    "Me dijo que no suele salir con compañeros de clase ni salir con ellos fuera de clase porque, bueno..."

# game/days2.rpy:235
translate Paloslios day2_f93abbdf:

    # "'Too many guys thought they had a chance of borrowing my bras and were disappointed after I had the gall to reject them,'."
    "\"Demasiados chicos pensaron que tenían la oportunidad de tomar prestados mis sujetadores y se decepcionaron cuando tuve el descaro de rechazarlos\"."

# game/days2.rpy:237
translate Paloslios day2_920691b3:

    # "Yikes."
    "Vaya."

# game/days2.rpy:240
translate Paloslios day2_ee4940fd:

    # "Made me wonder why she decided to approach me in the first place."
    "Me hizo preguntarme por qué decidió acercarse a mí en primer lugar."

# game/days2.rpy:243
translate Paloslios day2_b0e4d895:

    # "Probably why she decided to approach me rather than any of the male classmates."
    "Probablemente por eso decidió acercarse a mí en lugar de a cualquiera de los compañeros varones."

# game/days2.rpy:245
translate Paloslios day2_f9e64bbf:

    # s "[name]!"
    s "[name]!"

# game/days2.rpy:247
translate Paloslios day2_1c961627:

    # "A voice I didn’t recognize called my name."
    "Una voz que no reconocí dijo mi nombre."

# game/days2.rpy:254
translate Paloslios day2_ce7a21e8:

    # "Alan puts on a displeased look, his eyes watching the other side of the park."
    "Alan pone una mirada de disgusto, con los ojos mirando al otro lado del parque."

# game/days2.rpy:254
translate Paloslios day2_a30b90cc:

    # "I could see two people, one I could immediately recognize as Erika. The other person, however… I’ve never seen him before…"
    "Pude ver a dos personas, una que inmediatamente reconocí como Erika. La otra persona, sin embargo… nunca lo había visto antes…"

# game/days2.rpy:254
translate Paloslios day2_ad5566a5:

    # "How did he know my name?"
    "¿Cómo supo mi nombre?"

# game/days2.rpy:270
translate Paloslios day2_7f26f72d:

    # s "Oh my god, [name]!"
    s "¡Dios mío, [name]!"

# game/days2.rpy:272
translate Paloslios day2_94be250f:

    # u "Uh… Hi…"
    u "Eh... Hola..."

# game/days2.rpy:274
translate Paloslios day2_4dcb6bff:

    # "This guy was sure… Eccentric…"
    "Este tipo estaba seguro... Excéntrico..."

# game/days2.rpy:276
translate Paloslios day2_a4d8647a:

    # "From the tone of my voice, he could tell I was confused."
    "Por el tono de mi voz, se dio cuenta de que estaba confundida."

# game/days2.rpy:280
translate Paloslios day2_455d677f:

    # s "Do you not… Remember me?"
    s "¿No… te acuerdas de mí?"

# game/days2.rpy:282
translate Paloslios day2_342830ea:

    # "He sounded kinda disappointed."
    "Parecía un poco decepcionado."

# game/days2.rpy:284
translate Paloslios day2_0eeb4aa4:

    # "Geez dude, now you’re making me feel bad."
    "Dios mío, ahora me estás haciendo sentir mal."

# game/days2.rpy:286
translate Paloslios day2_2e008707:

    # "I gave him a good long look, the hamster wheels in my head beginning to move. Actually…"
    "Le di una buena mirada y las ruedas de hámster en mi cabeza comenzaron a moverse. En realidad…"

# game/days2.rpy:288
translate Paloslios day2_ca34614e:

    # u "… Stu?"
    u "… ¿Stu?"

# game/days2.rpy:292
translate Paloslios day2_cec3ae41:

    # "The guy gave me a smile and a wink."
    "El chico me dio una sonrisa y un guiño."

# game/days2.rpy:296
translate Paloslios day2_3596cf58:

    # s "Right on!"
    s "¡Tocar el asunto exacto!"

# game/days2.rpy:298
translate Paloslios day2_c7513b09:

    # "Oh my god… It was him!"
    "Dios mío… ¡Era él!"

# game/days2.rpy:302
translate Paloslios day2_4307ee93:

    # e "I could see the life nearly draining out of his eyes."
    e "Pude ver la vida casi desapareciendo de sus ojos."

# game/days2.rpy:308
translate Paloslios day2_f7986cc4:

    # "I could barely hold my excitement in."
    "Apenas pude contener mi emoción."

# game/days2.rpy:310
translate Paloslios day2_12af9198:

    # "Stu was a good friend of mine back since we were kids."
    "Stu era un buen amigo mío desde que éramos niños."

# game/days2.rpy:311
translate Paloslios day2_b4416bab:

    # "Even before the two of us attended school together, we knew each other."
    "Incluso antes de que los dos asistiéramos juntos a la escuela, nos conocíamos."

# game/days2.rpy:312
translate Paloslios day2_54df3184:

    # "It was when I left for college, we kinda lost touch."
    "Fue cuando me fui a la universidad que perdimos el contacto."

# game/days2.rpy:314
translate Paloslios day2_335e8090:

    # u "Why couldn’t you just greet me yourself, you bozo?"
    u "¿Por qué no pudiste saludarme tú mismo, idiota?"

# game/days2.rpy:318
translate Paloslios day2_855b393c:

    # s "I wanted to surprise you!"
    s "¡Quería sorprenderte!"

# game/days2.rpy:322
translate Paloslios day2_74c75fc6:

    # "What a guy! He always had something up his sleeve."
    "¡Qué tipo! Siempre tenía algo bajo la manga."

# game/days2.rpy:323
translate Paloslios day2_b210233d:

    # "He seemed quite as pleased as I was. I didn’t think I would’ve missed him so much!"
    "Parecía tan contento como yo. ¡No pensé que lo extrañaría tanto!"

# game/days2.rpy:325
translate Paloslios day2_df3a2857:

    # u "Oh I totally forgot!"
    u "¡Oh, lo olvidé por completo!"

# game/days2.rpy:327
translate Paloslios day2_eadda2ce:

    # "I have been so caught up with Stu and Erika, I seemed to have just left Alan out of the conversation."
    "He estado tan absorto con Stu y Erika que parecía haber dejado a Alan fuera de la conversación."

# game/days2.rpy:331
translate Paloslios day2_b024ec02:

    # "However, by the look of his face, it didn’t appear that he wanted to be a part of this."
    "Sin embargo, por la expresión de su rostro, no parecía que quisiera ser parte de esto."

# game/days2.rpy:333
translate Paloslios day2_97f7c670:

    # "I kinda felt bad."
    "Me sentí un poco mal."

# game/days2.rpy:335
translate Paloslios day2_a2ebcd9f:

    # u "This is Alan!"
    u "¡Este es Alan!"

# game/days2.rpy:339
translate Paloslios day2_09fbd232:

    # a "… Hey."
    a "… Ey."

# game/days2.rpy:341
translate Paloslios day2_d5d1452f:

    # "His tone was very…"
    "Su tono era muy..."

# game/days2.rpy:343
translate Paloslios day2_070d84e2:

    # "Uninterested."
    "Desinteresado."

# game/days2.rpy:345
translate Paloslios day2_de5fe89a:

    # "The three remained silent after Alan greeted himself."
    "Los tres permanecieron en silencio después de que Alan se saludara."

# game/days2.rpy:347
translate Paloslios day2_db8c9dd0:

    # "Erika had this look in her eye."
    "Erika tenía esta mirada en sus ojos."

# game/days2.rpy:348
translate Paloslios day2_42c6c175:

    # "I couldn’t tell what she was thinking but she appeared to be deep in thought."
    "No podía decir lo que estaba pensando, pero parecía estar sumida en sus pensamientos."

# game/days2.rpy:350
translate Paloslios day2_a20cefa7:

    # "..."
    "..."

# game/days2.rpy:352
translate Paloslios day2_991fa329:

    # "PLEASE somebody break this silence!"
    "¡POR FAVOR alguien rompa este silencio!"

# game/days2.rpy:358
translate Paloslios day2_8835336d:

    # "Holy shit this is SO not going as planned."
    "Mierda, esto no va según lo planeado."

# game/days2.rpy:359
translate Paloslios day2_8d60a0bf:

    # "The uncomfortable air was beginning to be too much for me. "
    "El aire incómodo empezaba a ser demasiado para mí. "

# game/days2.rpy:360
translate Paloslios day2_e2abd5e3:

    # "I heaved out a shaky breath."
    "Solté un suspiro tembloroso."

# game/days2.rpy:361
translate Paloslios day2_32116da1:

    # "Then another…"
    "Luego otro…"

# game/days2.rpy:362
translate Paloslios day2_38aab5f9:

    # "And another…"
    "Y otro…"

# game/days2.rpy:364
translate Paloslios day2_015b7b44:

    # "It was at this point, Alan took hold of me, with a stern look on his face."
    "Fue en ese momento que Alan me agarró, con una expresión severa en su rostro."

# game/days2.rpy:370
translate Paloslios day2_45592ab2:

    # "Without a word, he took me away from the park."
    "Sin decir palabra me sacó del parque."

# game/days2.rpy:371
translate Paloslios day2_291a427f:

    # "He wrapped his arms around me protectively."
    "Me rodeó con sus brazos protectoramente."

# game/days2.rpy:372
translate Paloslios day2_84e4d8df:

    # "I can’t explain why, but him being so close to me like this brought me comfort."
    "No puedo explicar por qué, pero el hecho de que él estuviera tan cerca de mí me reconfortó."

# game/days2.rpy:375
translate Paloslios day2_25179ff1:

    # "He gave me a comforting smile, which I also returned."
    "Me dedicó una sonrisa reconfortante, que yo también le devolví."

# game/days2.rpy:377
translate Paloslios day2_db971cf0:

    # e "Wait! [name]!"
    e "¡Esperar! [name]!"

# game/days2.rpy:385
translate Paloslios day2_06196f63:

    # "I looked back, seeing Erika running up to me, Stu right behind her."
    "Miré hacia atrás y vi a Erika corriendo hacia mí, con Stu justo detrás de ella."

# game/days2.rpy:386
translate Paloslios day2_8cc8ba62:

    # "I do feel bad for leaving them behind at the drop of a hat."
    "Me siento mal por dejarlos atrás en un abrir y cerrar de ojos."

# game/days2.rpy:387
translate Paloslios day2_2b1094ad:

    # "Alan looked at me, shaking his head disapprovingly, as if telling me that talking to them wasn’t worth it."
    "Alan me miró y sacudió la cabeza con desaprobación, como si me dijera que no valía la pena hablar con ellos."

# game/days2.rpy:393
translate Paloslios day2_3472a327:

    # "I broke eye contact with them, Alan’s grip getting tighter around my shoulders and we continued to walk back."
    "Rompí el contacto visual con ellos, el agarre de Alan se hizo más fuerte alrededor de mis hombros y continuamos caminando de regreso."

# game/days2.rpy:394
translate Paloslios day2_8f2638cd:

    # "Where? I’m not sure."
    "¿Dónde? No estoy seguro."

# game/days2.rpy:396
translate Paloslios day2_1b026d87:

    # "I just wanted to leave."
    "Sólo quería irme."

# game/days2.rpy:399
translate Paloslios day2_21b2aa1a:

    # "I can’t just leave them like this."
    "No puedo simplemente dejarlos así."

# game/days2.rpy:404
translate Paloslios day2_c097a1c9:

    # "I gave them a reassuring smile, which they both returned."
    "Les di una sonrisa tranquilizadora, que ambos me devolvieron."

# game/days2.rpy:406
translate Paloslios day2_e65f564d:

    # u "I’ll be fine… Don’t worry about me… I’ll see you guys around…"
    u "Estaré bien... No se preocupen por mí... Los veré por ahí..."

# game/days2.rpy:408
translate Paloslios day2_3033124a:

    # "They seemed worried for me, but still respected my decision."
    "Parecían preocupados por mí, pero aun así respetaron mi decisión."

# game/days2.rpy:413
translate Paloslios day2_00a89ce4:

    # "Great! Looks like it's up to me."
    "¡Excelente! Parece que depende de mí."

# game/days2.rpy:415
translate Paloslios day2_c087ee4e:

    # u "So wait-"
    u "Así que espera-"

# game/days2.rpy:421
translate Paloslios day2_04e05f3b:

    # "All three of them looked at me once I spoke up."
    "Los tres me miraron una vez que hablé."

# game/days2.rpy:423
translate Paloslios day2_baebf5a5:

    # u "How did you and Erika even know each other?"
    u "¿Cómo se conocieron Erika y tú?"

# game/days2.rpy:425
translate Paloslios day2_6a2a2496:

    # "Stu remained silent but Erika spoke up for him."
    "Stu permaneció en silencio pero Erika habló por él."

# game/days2.rpy:431
translate Paloslios day2_545d34e2:

    # e "Oh. He approached me after seeing me talking to you after class, saying that he knew you."
    e "Oh. Se acercó a mí después de verme hablando contigo después de clase y me dijo que te conocía."

# game/days2.rpy:435
translate Paloslios day2_d6913644:

    # "I was a bit stunned. Did Stu go to the same college as me and Erika did?"
    "Me quedé un poco atónito. ¿Stu fue a la misma universidad que Erika y yo?"

# game/days2.rpy:439
translate Paloslios day2_aa458514:

    # a "That’s a bit questionable."
    a "Eso es un poco cuestionable."

# game/days2.rpy:441
translate Paloslios day2_29345f9c:

    # "Alan spoke up, it was a little startling, since he has only said one word in the entire conversation."
    "Alan habló, fue un poco sorprendente, ya que solo ha dicho una palabra en toda la conversación."

# game/days2.rpy:447
translate Paloslios day2_7b35d444:

    # "Erika only eyes him, whilst Stu seems to become stiff. Things seemed to have gotten a bit out of hand now…"
    "Erika sólo lo mira, mientras Stu parece ponerse rígido. Las cosas parecían haberse ido un poco de control ahora..."

# game/days2.rpy:451
translate Paloslios day2_99afef8d:

    # a "Why didn’t you just approach [name] in the first place?"
    a "¿Por qué no te acercaste a [name] en primer lugar?"

# game/days2.rpy:453
translate Paloslios day2_a8708508:

    # "That’s true… Why didn’t he? Stu was always the type make the first move when greeting someone."
    "Eso es verdad… ¿Por qué no lo hizo? Stu siempre fue del tipo que da el primer paso cuando saluda a alguien."

# game/days2.rpy:457
translate Paloslios day2_499319de:

    # s "H-Hey now- It’s a little rude to intrude on someone when you’ve first met, don't cha think, big guy?"
    s "H-Oye, es un poco de mala educación entrometerse con alguien cuando te conoces por primera vez, ¿no crees, grandullón?"

# game/days2.rpy:461
translate Paloslios day2_56ee14ff:

    # a "You’re avoiding the question."
    a "Estás evitando la pregunta."

# game/days2.rpy:463
translate Paloslios day2_b4bce3a2:

    # "The two were now staring each other down."
    "Los dos ahora se miraban fijamente."

# game/days2.rpy:467
translate Paloslios day2_a31d5e49:

    # "Me and Erika looked at each other, as if we both read each other’s minds, plagued with worry."
    "Erika y yo nos miramos, como si ambos nos leyéramos la mente, plagados de preocupación."

# game/days2.rpy:469
translate Paloslios day2_bfacd997:

    # "Surprisingly, Erika stepped in."
    "Sorprendentemente, Erika intervino."

# game/days2.rpy:471
translate Paloslios day2_805d6321:

    # "Thank god."
    "Gracias a dios."

# game/days2.rpy:475
translate Paloslios day2_407f1e01:

    # e "If you really wanna know, he approached me first because-"
    e "Si realmente quieres saberlo, él se acercó a mí primero porque..."

# game/days2.rpy:477
translate Paloslios day2_a159d4f6:

    # e "He was asking for my number."
    e "Me estaba pidiendo mi número."

# game/days2.rpy:479
translate Paloslios day2_7d106bb8:

    # "That makes more sense."
    "Eso tiene más sentido."

# game/days2.rpy:481
translate Paloslios day2_542e458e:

    # u "Oh. I see…"
    u "Oh. Ya veo..."

# game/days2.rpy:485
translate Paloslios day2_5fb13fd2:

    # s "What? [name]!"
    s "¿Qué? [name]!"

# game/days2.rpy:487
translate Paloslios day2_e143e497:

    # u "No, I get it… I’ll see ya around then, Stu."
    u "No, lo entiendo… Nos vemos entonces, Stu."

# game/days2.rpy:491
translate Paloslios day2_5bff22ca:

    # "It was at this point, Alan took hold of me, with a satisfied look on his face."
    "Fue en ese momento que Alan me agarró, con una expresión de satisfacción en su rostro."

# game/days2.rpy:497
translate Paloslios day2_45592ab2_1:

    # "Without a word, he took me away from the park."
    "Sin decir palabra me sacó del parque."

# game/days2.rpy:498
translate Paloslios day2_291a427f_1:

    # "He wrapped his arms around me protectively."
    "Me rodeó con sus brazos protectoramente."

# game/days2.rpy:499
translate Paloslios day2_84e4d8df_1:

    # "I can’t explain why, but him being so close to me like this brought me comfort."
    "No puedo explicar por qué, pero el hecho de que él estuviera tan cerca de mí me reconfortó."

# game/days2.rpy:502
translate Paloslios day2_25179ff1_1:

    # "He gave me a comforting smile, which I also returned."
    "Me dedicó una sonrisa reconfortante, que yo también le devolví."

# game/days2.rpy:508
translate Paloslios day2_b32b6340:

    # s "[name]! Wait!"
    s "[name]! ¡Esperar!"

# game/days2.rpy:510
translate Paloslios day2_06196f63_1:

    # "I looked back, seeing Erika running up to me, Stu right behind her."
    "Miré hacia atrás y vi a Erika corriendo hacia mí, con Stu justo detrás de ella."

# game/days2.rpy:511
translate Paloslios day2_8cc8ba62_1:

    # "I do feel bad for leaving them behind at the drop of a hat."
    "Me siento mal por dejarlos atrás en un abrir y cerrar de ojos."

# game/days2.rpy:514
translate Paloslios day2_2b1094ad_1:

    # "Alan looked at me, shaking his head disapprovingly, as if telling me that talking to them wasn’t worth it."
    "Alan me miró y sacudió la cabeza con desaprobación, como si me dijera que no valía la pena hablar con ellos."

# game/days2.rpy:516
translate Paloslios day2_a0c4693d:

    # s "Let me explain myself, please!"
    s "¡Déjame explicarme, por favor!"

# game/days2.rpy:523
translate Paloslios day2_3472a327_1:

    # "I broke eye contact with them, Alan’s grip getting tighter around my shoulders and we continued to walk back."
    "Rompí el contacto visual con ellos, el agarre de Alan se hizo más fuerte alrededor de mis hombros y continuamos caminando de regreso."

# game/days2.rpy:524
translate Paloslios day2_8f2638cd_1:

    # "Where? I’m not sure."
    "¿Dónde? No estoy seguro."

# game/days2.rpy:526
translate Paloslios day2_1b026d87_1:

    # "I just wanted to leave."
    "Sólo quería irme."

# game/days2.rpy:529
translate Paloslios day2_a32545bb:

    # "I couldn’t leave him like this, he was my friend."
    "No podía dejarlo así, era mi amigo."

# game/days2.rpy:530
translate Paloslios day2_2f024882:

    # "My first ever friend."
    "Mi primer amigo."

# game/days2.rpy:532
translate Paloslios day2_91796455:

    # u "Alright, Stu. Go ahead."
    u "Muy bien, Stu. Adelante."

# game/days2.rpy:536
translate Paloslios day2_4314178e:

    # "He side eyed, looking to the ground and fiddling with the pockets of his pants."
    "Miró de reojo, mirando al suelo y jugueteando con los bolsillos de sus pantalones."

# game/days2.rpy:538
translate Paloslios day2_4a277866:

    # s "L-Listen, Erika worded it weird…"
    s "L-Escucha, Erika lo expresó raro..."

# game/days2.rpy:539
translate Paloslios day2_5168162c:

    # s "I know that back then I wasn’t… Well-"
    s "Sé que en aquel entonces yo no era… Bueno-"

# game/days2.rpy:540
translate Paloslios day2_9db3245d:

    # s "What I mean is that, please don’t perceive me in that type of way…"
    s "Lo que quiero decir es que, por favor, no me perciban de ese tipo de manera..."

# game/days2.rpy:541
translate Paloslios day2_03ce6d24:

    # s "I really just wanted to see you-"
    s "Realmente solo quería verte-"

# game/days2.rpy:543
translate Paloslios day2_92c352af:

    # u "I heard enough Stu…"
    u "Escuché suficiente Stu..."

# game/days2.rpy:545
translate Paloslios day2_229071cb:

    # "I gave him a reassuring smile."
    "Le di una sonrisa tranquilizadora."

# game/days2.rpy:546
translate Paloslios day2_78ac4644:

    # "Remembering Stu back then, he was kinda a flirt with everyone."
    "Recordando a Stu en aquel entonces, él era un poco coqueto con todos."

# game/days2.rpy:547
translate Paloslios day2_a3a18451:

    # "It shouldn’t surprise me that he tried to get with Erika."
    "No debería sorprenderme que intentara ligar con Erika."

# game/days2.rpy:548
translate Paloslios day2_26d75e72:

    # "I don’t know if I got upset at Stu for still getting into his old ways or that I got upset that he was flirting with Erika."
    "No sé si me enojé con Stu por seguir con sus viejas costumbres o si me enojó porque estaba coqueteando con Erika."

# game/days2.rpy:554
translate Paloslios day2_bc99a8cf:

    # "Even back then it bothered me and I didn’t know why."
    "Incluso entonces me molestaba y no sabía por qué."

# game/days2.rpy:555
translate Paloslios day2_06d1e510:

    # "Maybe because he was my friend, and every time he had a “fling”, I couldn’t get to hang out with him."
    "Tal vez porque era mi amigo y cada vez que tenía una “aventura”, no podía salir con él."

# game/days2.rpy:558
translate Paloslios day2_63d79590:

    # "Erika was my friend, and although I didn’t know her very well, it was kinda embarrassing that she had to meet Stu that way."
    "Erika era mi amiga y, aunque no la conocía muy bien, era un poco vergonzoso que tuviera que conocer a Stu de esa manera."

# game/days2.rpy:561
translate Paloslios day2_5c04c72b:

    # "And I don’t care. I just want to get this feeling off my chest."
    "Y no me importa. Sólo quiero sacarme este sentimiento del pecho."

# game/days2.rpy:563
translate Paloslios day2_b8628e04:

    # "I breathed out, still smiling at the two."
    "Exhalé, todavía sonriéndoles a los dos."

# game/days2.rpy:565
translate Paloslios day2_12afbcd0:

    # u "I know you’re trying your best."
    u "Sé que estás haciendo tu mejor esfuerzo."

# game/days2.rpy:567
translate Paloslios day2_1eb4e2ec:

    # s "… I am."
    s "… Soy."

# game/days2.rpy:569
translate Paloslios day2_2b47a79a:

    # "He said it so seriously but yet with so much sincerity."
    "Lo dijo muy en serio pero con tanta sinceridad."

# game/days2.rpy:571
translate Paloslios day2_daea0508:

    # "And with that, I left with Alan."
    "Y dicho esto, me fui con Alan."

# game/days2.rpy:581
translate Paloslios day2_6287cba5:

    # "I tried to relax… Tried to distract myself…"
    "Intenté relajarme... Intenté distraerme..."

# game/days2.rpy:581
translate Paloslios day2_9cdbe8f6:

    # "I was bundled into a ball at the end of my couch, Alan sitting on the other side."
    "Yo estaba hecho un ovillo al final de mi sofá, Alan sentado al otro lado."

# game/days2.rpy:581
translate Paloslios day2_87269406:

    # "The living room was dark, with only the light of the TV giving any life."
    "La sala de estar estaba a oscuras, solo la luz del televisor daba vida."

# game/days2.rpy:581
translate Paloslios day2_422f58a3:

    # "My attention wasn’t on the TV, however."
    "Sin embargo, mi atención no estaba en la televisión."

# game/days2.rpy:581
translate Paloslios day2_85ecb018:

    # "It was towards Alan."
    "Fue hacia Alan."

# game/days2.rpy:581
translate Paloslios day2_5bbe9795:

    # "His eyes stayed glued to the screen before he shifted them in my direction."
    "Sus ojos permanecieron pegados a la pantalla antes de moverlos en mi dirección."

# game/days2.rpy:581
translate Paloslios day2_c285bf0d:

    # "This is the second time I have been caught staring at him."
    "Esta es la segunda vez que me pillan mirándolo."

# game/days2.rpy:581
translate Paloslios day2_1de8da25:

    # "I averted my gaze immediately. I must’ve been weird to him."
    "Desvié la mirada inmediatamente. Debí haber sido raro con él."

# game/days2.rpy:600
translate Paloslios day2_f730115a:

    # a "You okay?"
    a "¿Estás bien?"

# game/days2.rpy:603
translate Paloslios day2_fe257af6:

    # u "I’m sorry…"
    u "Lo siento..."

# game/days2.rpy:605
translate Paloslios day2_8afb3608:

    # a "Are you still upset about what happened?"
    a "¿Sigues molesto por lo que pasó?"

# game/days2.rpy:607
translate Paloslios day2_2279da5a:

    # "I didn’t want to really answer, but my silence was deafening."
    "Realmente no quería responder, pero mi silencio fue ensordecedor."

# game/days2.rpy:609
translate Paloslios day2_25aa18cd:

    # u "I’m being stupid… Sorry… I don’t know why I got so upset… I couldn’t control it."
    u "Estoy siendo estúpido… Lo siento… No sé por qué me enojé tanto… No pude controlarlo."

# game/days2.rpy:613
translate Paloslios day2_6d7ee48b:

    # "I could see him softening his face at the corner of my eye."
    "Pude verlo suavizar su rostro por el rabillo del ojo."

# game/days2.rpy:614
translate Paloslios day2_acf0136a:

    # "I didn’t know why I started rambling to him, but I did."
    "No sabía por qué comencé a divagar con él, pero lo hice."

# game/days2.rpy:616
translate Paloslios day2_65d5d8cb:

    # "I suddenly felt a weight on top of me, I was being pushed down onto my back."
    "De repente sentí un peso encima de mí, me empujaban hacia abajo."

# game/days2.rpy:617
translate Paloslios day2_230bc57e:

    # "Alan had pinned me, his hands gently wrapping around my wrists."
    "Alan me había inmovilizado y sus manos rodearon suavemente mis muñecas."

# game/days2.rpy:619
translate Paloslios day2_b7808a8d:

    # a "[name]..."
    a "[name]..."

# game/days2.rpy:627
translate Paloslios day2_194b65c2:

    # a "You know you can tell me anything."
    a "Sabes que puedes contarme cualquier cosa."

# game/days2.rpy:633
translate Paloslios day2_4a8d0f9b:

    # u "Alan…"
    u "Alan..."

# game/days2.rpy:635
translate Paloslios day2_340ee3e6:

    # "My heart started to pound, and I felt him starting to come closer to my face."
    "Mi corazón comenzó a latir con fuerza y sentí que él comenzaba a acercarse a mi cara."

# game/days2.rpy:636
translate Paloslios day2_5aceb350:

    # "I went stiff…"
    "Me puse rígido..."

# game/days2.rpy:643
translate Paloslios day2_8c7efff3:

    # "I am not sure if I wanna continue whatever this was, But I know that I don’t want to let him go."
    "No estoy seguro de querer continuar, sea lo que sea, pero sé que no quiero dejarlo ir."

# game/days2.rpy:644
translate Paloslios day2_89329ba7:

    # "Even if it was for a bit."
    "Aunque fuera por un rato."

# game/days2.rpy:646
translate Paloslios day2_e2c28c08:

    # "My hand reaches out towards his face, my thumb rubbing across his cheek."
    "Mi mano se extiende hacia su rostro y mi pulgar frota su mejilla."

# game/days2.rpy:647
translate Paloslios day2_79208d3f:

    # "I could feel the rough patch of his scar."
    "Podía sentir la parte áspera de su cicatriz."

# game/days2.rpy:648
translate Paloslios day2_7c5785d7:

    # "He leaned into my touch, pressing his lips at the palm of my hand."
    "Se inclinó hacia mi toque, presionando sus labios en la palma de mi mano."

# game/days2.rpy:650
translate Paloslios day2_42697a1e:

    # "He seemed to get the idea that I didn't want to go any further."
    "Pareció entender que yo no quería ir más lejos."

# game/days2.rpy:651
translate Paloslios day2_210a81c0:

    # "He briefly smiled at me, only pulling me closer to his body and wrapping his arms around my waist."
    "Me sonrió brevemente, solo acercándome a su cuerpo y envolviendo sus brazos alrededor de mi cintura."

# game/days2.rpy:654
translate Paloslios day2_b283ce8d:

    # "I pressed my lips against his."
    "Presioné mis labios contra los suyos."

# game/days2.rpy:655
translate Paloslios day2_8a95fb8c:

    # "He seemed to be taken by surprise but leaned into our kiss."
    "Pareció tomado por sorpresa pero se inclinó hacia nuestro beso."

# game/days2.rpy:656
translate Paloslios day2_f52de9a2:

    # "It was deep and passionate. Alan then pressed up against me and I could immediately feel his…"
    "Fue profundo y apasionado. Alan luego se presionó contra mí y de inmediato pude sentir su..."

# game/days2.rpy:658
translate Paloslios day2_1ddd34fd:

    # "Excitement."
    "Emoción."

# game/days2.rpy:660
translate Paloslios day2_d47185a6:

    # a "I really like ya, doe-eyes…"
    a "Realmente me gustas, ojos de ciervo..."

# game/days2.rpy:662
translate Paloslios day2_804e4050:

    # "I shivered."
    "Me estremecí."

# game/days2.rpy:665
translate Paloslios day2_6d1dd52f:

    # "His breath tickled the lobe of my ear."
    "Su aliento me hizo cosquillas en el lóbulo de la oreja."

# game/days2.rpy:667
translate Paloslios day2_1b36d8b5:

    # a "You have no idea how you make me feel… Everytime I look at ya… My heart swells… It's like I wanna hold you and never let you go."
    a "No tienes idea de cómo me haces sentir... Cada vez que te miro... Mi corazón se hincha... Es como si quisiera abrazarte y nunca dejarte ir."

# game/days2.rpy:669
translate Paloslios day2_e1511e3e:

    # a "Ever."
    a "Alguna vez."

# game/days2.rpy:671
translate Paloslios day2_90176e19:

    # "His choice of words made me feel something."
    "Su elección de palabras me hizo sentir algo."

# game/days2.rpy:672
translate Paloslios day2_6e7d1e44:

    # "Although it sounded a tad possessive, he made me feel wanted and cared for."
    "Aunque sonó un poco posesivo, me hizo sentir querida y cuidada."

# game/days2.rpy:673
translate Paloslios day2_7399cc28:

    # "His hands start trailing from my wrists, making their way all over my body."
    "Sus manos comienzan a deslizarse desde mis muñecas, recorriendo todo mi cuerpo."

# game/days2.rpy:678
translate Paloslios day2_8c7efff3_1:

    # "I am not sure if I wanna continue whatever this was, But I know that I don’t want to let him go."
    "No estoy seguro de querer continuar, sea lo que sea, pero sé que no quiero dejarlo ir."

# game/days2.rpy:679
translate Paloslios day2_89329ba7_1:

    # "Even if it was for a bit."
    "Aunque fuera por un rato."

# game/days2.rpy:681
translate Paloslios day2_e2c28c08_1:

    # "My hand reaches out towards his face, my thumb rubbing across his cheek."
    "Mi mano se extiende hacia su rostro y mi pulgar frota su mejilla."

# game/days2.rpy:682
translate Paloslios day2_79208d3f_1:

    # "I could feel the rough patch of his scar."
    "Podía sentir la parte áspera de su cicatriz."

# game/days2.rpy:683
translate Paloslios day2_7c5785d7_1:

    # "He leaned into my touch, pressing his lips at the palm of my hand."
    "Se inclinó hacia mi toque, presionando sus labios en la palma de mi mano."

# game/days2.rpy:685
translate Paloslios day2_42697a1e_1:

    # "He seemed to get the idea that I didn't want to go any further."
    "Pareció entender que yo no quería ir más lejos."

# game/days2.rpy:686
translate Paloslios day2_39ccbafc:

    # "He briefly smiled at me, only pulling me closer to his body and wrapped his arms around my waist."
    "Me sonrió brevemente, solo acercándome a su cuerpo y envolviendo sus brazos alrededor de mi cintura."

# game/days2.rpy:689
translate Paloslios day2_e03faac8:

    # "Alan peppered kisses from my jaw to my collar."
    "Alan lanzó besos desde mi mandíbula hasta mi cuello."

# game/days2.rpy:691
translate Paloslios day2_108ba1f9:

    # a "Everything about you is perfect… I wanna treasure you…"
    a "Todo en ti es perfecto... quiero atesorarte..."

# game/days2.rpy:692
translate Paloslios day2_46de1faf:

    # a "You’re the only good person in my life…"
    a "Eres la única buena persona en mi vida..."

# game/days2.rpy:694
translate Paloslios day2_f2f12983:

    # "How could he even speak like this with no sweat?"
    "¿Cómo podía siquiera hablar así sin sudar?"

# game/days2.rpy:695
translate Paloslios day2_4c8da1c4:

    # "Just hearing those words made me look away in embarrassment."
    "Sólo escuchar esas palabras me hizo mirar hacia otro lado avergonzado."

# game/days2.rpy:697
translate Paloslios day2_60eb1665:

    # "I suddenly feel his hands take hold of my face, pulling me towards his direction."
    "De repente siento sus manos agarrar mi cara, jalándome hacia su dirección."

# game/days2.rpy:699
translate Paloslios day2_0800d805:

    # a "Look at me, doe-eyes… I want to see your reaction…"
    a "Mírame, ojos de cierva… quiero ver tu reacción…"

# game/days2.rpy:701
translate Paloslios day2_887fc19b:

    # "He shouldn’t be this good. Arousal started growing inside of me."
    "No debería ser tan bueno. La excitación comenzó a crecer dentro de mí."

# game/days2.rpy:703
translate Paloslios day2_6f75f019:

    # "One quick, swift motion, he hooked my pants and underwear to my ankles."
    "Con un movimiento rápido y veloz, enganchó mis pantalones y ropa interior a mis tobillos."

# game/days2.rpy:704
translate Paloslios day2_3bdee94f:

    # "His mouth was hungry and ravenous, leaving kisses at the exposed skin of my thighs."
    "Su boca estaba hambrienta y voraz, dejando besos en la piel expuesta de mis muslos."

# game/days2.rpy:706
translate Paloslios day2_38ed11a8:

    # "Then I felt something sharp…"
    "Entonces sentí algo agudo..."

# game/days2.rpy:708
translate Paloslios day2_a8d1f807:

    # u "Are you… biting me…?"
    u "¿Estás… mordiéndome…?"

# game/days2.rpy:710
translate Paloslios day2_556767bc:

    # "I didn’t get an answer, but I could feel the curling of a smirk forming against my inner thigh."
    "No obtuve una respuesta, pero pude sentir la curvatura de una sonrisa formándose contra la parte interna de mi muslo."

# game/days2.rpy:712
translate Paloslios day2_0903ec18:

    # "The only response was another bite, sinking his teeth deeper."
    "La única respuesta fue otro mordisco, hundiendo más los dientes."

# game/days2.rpy:714
translate Paloslios day2_ef304f21:

    # "He was trying to mark me. Multiple times."
    "Estaba tratando de marcarme. Varias veces."

# game/days2.rpy:716
translate Paloslios day2_09b5ad13:

    # a "You’re all ready just for me, is a few little bites all it takes, doe-eyes?"
    a "Estás listo solo para mí, ¿se necesitan unos cuantos bocaditos, ojos de cierva?"

# game/days2.rpy:718
translate Paloslios day2_fe4ec12d:

    # "He could've gotten a retort out of me, but I was stopped when he pulled up my hips towards his face and ran his tongue."
    "Podría haberme sacado una réplica, pero me detuve cuando levantó mis caderas hacia su cara y pasó su lengua."

# game/days2.rpy:720
translate Paloslios day2_87fb835d:

    # a "Who knew you would taste so sweet as well?"
    a "¿Quién sabía que tú también sabrías tan dulce?"

# game/days2.rpy:722
translate Paloslios day2_5d662130:

    # "His mouth started to work and in desperation, my own hands focused on running down to his head, where I took fistfuls of his brown hair."
    "Su boca comenzó a trabajar y, desesperada, mis propias manos se concentraron en correr hacia su cabeza, donde tomé puñados de su cabello castaño."

# game/days2.rpy:724
translate Paloslios day2_1f1fcf7e:

    # "The tiniest touch of his, whether it would be a graze of his fingertips, or his tongue, was pushing me a little closer to the edge."
    "El más mínimo toque suyo, ya fuera un roce con las yemas de sus dedos o con su lengua, me empujaba un poco más cerca del borde."

# game/days2.rpy:726
translate Paloslios day2_f594510e:

    # "I could feel the heat building up, like a low burn at the pit of my stomach."
    "Podía sentir el calor aumentando, como un ardor leve en la boca del estómago."

# game/days2.rpy:728
translate Paloslios day2_f2c738e5:

    # "He then detached himself."
    "Luego se separó."

# game/days2.rpy:730
translate Paloslios day2_21825f66:

    # u "A-Alan…?"
    u "¿A-Alan…?"

# game/days2.rpy:732
translate Paloslios day2_b0f87989:

    # a "I don’t wanna finish just yet, doe-eyes. I want {i}more{/i} of you…"
    a "No quiero terminar todavía, ojos de ciervo. Quiero {i}más{/i} de ti…"

# game/days2.rpy:734
translate Paloslios day2_50b7f298:

    # "He removed himself from me, hastily removing his clothes."
    "Se separó de mí, quitándose la ropa apresuradamente."

# game/days2.rpy:735
translate Paloslios day2_0282be49:

    # "It seemed that he was as desperate as I was."
    "Parecía que estaba tan desesperado como yo."

# game/days2.rpy:737
translate Paloslios day2_1622d1e5:

    # "I sure wasn’t complaining."
    "Seguro que no me estaba quejando."

# game/days2.rpy:739
translate Paloslios day2_37b89047:

    # "He got rid of his turtleneck, tossing it off to the side. My eyes couldn’t help but to wander to admire his bare chest."
    "Se deshizo de su jersey de cuello alto y lo arrojó a un lado. Mis ojos no pudieron evitar deambular para admirar su pecho desnudo."

# game/days2.rpy:741
translate Paloslios day2_e0fa7945:

    # "That is until…"
    "Eso es hasta..."

# game/days2.rpy:743
translate Paloslios day2_02468116_1:

    # u "Holy shit…"
    u "Santa mierda..."

# game/days2.rpy:745
translate Paloslios day2_fd1e5f9f:

    # "I saw a scar. A huge scar."
    "Vi una cicatriz. Una cicatriz enorme."

# game/days2.rpy:751
translate Paloslios day2_fae0a5cb:

    # "In fact, his whole body was covered in injuries."
    "De hecho, todo su cuerpo estaba cubierto de heridas."

# game/days2.rpy:752
translate Paloslios day2_1dc01999:

    # "He was in way worse shape than I expected. More scratches, cigar burns, and, again, the scar at the side of his abdomen."
    "Estaba en peor forma de lo que esperaba. Más rasguños, quemaduras de cigarro y, de nuevo, la cicatriz al costado de su abdomen."

# game/days2.rpy:753
translate Paloslios day2_4f7ef0a2:

    # "It didn’t look fresh but still, how long has he had these before?"
    "No parecía fresco, pero aun así, ¿cuánto tiempo hace que los tiene antes?"

# game/days2.rpy:755
translate Paloslios day2_84409801:

    # u "Alan, what happened to you?"
    u "Alan, ¿qué te pasó?"

# game/days2.rpy:759
translate Paloslios day2_f92c3a57:

    # a "Oh… These…"
    a "Oh… estos…"

# game/days2.rpy:761
translate Paloslios day2_3e7fba59:

    # "He looked away from my gaze, brushing one of his scars."
    "Apartó la mirada de mi mirada, rozando una de sus cicatrices."

# game/days2.rpy:763
translate Paloslios day2_30602658:

    # a "Some of these are from childhood. Others are more… recent…"
    a "Algunos de estos son de la infancia. Otros son más… recientes…"

# game/days2.rpy:765
translate Paloslios day2_045784da:

    # "We both stood silent with my concern still weighing down."
    "Ambos nos quedamos en silencio con mi preocupación aún pesando."

# game/days2.rpy:767
translate Paloslios day2_4c5ca315:

    # a "Don’t worry about it…"
    a "No te preocupes por eso…"

# game/days2.rpy:769
translate Paloslios day2_6e86b9e7:

    # u "Alan, {i}these{/i} are clearly not simple scratch marks. Are you hurt?"
    u "Alan, {i}estas{/i} claramente no son simples marcas de rasguños. ¿Estás herido?"

# game/days2.rpy:773
translate Paloslios day2_08b7272d:

    # a "It’s okay, doe-eyes! I swear, they didn’t even hurt!"
    a "¡Está bien, ojos de ciervo! ¡Lo juro, ni siquiera me dolieron!"

# game/days2.rpy:775
translate Paloslios day2_9538ef0b:

    # u "… What?"
    u "… ¿Qué?"

# game/days2.rpy:777
translate Paloslios day2_b83137af:

    # "What is he going on about?"
    "¿De qué está hablando?"

# game/days2.rpy:781
translate Paloslios day2_41a2d38c:

    # a "I’ll… I’ll explain later… Just… Please… Let’s keep going… I want you right now."
    a "Te... te lo explicaré más tarde... Sólo... Por favor... Sigamos... Te quiero ahora mismo."

# game/days2.rpy:783
translate Paloslios day2_adb04267:

    # "I shouldn’t push it if he doesn’t want to talk about it."
    "No debería presionarlo si él no quiere hablar de eso."

# game/days2.rpy:785
translate Paloslios day2_ff63a9cb:

    # u "Okay…"
    u "Está bien…"

# game/days2.rpy:789
translate Paloslios day2_cb445070:

    # a "It’s okay, Doe-eyes. You can relax with me…"
    a "Está bien, ojos de ciervo. Puedes relajarte conmigo..."

# game/days2.rpy:791
translate Paloslios day2_47f873b5:

    # "He was soon all over me again, positioning himself between my legs, his hands prying them open. I could feel him…"
    "Pronto estuvo sobre mí otra vez, colocándose entre mis piernas y sus manos abriéndolas. Podía sentirlo..."

# game/days2.rpy:793
translate Paloslios day2_d9ced2d0:

    # a "We can take it nice and slow. I want you to want me."
    a "Podemos tomárnoslo con calma y con calma. Quiero que me quieras."

# game/days2.rpy:795
translate Paloslios day2_3de79e0b:

    # "All in one go, I feel him buried inside til the hilt. I couldn’t help but let my breath hitch."
    "De una sola vez, lo siento enterrado por dentro hasta la empuñadura. No pude evitar dejar que se me cortara la respiración."

# game/days2.rpy:797
translate Paloslios day2_9cb5e1e0:

    # a "Ha… Filled you up pretty good, huh?"
    a "Ja... Te llenó bastante, ¿eh?"

# game/days2.rpy:799
translate Paloslios day2_352a5058:

    # "His hips began to move along with mine. The movement first started slow and quickly built up speed."
    "Sus caderas comenzaron a moverse junto con las mías. El movimiento comenzó lentamente y rápidamente fue ganando velocidad."

# game/days2.rpy:801
translate Paloslios day2_202dee31:

    # a "God you feel so good… Can you feel me? All the way in?"
    a "Dios, te sientes tan bien… ¿Puedes sentirme? ¿Hasta dentro?"

# game/days2.rpy:803
translate Paloslios day2_f0889dcc:

    # "His mouth went towards my neck, attacking any spot that might cause a reaction. Sure enough, he did."
    "Su boca se dirigió hacia mi cuello, atacando cualquier lugar que pudiera provocar una reacción. Efectivamente, lo hizo."

# game/days2.rpy:805
translate Paloslios day2_00ff51a4:

    # "He didn’t give me any time to process, but I don’t care anymore, I just wanted him. I needed him."
    "No me dio tiempo para procesarlo, pero ya no me importa, solo lo quería. Lo necesitaba."

# game/days2.rpy:807
translate Paloslios day2_1ae63e08:

    # a "Look at you… You look so amazing like this… I can’t believe-"
    a "Mírate... Te ves tan increíble así... No puedo creer-"

# game/days2.rpy:809
translate Paloslios day2_ccd67621:

    # "Each word he spoke was followed by a rough thrust."
    "Cada palabra que pronunció fue seguida por una estocada brusca."

# game/days2.rpy:810
translate Paloslios day2_4f2284dc:

    # "Each time I could feel my mind getting fuzzy."
    "Cada vez podía sentir que mi mente se volvía confusa."

# game/days2.rpy:812
translate Paloslios day2_79c5b498:

    # a "I can’t believe I get to keep you like this… You’re all mine."
    a "No puedo creer que pueda mantenerte así… Eres toda mía."

# game/days2.rpy:814
translate Paloslios day2_560273f9:

    # a "Mine."
    a "Mío."

# game/days2.rpy:816
translate Paloslios day2_1a3d86c6:

    # a "Mine…"
    a "Mío…"

# game/days2.rpy:818
translate Paloslios day2_ce617998_3:

    # "…"
    "…"

# game/days2.rpy:820
translate Paloslios day2_54e5a19f:

    # "I was his."
    "Yo era suyo."

# game/days2.rpy:822
translate Paloslios day2_249b71a3:

    # "All his."
    "Todo suyo."

# game/days2.rpy:824
translate Paloslios day2_cecb77c9:

    # "He was rough and I could see him baring his teeth, almost animalistic."
    "Era rudo y pude verlo enseñando los dientes, casi como un animal."

# game/days2.rpy:826
translate Paloslios day2_3cb19779:

    # a "Doe-eyes… I-I love you…!"
    a "Ojos de Cierva... ¡Te-te amo...!"

# game/days2.rpy:828
translate Paloslios day2_b3b7abf2:

    # "My mind went blank. He held me tightly as something warm began to fill me."
    "Mi mente se quedó en blanco. Me abrazó con fuerza mientras algo cálido comenzaba a llenarme."

# game/days2.rpy:830
translate Paloslios day2_c9b78c10:

    # "He grunts and we both lie sweating, catching our breaths."
    "Él gruñe y ambos nos quedamos sudando, recuperando el aliento."

# game/days2.rpy:832
translate Paloslios day2_42bdd910:

    # "My hand drifted up to his brown hair, and I slowly began to stroke it."
    "Mi mano se dirigió hacia su cabello castaño y lentamente comencé a acariciarlo."

# game/days2.rpy:834
translate Paloslios day2_83c2268b:

    # "We must’ve stayed for a good few minutes, holding each other."
    "Debimos habernos quedado unos buenos minutos, abrazados."

# game/days2.rpy:836
translate Paloslios day2_1adb81b9:

    # a "Hey. I got an idea."
    a "Ey. Tengo una idea."

# game/days2.rpy:838
translate Paloslios day2_a353bf40:

    # u "Do you plan robbing the convenience store again?"
    u "¿Planeas volver a robar la tienda de conveniencia?"

# game/days2.rpy:840
translate Paloslios day2_ccaaa25e:

    # "Alan got up from my chest, rolling his eyes."
    "Alan se levantó de mi pecho y puso los ojos en blanco."

# game/days2.rpy:842
translate Paloslios day2_c173485b:

    # a "I’ll leave that for another day. But no. I think you’ll like this {i}much{/i} better."
    a "Lo dejaré para otro día. Pero no. Creo que te gustará mucho más este {i}{/i}."

# game/days2.rpy:850
translate Paloslios day2_8f94a02e:

    # "He took my hand and guided me back to the woods."
    "Tomó mi mano y me guió de regreso al bosque."

# game/days2.rpy:852
translate Paloslios day2_2e2c5c50:

    # "It was a bit of a walk, like most of our little get-togethers, but for some reason, it felt longer than before."
    "Fue una caminata un poco larga, como la mayoría de nuestras pequeñas reuniones, pero por alguna razón, se sintió más larga que antes."

# game/days2.rpy:854
translate Paloslios day2_64b7976e:

    # "Gradually, the trees became sparse and patches of the night sky peaked through the branches."
    "Poco a poco, los árboles se fueron dispersando y fragmentos del cielo nocturno asomaban entre las ramas."

# game/days2.rpy:855
translate Paloslios day2_5dbea052:

    # "We were going uphill, having a bit of a hike on our way there. He seemed to have noticed that I was getting fatigued."
    "Íbamos cuesta arriba y hacíamos una pequeña caminata en el camino. Parecía haber notado que me estaba fatigando."

# game/days2.rpy:859
translate Paloslios day2_64aa8daf:

    # a "If you want I can carry you. It’s no bother."
    a "Si quieres te puedo llevar. No es ninguna molestia."

# game/days2.rpy:866
translate Paloslios day2_6db9d0d1:

    # u "I’m good! You don’t need to do anything."
    u "¡Estoy bien! No necesitas hacer nada."

# game/days2.rpy:868
translate Paloslios day2_1c1d90da:

    # "I would simply feel bad for making him carry me all the way up."
    "Simplemente me sentiría mal por obligarlo a cargarme hasta arriba."

# game/days2.rpy:871
translate Paloslios day2_75ceafc5:

    # "It seemed a little silly, but I wouldn’t mind. I raised my arms up, motioning him to pick me up."
    "Parecía un poco tonto, pero no me importaría. Levanté los brazos y le indiqué que me levantara."

# game/days2.rpy:873
translate Paloslios day2_a29a62f9:

    # "He smiled at me, and just as quickly, lifted my body, carrying me bridal style."
    "Me sonrió y, con la misma rapidez, levantó mi cuerpo, cargándome al estilo nupcial."

# game/days2.rpy:875
translate Paloslios day2_922edd1f:

    # a "You’re incredibly cute."
    a "Eres increíblemente lindo."

# game/days2.rpy:877
translate Paloslios day2_ce617998_4:

    # "…"
    "…"

# game/days2.rpy:879
translate Paloslios day2_495e4d21:

    # u "Shut up…"
    u "Cállate..."

# game/days2.rpy:881
translate Paloslios day2_6cbbaf00:

    # a "See?"
    a "¿Ves?"

# game/days2.rpy:889
translate Paloslios day2_0409c78e:

    # "We both lay down on the soft grass."
    "Ambos nos acostamos sobre la suave hierba."

# game/days2.rpy:890
translate Paloslios day2_86b2cf38:

    # "The sky was completely bare of any clouds and the darkness of the woods made the tiniest dots of the stars twinkle brighter."
    "El cielo estaba completamente desprovisto de nubes y la oscuridad del bosque hacía que los puntos más pequeños de las estrellas brillaran más."

# game/days2.rpy:891
translate Paloslios day2_19fd69eb:

    # "It was so nice and cool out here."
    "Era tan agradable y fresco aquí."

# game/days2.rpy:893
translate Paloslios day2_b90b6fa8:

    # "I looked over to Alan, eyes glowing with awe. It made me smile, seeing him like a kid in a candy store."
    "Miré a Alan, con los ojos brillando de asombro. Me hizo sonreír verlo como un niño en una tienda de dulces."

# game/days2.rpy:897
translate Paloslios day2_1f265f30:

    # a "What’s your favorite?"
    a "¿Cuál es tu favorito?"

# game/days2.rpy:901
translate Paloslios day2_75f284b8:

    # u "Hm?"
    u "¿Mmm?"

# game/days2.rpy:905
translate Paloslios day2_10bce5f4:

    # a "Constellation. I mean. What’s your favorite constellation?"
    a "Constelación. Quiero decir. ¿Cuál es tu constelación favorita?"

# game/days2.rpy:914
translate Paloslios day2_f0acf962:

    # u "I like Draco."
    u "Me gusta Draco."

# game/days2.rpy:918
translate Paloslios day2_5b4b74d3:

    # a "Aaah, that’s a good one! People often confuse it for the Big Dipper."
    a "¡Aaah, esa es buena! La gente suele confundirlo con la Osa Mayor."

# game/days2.rpy:922
translate Paloslios day2_b16a5c04:

    # u "Aren’t they kinda the same?"
    u "¿No son más o menos iguales?"

# game/days2.rpy:926
translate Paloslios day2_add5070b:

    # a "Not really. The Big Dipper is supposed to be a guide into finding Draco."
    a "No precisamente. Se supone que la Osa Mayor es una guía para encontrar a Draco."

# game/days2.rpy:931
translate Paloslios day2_8399a4af:

    # u "Pegasus!"
    u "¡Pegaso!"

# game/days2.rpy:935
translate Paloslios day2_783ea0e6:

    # a "Aah. That’s a good one! Did ya know you can find the Galaxy of Andromeda using that constellation?"
    a "Ah. ¡Esa es buena! ¿Sabías que puedes encontrar la galaxia de Andrómeda usando esa constelación?"

# game/days2.rpy:939
translate Paloslios day2_7eeee22c:

    # u "Really now?"
    u "¿De verdad ahora?"

# game/days2.rpy:943
translate Paloslios day2_2dda10cd:

    # a "Yeah! It’s hard to see obviously and it looks like a regular star through the naked eye, but it’s there!"
    a "¡Sí! Obviamente es difícil de ver y parece una estrella normal a simple vista, ¡pero está ahí!"

# game/days2.rpy:947
translate Paloslios day2_63955c52:

    # u "My favorite constellation is my Zodiac one."
    u "Mi constelación favorita es la del Zodíaco."

# game/days2.rpy:951
translate Paloslios day2_8728d848:

    # a "Really? Which one?"
    a "¿En realidad? ¿Cuál?"

# game/days2.rpy:961
translate Paloslios day2_78aabb6d:

    # a "That’s cool!"
    a "¡Eso es genial!"

# game/days2.rpy:965
translate Paloslios day2_78aabb6d_1:

    # a "That’s cool!"
    a "¡Eso es genial!"

# game/days2.rpy:969
translate Paloslios day2_78aabb6d_2:

    # a "That’s cool!"
    a "¡Eso es genial!"

# game/days2.rpy:973
translate Paloslios day2_78aabb6d_3:

    # a "That’s cool!"
    a "¡Eso es genial!"

# game/days2.rpy:977
translate Paloslios day2_78aabb6d_4:

    # a "That’s cool!"
    a "¡Eso es genial!"

# game/days2.rpy:981
translate Paloslios day2_78aabb6d_5:

    # a "That’s cool!"
    a "¡Eso es genial!"

# game/days2.rpy:985
translate Paloslios day2_78aabb6d_6:

    # a "That’s cool!"
    a "¡Eso es genial!"

# game/days2.rpy:989
translate Paloslios day2_78aabb6d_7:

    # a "That’s cool!"
    a "¡Eso es genial!"

# game/days2.rpy:993
translate Paloslios day2_78aabb6d_8:

    # a "That’s cool!"
    a "¡Eso es genial!"

# game/days2.rpy:997
translate Paloslios day2_04e775cb:

    # a "Oh! I’m a Capricorn too!"
    a "¡Oh! ¡Yo también soy Capricornio!"

# game/days2.rpy:1000
translate Paloslios day2_6a967504:

    # u "Huh… Neat!"
    u "Eh… ¡Genial!"

# game/days2.rpy:1003
translate Paloslios day2_079fd909:

    # a "Pretty neat."
    a "Bastante limpio."

# game/days2.rpy:1008
translate Paloslios day2_78aabb6d_9:

    # a "That’s cool!"
    a "¡Eso es genial!"

# game/days2.rpy:1012
translate Paloslios day2_78aabb6d_10:

    # a "That’s cool!"
    a "¡Eso es genial!"

# game/days2.rpy:1016
translate Paloslios day2_09239a6c:

    # u "I am not well known with my constellations."
    u "No soy muy conocido con mis constelaciones."

# game/days2.rpy:1020
translate Paloslios day2_d6b55ccf:

    # a "I can teach you if you would like! I almost know them like the back of my hand!"
    a "¡Puedo enseñarte si quieres! ¡Casi los conozco como la palma de mi mano!"

# game/days2.rpy:1024
translate Paloslios day2_b71ab806:

    # u "Yeah? Which one is {i}your{/i} favorite?"
    u "¿Sí? ¿Cuál es {i}tu{/i} favorito?"

# game/days2.rpy:1028
translate Paloslios day2_13184c8e:

    # a "Orion!"
    a "¡Orión!"

# game/days2.rpy:1032
translate Paloslios day2_10d427fb:

    # u "The hunter one? Why is that?"
    u "¿El cazador? ¿Porqué es eso?"

# game/days2.rpy:1035
translate Paloslios day2_3624780d:

    # a "The story behind it is cool."
    a "La historia detrás de esto es genial."

# game/days2.rpy:1038
translate Paloslios day2_0b35703e:

    # a "And I share the same last name."
    a "Y comparto el mismo apellido."

# game/days2.rpy:1042
translate Paloslios day2_f2defcad:

    # u "Alan Orion? That’s your full name?"
    u "¿Alan Orión? ¿Ese es tu nombre completo?"

# game/days2.rpy:1044
translate Paloslios day2_17fc30ed:

    # "Alan simply gave me a nod, sighing peacefully. Taking in the fresh air around us."
    "Alan simplemente asintió y suspiró pacíficamente. Tomando el aire fresco que nos rodea."

# game/days2.rpy:1046
translate Paloslios day2_a8ac4cc3:

    # u "You sure know a lot about constellations, huh?"
    u "Seguro que sabes mucho sobre constelaciones, ¿eh?"

# game/days2.rpy:1050
translate Paloslios day2_7f1ab3ce:

    # a "Yeah! Ever since I was a kid."
    a "¡Sí! Desde que era niño."

# game/days2.rpy:1053
translate Paloslios day2_fce3f938:

    # "This was probably the first thing I know something personal about him."
    "Probablemente esto fue lo primero que supe algo personal sobre él."

# game/days2.rpy:1054
translate Paloslios day2_b2444bd0:

    # "My eyes went from looking at the stars, to the stitched scar of his arm."
    "Mis ojos pasaron de mirar las estrellas a la cicatriz cosida de su brazo."

# game/days2.rpy:1056
translate Paloslios day2_4a8d0f9b_1:

    # u "Alan…"
    u "Alan..."

# game/days2.rpy:1058
translate Paloslios day2_32fb53c2:

    # a "Hm?"
    a "¿Mmm?"

# game/days2.rpy:1060
translate Paloslios day2_ff327f55:

    # u "About… Those scars…"
    u "Acerca de… Esas cicatrices…"

# game/days2.rpy:1064
translate Paloslios day2_7891e355:

    # a "Oh."
    a "Ah."

# game/days2.rpy:1066
translate Paloslios day2_2d234c15:

    # "I see his smile drop, and I immediately feel bad for bringing it up."
    "Veo que su sonrisa se desvanece e inmediatamente me siento mal por mencionarlo."

# game/days2.rpy:1067
translate Paloslios day2_4a87acbd:

    # u "I-I’m sorry! I know you probably don’t wanna talk about it but-"
    u "¡Lo-lo siento! Sé que probablemente no quieras hablar de eso, pero..."

# game/days2.rpy:1069
translate Paloslios day2_a473038f:

    # a "It’s okay. You’re just worried. About me, right?"
    a "Está bien. Sólo estás preocupado. Sobre mí, ¿verdad?"

# game/days2.rpy:1071
translate Paloslios day2_b8363d82:

    # "I give him a nod, laying on my side, looking over to him. I gave him a few moments for him to collect his thoughts."
    "Le doy un asiento, me acuesto de lado y lo miro. Le di unos momentos para que ordenara sus pensamientos."

# game/days2.rpy:1073
translate Paloslios day2_87600dd3:

    # "He finally spoke up."
    "Finalmente habló."

# game/days2.rpy:1077
translate Paloslios day2_092ff83d:

    # a "Well, to start off. Most of these scars are recent, only due to me and my recklessness."
    a "Bueno, para empezar. La mayoría de estas cicatrices son recientes, sólo debidas a mí y a mi imprudencia."

# game/days2.rpy:1081
translate Paloslios day2_a4eb1d36:

    # u "… Like?"
    u "… ¿Como?"

# game/days2.rpy:1085
translate Paloslios day2_ec466790:

    # a "Heh… Like trying to feed a bear…"
    a "Je... Como intentar alimentar a un oso..."

# game/days2.rpy:1089
translate Paloslios day2_4a8d0f9b_2:

    # u "Alan…"
    u "Alan..."

# game/days2.rpy:1093
translate Paloslios day2_ed292b04:

    # a "I know! I know! It was dumb!"
    a "¡Lo sé! ¡Lo sé! ¡Fue tonto!"

# game/days2.rpy:1097
translate Paloslios day2_6cb027f8:

    # u "Extremely dumb!"
    u "¡Extremadamente tonto!"

# game/days2.rpy:1099
translate Paloslios day2_9f266cb7:

    # "I lightly punched his arm, as if it was some sort of punishment for putting himself in danger like that. He only retaliated with a soft chuckle."
    "Le di un ligero puñetazo en el brazo, como si fuera algún tipo de castigo por ponerse en peligro de esa manera. Él sólo respondió con una suave risa."

# game/days2.rpy:1102
translate Paloslios day2_25bd0890:

    # "His smiled faded, however."
    "Sin embargo, su sonrisa se desvaneció."

# game/days2.rpy:1104
translate Paloslios day2_e649842c:

    # a "Not all of them are new though…"
    a "Aunque no todos son nuevos..."

# game/days2.rpy:1106
translate Paloslios day2_e8b1023b:

    # "He shifted uncomfortably. I gave him another moment."
    "Se movió incómodo. Le di otro momento."

# game/days2.rpy:1110
translate Paloslios day2_27e857ca:

    # a "I was kinda a troubled kid. Got bullied a lot and well… I got pretty tired of it that I got physical."
    a "Yo era un niño un poco problemático. Me acosaron mucho y bueno… me cansé bastante de eso y me puse físico."

# game/days2.rpy:1113
translate Paloslios day2_1141542c:

    # u "So… those cigarette burns were from your bullies?"
    u "Entonces... ¿esas quemaduras de cigarrillos fueron de tus matones?"

# game/days2.rpy:1117
translate Paloslios day2_1cb97019:

    # a "No. They were from my older brother."
    a "No. Eran de mi hermano mayor."

# game/days2.rpy:1120
translate Paloslios day2_af3591ad:

    # "… What?!"
    "… ¡¿Qué?!"

# game/days2.rpy:1122
translate Paloslios day2_695ac95a:

    # u "You have a brother? He did that to you?"
    u "¿Tienes un hermano? ¿Él te hizo eso?"

# game/days2.rpy:1126
translate Paloslios day2_1f4dcbcc:

    # a "I have three actually."
    a "En realidad tengo tres."

# game/days2.rpy:1129
translate Paloslios day2_116dc7de:

    # "This was spinning my entire world. Alan must’ve been through a lot! Is that why he’s in the woods? To escape from it all?"
    "Esto estaba dando vueltas a mi mundo entero. ¡Alan debe haber pasado por mucho! ¿Es por eso que está en el bosque? ¿Para escapar de todo?"

# game/days2.rpy:1133
translate Paloslios day2_0067c11b:

    # a "We were… pretty dysfunctional."
    a "Éramos… bastante disfuncionales."

# game/days2.rpy:1134
translate Paloslios day2_ee59f301:

    # a "Mom was constantly in and out of hospital. So two of my older brothers had to take care of us."
    a "Mamá entraba y salía constantemente del hospital. Entonces dos de mis hermanos mayores tuvieron que cuidarnos."

# game/days2.rpy:1135
translate Paloslios day2_e6e469c9:

    # a "The eldest… He burnt cigarettes on me whenever I would win in a fight, telling me I finally became what I was meant to do."
    a "El mayor... Me quemaba cigarrillos cada vez que ganaba en una pelea, diciéndome que finalmente me convertí en lo que debía hacer."

# game/days2.rpy:1137
translate Paloslios day2_b8c7c994:

    # a "It was to fight back and not let others push me… I’d hate to say it worked."
    a "Fue contraatacar y no dejar que otros me empujaran... Odiaría decir que funcionó."

# game/days2.rpy:1141
translate Paloslios day2_d9aec312:

    # u "What about… Your other brothers?"
    u "¿Qué pasa con... tus otros hermanos?"

# game/days2.rpy:1145
translate Paloslios day2_50d4c7b8:

    # a "Second eldest wanted to pretend that everything was fine and ignored our problems."
    a "El segundo mayor quería fingir que todo estaba bien e ignoraba nuestros problemas."

# game/days2.rpy:1146
translate Paloslios day2_c3852c2b:

    # a "He was desperately trying to be like the dad of our group. When I didn’t need one, I wanted a brother."
    a "Estaba tratando desesperadamente de ser como el padre de nuestro grupo. Cuando no lo necesitaba, quería un hermano."

# game/days2.rpy:1150
translate Paloslios day2_4d0ac99b:

    # "He heavily sighed after his rant. I kept myself quiet to let him continue."
    "Suspiró profundamente después de su perorata. Me quedé en silencio para dejarle continuar."

# game/days2.rpy:1154
translate Paloslios day2_2017605a:

    # a "My youngest brother… I got along with him at first but…"
    a "Mi hermano menor... me llevaba bien con él al principio pero..."

# game/days2.rpy:1158
translate Paloslios day2_72e94c19:

    # a "…"
    a "…"

# game/days2.rpy:1162
translate Paloslios day2_d7c9ccf8:

    # a "He wasn’t the worst out of all of them but we had a fall out."
    a "No era el peor de todos, pero tuvimos una pelea."

# game/days2.rpy:1166
translate Paloslios day2_067d1d96:

    # u "… I’m sorry."
    u "… Lo lamento."

# game/days2.rpy:1170
translate Paloslios day2_4c0fe470:

    # a "It’s alright. They were nothing compared to my school life! I got called “Crazy-Eyed Alan” by my entire class."
    a "Está bien. ¡No eran nada comparados con mi vida escolar! Toda mi clase me llamó \"Alan el de ojos locos\"."

# game/days2.rpy:1174
translate Paloslios day2_31007d00:

    # "I only gave him a sad expression. Feeling incredibly sorry for him. I scooted closer to him, practically touching shoulders."
    "Sólo le puse una expresión triste. Sintiendo una pena increíble por él. Me acerqué a él, prácticamente tocándome los hombros."

# game/days2.rpy:1176
translate Paloslios day2_e77609cc:

    # u "I can’t imagine how long you must’ve endured it."
    u "No puedo imaginar cuánto tiempo debiste soportarlo."

# game/days2.rpy:1180
translate Paloslios day2_7b856ff4:

    # a "One instance in particular, pushed me over the edge… That day, I decided to drop out of school, leave my family, and never look back."
    a "Un caso en particular me llevó al límite... Ese día, decidí abandonar la escuela, dejar a mi familia y nunca mirar atrás."

# game/days2.rpy:1184
translate Paloslios day2_e095ce33:

    # "We both stayed silent, continuing to look up at the night sky."
    "Ambos nos quedamos en silencio, sin dejar de mirar el cielo nocturno."

# game/days2.rpy:1188
translate Paloslios day2_df465612:

    # a "I always thought I was meant to be alone. I didn’t like being around people."
    a "Siempre pensé que estaba destinada a estar sola. No me gustaba estar rodeado de gente."

# game/days2.rpy:1192
translate Paloslios day2_13124c64:

    # "I started to feel his hand starting to brush against mine."
    "Empecé a sentir su mano rozando la mía."

# game/days2.rpy:1196
translate Paloslios day2_d92b7404:

    # a "That was until I met you, doe-eyes…"
    a "Eso fue hasta que te conocí, ojos de ciervo..."

# game/days2.rpy:1200
translate Paloslios day2_2e77812e:

    # "He took hold of my hand, squeezing it tightly. It made my heart race."
    "Tomó mi mano y la apretó con fuerza. Hizo que mi corazón se acelerara."

# game/days2.rpy:1202
translate Paloslios day2_4a8d0f9b_3:

    # u "Alan…"
    u "Alan..."

# game/days2.rpy:1204
translate Paloslios day2_32fb53c2_1:

    # a "Hm?"
    a "¿Mmm?"

# game/days2.rpy:1206
translate Paloslios day2_b90567f4:

    # "I look over to him, meeting his eyes, giving me the sofest expression I have ever seen from him."
    "Lo miro, lo encuentro a los ojos, dándome la expresión más suave que jamás haya visto en él."

# game/days2.rpy:1211
translate Paloslios day2_c5fa9a8c:

    # u "I think you have very beautiful eyes."
    u "Creo que tienes unos ojos muy bonitos."

# game/days2.rpy:1213
translate Paloslios day2_dc445544:

    # "A smile slowly creeped onto him, and I could see his face reddening."
    "Una sonrisa apareció lentamente en él y pude ver su rostro enrojecerse."

# game/days2.rpy:1217
translate Paloslios day2_eee6d3ac:

    # a "Thank you…"
    a "Gracias…"

# game/days2.rpy:1222
translate Paloslios day2_4ac27588:

    # u "I’m glad to have met you."
    u "Me alegro de haberte conocido."

# game/days2.rpy:1224
translate Paloslios day2_d4795602:

    # "I gripped his hand back tightly and he responded with his thumb rubbing against the back of my hand."
    "Agarré su mano con fuerza y él respondió con su pulgar frotando el dorso de mi mano."

# game/days2.rpy:1227
translate Paloslios day2_8a0baa39:

    # a "I feel the same."
    a "Siento lo mismo."

# game/days2.rpy:1231
translate Paloslios day2_be118409:

    # "I couldn’t bring myself to say anything. I felt choked up by my words."
    "No me atreví a decir nada. Me sentí ahogado por mis palabras."

# game/days2.rpy:1233
translate Paloslios day2_c3959ab2:

    # u "... I think I should go back home now."
    u "... Creo que debería volver a casa ahora."

# game/days2.rpy:1237
translate Paloslios day2_aeff9411:

    # a "Alright then."
    a "Muy bien entonces."

# game/days2.rpy:1245
translate Paloslios day2_f87af833:

    # "We both got up from our spot, I stretched out my arms, feeling a yawn coming up. Alan noted, standing beside me."
    "Ambos nos levantamos de nuestro lugar, estiré los brazos sintiendo un bostezo inminente. Alan notó, de pie a mi lado."

# game/days2.rpy:1247
translate Paloslios day2_70a36557:

    # a "Let me carry you."
    a "Déjame llevarte."

# game/days2.rpy:1249
translate Paloslios day2_990e9004:

    # u "It’s fine, Alan. I’m just a little tired."
    u "Está bien, Alan. Estoy un poco cansado."

# game/days2.rpy:1251
translate Paloslios day2_ad841c97:

    # "Before I could get on my feet, I felt his arms hook around my legs and back and proceeded to pick me up from the ground at ease."
    "Antes de que pudiera ponerme de pie, sentí sus brazos rodear mis piernas y mi espalda y procedí a levantarme del suelo cómodamente."

# game/days2.rpy:1253
translate Paloslios day2_0879917b:

    # u "H-Hey!"
    u "¡Oye!"

# game/days2.rpy:1257
translate Paloslios day2_e6146f5d:

    # "He gave me a smile, holding me closer to his body."
    "Me dio una sonrisa, abrazándome más cerca de su cuerpo."

# game/days2.rpy:1259
translate Paloslios day2_1f631a85:

    # a "I insist."
    a "Insisto."

# game/days2.rpy:1261
translate Paloslios day2_eab72863:

    # "I gave in, pouting on the way there before my eyes began to grow heavy. I leaned onto his chest, making him my personal pillow and rested my eyes."
    "Me rendí, haciendo pucheros en el camino antes de que mis ojos comenzaran a volverse pesados. Me apoyé en su pecho, convirtiéndolo en mi almohada personal y descansé mis ojos."

# game/days2.rpy:1267
translate Paloslios day2_d2f89f34:

    # "I could barely tell what was going on around me, only feeling my body being set down on something soft and comfortable. I smiled, cuddling up to something soft I could find next to me."
    "Apenas podía decir lo que estaba pasando a mi alrededor, solo sentía mi cuerpo apoyado sobre algo suave y cómodo. Sonreí, acurrucándome en algo suave que pude encontrar a mi lado."

# game/days2.rpy:1269
translate Paloslios day2_6701c83e:

    # "Before I drifted off to sleep, something warm pressed against my cheek, and I heard Alan’s voice."
    "Antes de quedarme dormido, algo cálido presionó mi mejilla y escuché la voz de Alan."

# game/days2.rpy:1271
translate Paloslios day2_07c63ad8:

    # a "Goodnight, Doe-eyes…"
    a "Buenas noches, ojos de ciervo..."

