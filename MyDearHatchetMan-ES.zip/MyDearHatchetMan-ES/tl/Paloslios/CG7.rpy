


    ####
    ##                                      ##
    ##  F95Zone Paloslios Renpy Translator  ##
    ##     https://ko-fi.com/paloslios      ##
    ##                                      ##
    ####



translate Paloslios strings:

    # game/days1.rpy:47
    old "Check on phone"
    new "Consultar por teléfono"

    # game/days1.rpy:47
    old "Get out of bed"
    new "sal de la cama"

    # game/days1.rpy:52
    old "Open message"
    new "mensaje abierto"

    # game/days1.rpy:52
    old "Don’t open message"
    new "No abrir mensaje"

    # game/days1.rpy:213
    old "It flattered you"
    new "te halagó"

    # game/days1.rpy:213
    old "You didn’t mind it but…"
    new "No te importó pero..."

    # game/days1.rpy:429
    old "Ice cream"
    new "helado"

    # game/days1.rpy:429
    old "A Slushie"
    new "un granizado"

    # game/days1.rpy:429
    old "A soda"
    new "un refresco"

    # game/days1.rpy:507
    old "Offer him a taste of yours"
    new "Ofrécele una probada tuya."

translate Paloslios strings:

    # game/days2.rpy:41
    old "Don’t bother"
    new "No te molestes"

    # game/days2.rpy:41
    old "Check messages"
    new "comprobar mensajes"

    # game/days2.rpy:354
    old "Stay quiet"
    new "quédate callado"

    # game/days2.rpy:354
    old "Say something"
    new "di algo"

    # game/days2.rpy:389
    old "Ignore them"
    new "ignorarlos"

    # game/days2.rpy:389
    old "Tell them"
    new "Diles"

    # game/days2.rpy:518
    old "Listen to him"
    new "escúchalo"

    # game/days2.rpy:550
    old "Upset at Stu’s antics"
    new "Molesto por las payasadas de Stu"

    # game/days2.rpy:550
    old "Upset he tried to get with Erika"
    new "Molesto intentó ponerse con Erika"

    # game/days2.rpy:550
    old "You don’t know why"
    new "No sabes por qué"

    # game/days2.rpy:638
    old "Hold him"
    new "Sostenlo"

    # game/days2.rpy:638
    old "Kiss him"
    new "Besarlo"

    # game/days2.rpy:675
    old "Stop him"
    new "detenerlo"

    # game/days2.rpy:675
    old "Let him continue"
    new "Déjalo continuar"

    # game/days2.rpy:861
    old "You’re fine"
    new "estas bien"

    # game/days2.rpy:861
    old "Let him carry you"
    new "Deja que te lleve"

    # game/days2.rpy:909
    old "Draco"
    new "Draco"

    # game/days2.rpy:909
    old "Pegasus"
    new "Pegaso"

    # game/days2.rpy:909
    old "Your zodiac sign"
    new "Tu signo del zodíaco"

    # game/days2.rpy:909
    old "You don’t know"
    new "no lo sabes"

    # game/days2.rpy:955
    old "Aries"
    new "aries"

    # game/days2.rpy:955
    old "Taurus"
    new "Tauro"

    # game/days2.rpy:955
    old "Gemini"
    new "Géminis"

    # game/days2.rpy:955
    old "Cancer"
    new "Cáncer"

    # game/days2.rpy:955
    old "Leo"
    new "león"

    # game/days2.rpy:955
    old "Virgo"
    new "Virgo"

    # game/days2.rpy:955
    old "Libra"
    new "libra"

    # game/days2.rpy:955
    old "Scorpio"
    new "Escorpio"

    # game/days2.rpy:955
    old "Sagittarius"
    new "Sagitario"

    # game/days2.rpy:955
    old "Capricorn"
    new "Capricornio"

    # game/days2.rpy:955
    old "Aquarius"
    new "Acuario"

    # game/days2.rpy:955
    old "Pisces"
    new "Piscis"

    # game/days2.rpy:1208
    old "I think your eyes are beautiful"
    new "Creo que tus ojos son hermosos"

    # game/days2.rpy:1208
    old "I’m glad to have met you"
    new "Me alegro de haberte conocido"

    # game/days2.rpy:1208
    old "Say nothing"
    new "no digas nada"

translate Paloslios strings:

    # game/script.rpy:22
    old "What is your gender?"
    new "¿Cuál es tu género?"

    # game/script.rpy:22
    old "Male"
    new "masculino"

    # game/script.rpy:22
    old "Female"
    new "Mujer"

    # game/script.rpy:22
    old "More..."
    new "Más..."

    # game/script.rpy:52
    old "Nonbinary"
    new "no binario"

    # game/script.rpy:52
    old "Custom..."
    new "Personalizado..."

    # game/script.rpy:52
    old "Back..."
    new "Atrás..."

    # game/script.rpy:76
    old "Your gender is: male. Is this okay?"
    new "Tu género es: masculino. ¿Está bien?"

    # game/script.rpy:76
    old "Yes"
    new "si"

    # game/script.rpy:76
    old "No"
    new "No"

    # game/script.rpy:84
    old "Your gender is: female. Is this okay?"
    new "Tu género es: femenino. ¿Está bien?"

    # game/script.rpy:92
    old "Your gender is: nonbinary. Is this okay?"
    new "Tu género es: no binario. ¿Está bien?"

    # game/script.rpy:100
    old "Your gender is: custom with pronouns [PP1]/[PP2]/[PP3]. Is this okay?"
    new "Tu género es: personalizado con pronombres [PP1]/[PP2]/[PP3]. ¿Está bien?"

    # game/script.rpy:184
    old "Cry"
    new "Llorar"

    # game/script.rpy:184
    old "Stay silent"
    new "quédate en silencio"

    old "Save"
    new "Ahorrar"

    old "Load"
    new "Carga"

    old "Delete"
    new "Borrar"

    old "Quick Save"
    new "Guardado rápido"

    old "Quick Load"
    new "Carga rápida"

    old "Auto"
    new "Auto"

    old "Page"
    new "Página"

    old "Empty Slot"
    new "Ranura vacía"

    old "Are you sure?"
    new "¿Está seguro?"

    old "Cancel"
    new "Cancelar"

    old "OK"
    new "DE ACUERDO"

    old "Confirm"
    new "Confirmar"

    old "Preferences"
    new "Preferencias"

    old "Settings"
    new "Ajustes"

    old "Display"
    new "Mostrar"

    old "Audio"
    new "Audio"

    old "Accessibility"
    new "Accesibilidad"

    old "Text Speed"
    new "Velocidad del texto"

    old "Auto-Forward Time"
    new "Avance automático del tiempo"

    old "Music Volume"
    new "Volumen de la música"

    old "Sound Volume"
    new "Volumen del sonido"

    old "Voice Volume"
    new "Volumen de voz"

    old "Mute All"
    new "Silenciar todo"

    old "Fullscreen"
    new "Pantalla completa"

    old "Window"
    new "Ventana"

    old "Skip"
    new "Saltar"

    old "After Choices"
    new "Después de las elecciones"

    old "Transitions"
    new "Transiciones"

    old "Skipping"
    new "Salto a la comba"

    old "Continue"
    new "Continuar"

    old "Stop Skipping"
    new "Deja de saltarte"

    old "History"
    new "Historia"

    old "Back"
    new "Atrás"

    old "Return"
    new "Devolver"

    old "Main Menu"
    new "Menú principal"

    old "Start"
    new "Comenzar"

    old "New Game"
    new "Nuevo juego"

    old "Load Game"
    new "Cargar juego"

    old "Save Game"
    new "Guardar partida"

    old "Options"
    new "Opciones"

    old "Extras"
    new "Extras"

    old "Gallery"
    new "Galería"

    old "Music Room"
    new "Sala de música"

    old "Replay"
    new "Repetición"

    old "Quit"
    new "Abandonar"

    old "Exit"
    new "Salida"

    old "Credits"
    new "Créditos"

    old "About"
    new "Acerca de"

    old "Help"
    new "Ayuda"

    old "Next"
    new "Próximo"

    old "Previous"
    new "Anterior"

    old "Clear"
    new "Claro"

    old "Reset"
    new "Reiniciar"

    old "Default"
    new "Por defecto"

    old "Apply"
    new "Aplicar"

    old "Close"
    new "Cerca"

    old "Hide"
    new "Esconder"

    old "Show"
    new "Espectáculo"

    old "Toggle"
    new "Palanca"

    old "Enable"
    new "Permitir"

    old "Disable"
    new "Desactivar"

    old "On"
    new "En"

    old "Off"
    new "Apagado"

    old "Monday"
    new "Lunes"

    old "Tuesday"
    new "Martes"

    old "Wednesday"
    new "Miércoles"

    old "Thursday"
    new "Jueves"

    old "Friday"
    new "Viernes"

    old "Saturday"
    new "Sábado"

    old "Sunday"
    new "Domingo"

    old "January"
    new "Enero"

    old "February"
    new "Febrero"

    old "March"
    new "Marzo"

    old "April"
    new "Abril"

    old "May"
    new "Puede"

    old "June"
    new "Junio"

    old "July"
    new "Julio"

    old "August"
    new "Agosto"

    old "September"
    new "Septiembre"

    old "October"
    new "Octubre"

    old "November"
    new "Noviembre"

    old "December"
    new "Diciembre"

    old "Error"
    new "Error"

    old "Warning"
    new "Advertencia"

    old "Information"
    new "Información"

    old "Loading..."
    new "Cargando..."

    old "Saving..."
    new "Ahorro..."

    old "File not found"
    new "Archivo no encontrado"

    old "Cannot save"
    new "No se puede guardar"

    old "Cannot load"
    new "No se puede cargar"

    old "Self-voicing"
    new "Autoexpresión"

    old "Clipboard voicing"
    new "Voz del portapapeles"

    old "Debug voicing"
    new "Depuración de voces"

    old "Opens the accessibility menu"
    new "Abre el menú de accesibilidad"

    old "Closes the game menu"
    new "Cierra el menú del juego."

    old "Chapter"
    new "Capítulo"

    old "Scene"
    new "Escena"

    old "Episode"
    new "Episodio"

    old "Part"
    new "Parte"

    old "Volume"
    new "Volumen"

    old "Ending"
    new "Final"

    old "Bad End"
    new "Mal final"

    old "Good End"
    new "Buen final"

    old "True End"
    new "Fin verdadero"

    old "Please enter your name:"
    new "Por favor, introduzca su nombre:"

    old "Enter text:"
    new "Introducir texto:"

    old "Input required"
    new "Entrada requerida"

    old "What is your choice?"
    new "¿Cual es tu elección?"

    old "Select an option"
    new "Seleccione una opción"

    old "Game saved."
    new "Juego guardado."

    old "Game loaded."
    new "Juego cargado."

    old "Quick save created."
    new "Guardado rápido creado."

    old "Cannot quick save here."
    new "No se puede guardar rápidamente aquí."

    old "No save data."
    new "No hay datos guardados."

    old "Save data corrupted."
    new "Guardar datos corruptos."

    old "Unknown error occurred."
    new "Se produjo un error desconocido."

    old "The game will now quit."
    new "El juego ahora se cerrará."

    old "Are you sure you want to quit?"
    new "¿Estás seguro que deseas salir?"

    old "Are you sure you want to return to the main menu?"
    new "¿Estás seguro que deseas volver al menú principal?"

    old "Joystick mapping has been reset to default."
    new "La asignación del joystick se ha restablecido a los valores predeterminados."

    old "This save was created on a different device. Timestamps may be inaccurate."
    new "Esta partida guardada se creó en otro dispositivo. Las marcas de tiempo pueden ser inexactas."

    old "The input you entered is not a valid filename."
    new "El dato ingresado no es un nombre de archivo válido."

    old "The filename is too long."
    new "El nombre del archivo es demasiado largo."

    old "{#month_short}Jan"
    new "{#month_short} Enero"

    old "{#month_short}Feb"
    new "{#month_short} Feb"

    old "{#month_short}Mar"
    new "{#month_short} Mar"

    old "{#month_short}Apr"
    new "{#month_short} Abril"

    old "{#month_short}May"
    new "{#month_short} Mayo"

    old "{#month_short}Jun"
    new "{#month_short} Junio"

    old "{#month_short}Jul"
    new "{#month_short} Julio"

    old "{#month_short}Aug"
    new "{#month_short} Agosto"

    old "{#month_short}Sep"
    new "{#month_short} Septiembre"

    old "{#month_short}Oct"
    new "{#month_short} Octubre"

    old "{#month_short}Nov"
    new "{#month_short} Noviembre"

    old "{#month_short}Dec"
    new "{#month_short} Diciembre"

    old "What is your name? Type it in and press enter:"
    new "¿Cuál es tu nombre? Escríbelo y pulsa Intro:"