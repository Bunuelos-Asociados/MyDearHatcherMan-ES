


    ####
    ##                                      ##
    ##  F95Zone Paloslios Renpy Translator  ##
    ##     https://ko-fi.com/paloslios      ##
    ##                                      ##
    ####



translate Paloslios strings:

    # game/script.rpy:156
    old "What is your gender?"
    new "¿Cuál es tu género?"

    # game/script.rpy:156
    old "Male"
    new "Masculino"

    # game/script.rpy:156
    old "Female"
    new "Femenino"

    # game/script.rpy:156
    old "Nonbinary"
    new "No binario"

    # game/script.rpy:156
    old "Custom..."
    new "Costumbre..."

    # game/script.rpy:192
    old "Your gender is: male. Is this okay?"
    new "Tu género es: hombre. ¿Está bien?"

    # game/script.rpy:199
    old "Your gender is: female. Is this okay?"
    new "Tu género es: mujer. ¿Está bien?"

    # game/script.rpy:206
    old "Your gender is: nonbinary. Is this okay?"
    new "Tu género es: no binario. ¿Está bien?"

    # game/script.rpy:213
    old "Your gender is: [gender] with pronouns [PP1]/[PP2]/[PP3]. Is this okay?"
    new "Tu género es: [gender] con pronombres [PP1]/[PP2]/[PP3]. ¿Está bien?"

    # game/script.rpy:339
    old "Jump"
    new "Saltar"

    # game/script.rpy:339
    old "Freeze in place"
    new "Congelarse en su lugar"

    # game/script.rpy:377
    old "Scream"
    new "Gritar"

    # game/script.rpy:377
    old "ATTACK!"
    new "¡ATAQUE!"

    # game/script.rpy:475
    old "It annoyed you"
    new "Te molestó"

    # game/script.rpy:475
    old "It kinda charmed you"
    new "Te cautivó un poco"

    # game/script.rpy:770
    old "Slice of leftover pizza"
    new "Rebanada de pizza sobrante"

    # game/script.rpy:770
    old "Toaster waffles"
    new "Gofres de tostadora"

    # game/script.rpy:770
    old "Eggs"
    new "Huevos"

    # game/script.rpy:857
    old "Laugh"
    new "Reír"

    # game/script.rpy:857
    old "Groan"
    new "Gemido"

    # game/script.rpy:954
    old "It flattered you"
    new "Te halagó"

    # game/script.rpy:954
    old "It weirded you out"
    new "Te extrañó"

    # game/script.rpy:1053
    old "Ice cream"
    new "Helado"

    # game/script.rpy:1053
    old "Slushie"
    new "Granizado"

    # game/script.rpy:1053
    old "A Soda"
    new "Un refresco"

    # game/script.rpy:1139
    old "Offer him a taste of your treat"
    new "Ofrecerle una muestra de tu regalo"

    # game/script.rpy:1139
    old "Stay silent"
    new "Permanecer en silencio"

    # game/script.rpy:1217
    old "'Can you teach me how to do that?'"
    new "'¿Puedes enseñarme cómo hacer eso?'"

    # game/script.rpy:1217
    old "Search for a rock to throw"
    new "Buscar una roca para lanzar"

    # game/scriptday2.rpy:35
    old "Check messages"
    new "Verificar mensajes"

    # game/scriptday2.rpy:35
    old "Don't bother"
    new "No te molestes"

    # game/scriptday2.rpy:107
    old "Reply with sass"
    new "Responder con Sass"

    # game/scriptday2.rpy:107
    old "Reply nervously"
    new "Responder nerviosamente"

    # game/scriptday2.rpy:183
    old "I think I'll pass."
    new "Creo que pasaré."

    # game/scriptday2.rpy:183
    old "I'd be happy to meet them."
    new "Estaría feliz de conocerlos."

    # game/scriptday2.rpy:203
    old "Arrest me then, officer."
    new "Arrestarme entonces, oficial."

    # game/scriptday2.rpy:203
    old "Nope! I'm NOT a criminal!"
    new "¡No! ¡No soy un criminal!"

    # game/scriptday2.rpy:236
    old "Make your leave"
    new "Haz tu clase"

    # game/scriptday2.rpy:236
    old "Ask Alan to accompany you"
    new "Pídale a Alan que lo acompañe"

    # game/scriptday2.rpy:473
    old "Ask her about the assignment."
    new "Pregúntale sobre la tarea."

    # game/scriptday2.rpy:473
    old "How was her day?"
    new "¿Cómo estuvo su día?"

    # game/scriptday2.rpy:545
    old "Mecha"
    new "Mecha"

    # game/scriptday2.rpy:545
    old "Magical Girls"
    new "Chicas mágicas"

    # game/scriptday2.rpy:545
    old "Slice of life"
    new "Rebanada de vida"

    # game/scriptday2.rpy:545
    old "Horror"
    new "Horror"

    # game/scriptday2.rpy:775
    old "Pancakes"
    new "Panqueques"

    # game/scriptday2.rpy:775
    old "Breakfast burrito"
    new "Burrito de desayuno"

    # game/scriptday2.rpy:775
    old "Eggs in a basket"
    new "Huevos de canasta"

    # game/scriptday2.rpy:840
    old "Keep the conversation going"
    new "Mantenga la conversación"

    # game/scriptday2.rpy:840
    old "Let it go"
    new "Déjalo ir"

    # game/scriptday2.rpy:904
    old "Breakfasts used to be messy..."
    new "Los desayunos solían ser desordenados ..."

    # game/scriptday2.rpy:904
    old "This feels nostalgic."
    new "Esto se siente nostálgico."

    # game/scriptday2.rpy:933
    old "Kiss him"
    new "Besarlo"

    # game/scriptday2.rpy:933
    old "Back away"
    new "Retroceder"

    # game/scriptday2.rpy:1082
    old "Talk to Erika"
    new "Habla con Erika"

    # game/scriptday2.rpy:1082
    old "Talk to Stu"
    new "Habla con Stu"

    # game/scriptday2.rpy:1082
    old "Talk to Alan"
    new "Habla con Alan"

    # game/scriptday2.rpy:1138
    old "It's too late at this point. Let it slide."
    new "Es demasiado tarde en este punto. Déjalo pasar."

    # game/scriptday2.rpy:1138
    old "You feel uncomfortable. Correct Alan."
    new "Te sientes incómodo. Corrige Alan."

    # game/scriptday2.rpy:1138
    old "You liked his nickname for you."
    new "Te gustó su apodo para ti."

    # game/scriptday2.rpy:1187
    old "Say nothing"
    new "No decir nada"

    # game/scriptday2.rpy:1187
    old "Ease the tension"
    new "Aliviar la tensión"

    # game/scriptday2.rpy:1351
    old "Throw the pillow at him."
    new "Lanza la almohada."

    # game/scriptday2.rpy:1351
    old "Hand him the pillow."
    new "Déle la almohada."

    # game/scriptday2.rpy:1435
    old "Stay silent."
    new "Permanecer en silencio."

    # game/scriptday2.rpy:1435
    old "Say that you like him."
    new "Di que te gusta."

    # game/scriptday2.rpy:1435
    old "Let him surprise you."
    new "Deja que te sorprenda."

    # game/scriptday2.rpy:1468
    old "Ask him to stop"
    new "Pídale que se detenga"

    # game/scriptday2.rpy:1468
    old "Keep going"
    new "Sigue adelante"

    # game/scriptday2.rpy:1486
    old "Pat the seat next to you"
    new "Pase el asiento a tu lado"

    # game/scriptday2.rpy:1486
    old "Pat your lap"
    new "Patea tu regazo"

    old "What is your name? Type it in and press enter:"
    new "¿Cuál es tu nombre? Escríbelo y pulsa Intro:"

    old "Save"
    new "Ahorrar"

    old "Load"
    new "Carga"

    old "Delete"
    new "Borrar"

    old "Quick Save"
    new "Guardado rápido"

    old "Quick Load"
    new "Carga rápida"

    old "Auto"
    new "Auto"

    old "Page"
    new "Página"

    old "Empty Slot"
    new "Ranura vacía"

    old "Are you sure?"
    new "¿Está seguro?"

    old "Yes"
    new "Sí"

    old "No"
    new "No"

    old "Cancel"
    new "Cancelar"

    old "OK"
    new "DE ACUERDO"

    old "Confirm"
    new "Confirmar"

    old "Preferences"
    new "Preferencias"

    old "Settings"
    new "Ajustes"

    old "Display"
    new "Mostrar"

    old "Audio"
    new "Audio"

    old "Accessibility"
    new "Accesibilidad"

    old "Text Speed"
    new "Velocidad del texto"

    old "Auto-Forward Time"
    new "Avance automático del tiempo"

    old "Music Volume"
    new "Volumen de la música"

    old "Sound Volume"
    new "Volumen del sonido"

    old "Voice Volume"
    new "Volumen de voz"

    old "Mute All"
    new "Silenciar todo"

    old "Fullscreen"
    new "Pantalla completa"

    old "Window"
    new "Ventana"

    old "Skip"
    new "Saltar"

    old "After Choices"
    new "Después de las elecciones"

    old "Transitions"
    new "Transiciones"

    old "Skipping"
    new "Salto a la comba"

    old "Continue"
    new "Continuar"

    old "Stop Skipping"
    new "Deja de saltarte"

    old "History"
    new "Historia"

    old "Back"
    new "Atrás"

    old "Return"
    new "Devolver"

    old "Main Menu"
    new "Menú principal"

    old "Start"
    new "Comenzar"

    old "New Game"
    new "Nuevo juego"

    old "Load Game"
    new "Cargar juego"

    old "Save Game"
    new "Guardar partida"

    old "Options"
    new "Opciones"

    old "Extras"
    new "Extras"

    old "Gallery"
    new "Galería"

    old "Music Room"
    new "Sala de música"

    old "Replay"
    new "Repetición"

    old "Quit"
    new "Abandonar"

    old "Exit"
    new "Salida"

    old "Credits"
    new "Créditos"

    old "About"
    new "Acerca de"

    old "Help"
    new "Ayuda"

    old "Next"
    new "Próximo"

    old "Previous"
    new "Anterior"

    old "Clear"
    new "Claro"

    old "Reset"
    new "Reiniciar"

    old "Default"
    new "Por defecto"

    old "Apply"
    new "Aplicar"

    old "Close"
    new "Cerca"

    old "Hide"
    new "Esconder"

    old "Show"
    new "Espectáculo"

    old "Toggle"
    new "Palanca"

    old "Enable"
    new "Permitir"

    old "Disable"
    new "Desactivar"

    old "On"
    new "En"

    old "Off"
    new "Apagado"

    old "Monday"
    new "Lunes"

    old "Tuesday"
    new "Martes"

    old "Wednesday"
    new "Miércoles"

    old "Thursday"
    new "Jueves"

    old "Friday"
    new "Viernes"

    old "Saturday"
    new "Sábado"

    old "Sunday"
    new "Domingo"

    old "January"
    new "Enero"

    old "February"
    new "Febrero"

    old "March"
    new "Marzo"

    old "April"
    new "Abril"

    old "May"
    new "Puede"

    old "June"
    new "Junio"

    old "July"
    new "Julio"

    old "August"
    new "Agosto"

    old "September"
    new "Septiembre"

    old "October"
    new "Octubre"

    old "November"
    new "Noviembre"

    old "December"
    new "Diciembre"

    old "Error"
    new "Error"

    old "Warning"
    new "Advertencia"

    old "Information"
    new "Información"

    old "Loading..."
    new "Cargando..."

    old "Saving..."
    new "Ahorro..."

    old "File not found"
    new "Archivo no encontrado"

    old "Cannot save"
    new "No se puede guardar"

    old "Cannot load"
    new "No se puede cargar"

    old "Self-voicing"
    new "Autoexpresión"

    old "Clipboard voicing"
    new "Voz del portapapeles"

    old "Debug voicing"
    new "Depuración de voces"

    old "Opens the accessibility menu"
    new "Abre el menú de accesibilidad"

    old "Closes the game menu"
    new "Cierra el menú del juego."

    old "Chapter"
    new "Capítulo"

    old "Scene"
    new "Escena"

    old "Episode"
    new "Episodio"

    old "Part"
    new "Parte"

    old "Volume"
    new "Volumen"

    old "Ending"
    new "Final"

    old "Bad End"
    new "Mal final"

    old "Good End"
    new "Buen final"

    old "True End"
    new "Fin verdadero"

    old "Please enter your name:"
    new "Por favor, introduzca su nombre:"

    old "Enter text:"
    new "Introducir texto:"

    old "Input required"
    new "Entrada requerida"

    old "What is your choice?"
    new "¿Cual es tu elección?"

    old "Select an option"
    new "Seleccione una opción"

    old "Game saved."
    new "Juego guardado."

    old "Game loaded."
    new "Juego cargado."

    old "Quick save created."
    new "Guardado rápido creado."

    old "Cannot quick save here."
    new "No se puede guardar rápidamente aquí."

    old "No save data."
    new "No hay datos guardados."

    old "Save data corrupted."
    new "Guardar datos corruptos."

    old "Unknown error occurred."
    new "Se produjo un error desconocido."

    old "The game will now quit."
    new "El juego ahora se cerrará."

    old "Are you sure you want to quit?"
    new "¿Estás seguro que deseas salir?"

    old "Are you sure you want to return to the main menu?"
    new "¿Estás seguro que deseas volver al menú principal?"

    old "Joystick mapping has been reset to default."
    new "La asignación del joystick se ha restablecido a los valores predeterminados."

    old "This save was created on a different device. Timestamps may be inaccurate."
    new "Esta partida guardada se creó en otro dispositivo. Las marcas de tiempo pueden ser inexactas."

    old "The input you entered is not a valid filename."
    new "El dato ingresado no es un nombre de archivo válido."

    old "The filename is too long."
    new "El nombre del archivo es demasiado largo."

    old "{#month_short}Jan"
    new "{#month_short} Enero"

    old "{#month_short}Feb"
    new "{#month_short} Feb"

    old "{#month_short}Mar"
    new "{#month_short} Mar"

    old "{#month_short}Apr"
    new "{#month_short} Abril"

    old "{#month_short}May"
    new "{#month_short} Mayo"

    old "{#month_short}Jun"
    new "{#month_short} Junio"

    old "{#month_short}Jul"
    new "{#month_short} Julio"

    old "{#month_short}Aug"
    new "{#month_short} Agosto"

    old "{#month_short}Sep"
    new "{#month_short} Septiembre"

    old "{#month_short}Oct"
    new "{#month_short} Octubre"

    old "{#month_short}Nov"
    new "{#month_short} Noviembre"

    old "{#month_short}Dec"
    new "{#month_short} Diciembre"

    old "What is the name of your gender? Example: Male/Female/Nonbinary:"
    new "¿Cuál es tu género? Ejemplo: Masculino/Femenino/No binario:"

    old "What is your subject pronoun? Example: He/She/They:"
    new "¿Cuál es tu pronombre sujeto? Ejemplo: Él/Ella/Ellos/Ellas:"
    
    old "What is your object pronoun? Example: Him/Her/Them:"
    new "¿Cuál es tu pronombre objeto? Ejemplo: Él/Ella/Ellos/Ellas:"
    
    old "What is your possessive pronoun? Example: His/Hers/Theirs:"
    new "¿Cuál es tu pronombre posesivo? Ejemplo: Suyo/Suya/Suyo:"

    old "ice cream"
    new "helado"

    old "slushie"
    new "granizado"

    old "Are you sure you want to overwrite your save?"
    new "¿Estás seguro de que quieres sobrescribir tu guardado?"
