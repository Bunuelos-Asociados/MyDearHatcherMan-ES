


    ####
    ##                                      ##
    ##  F95Zone Paloslios Renpy Translator  ##
    ##     https://ko-fi.com/paloslios      ##
    ##                                      ##
    ####



# game/script.rpy:30
translate Paloslios start_d9b59511:

    # "That's {i}my{/i} name, Doe-eyes..."
    "Eso es {i}mi{/i} nombre, Doe-Eyes ..."

# game/script.rpy:36
translate Paloslios start_99402c96:

    # "Hey! You can't steal my name!"
    "¡Ey! ¡No puedes robar mi nombre!"

# game/script.rpy:41
translate Paloslios start_3ffde6b4:

    # "Don't even think about it."
    "Ni siquiera lo pienses."

# game/script.rpy:45
translate Paloslios start_99402c96_1:

    # "Hey! You can't steal my name!"
    "¡Ey! ¡No puedes robar mi nombre!"

# game/script.rpy:49
translate Paloslios start_8f3a2a91:

    # "Nuh-uh!"
    "Nuh-uh!"

# game/script.rpy:53
translate Paloslios start_a20cefa7:

    # "..."
    "..."

# game/script.rpy:58
translate Paloslios start_41279dd5:

    # "I think you should choose a better name."
    "Creo que deberías elegir un mejor nombre."

# game/script.rpy:62
translate Paloslios start_8f5dd8b1:

    # "... Not a chance."
    "... no es una oportunidad."

# game/script.rpy:66
translate Paloslios start_49da980a:

    # "Non."
    "No."

# game/script.rpy:70
translate Paloslios start_24d1d670:

    # "Real funny..."
    "Realmente divertido ..."

# game/script.rpy:74
translate Paloslios start_e40ba73c:

    # "Nope! That's mine!"
    "¡No! ¡Eso es mío!"

# game/script.rpy:78
translate Paloslios start_606c3e43:

    # "I know that you are Stu, but I'll allow it."
    "Sé que eres STU, pero lo permitiré."

# game/script.rpy:83
translate Paloslios start_5904e88b:

    # "You're practically like Erika, but I'll allow it."
    "Eres prácticamente como Erika, pero lo permitiré."

# game/script.rpy:88
translate Paloslios start_63d5093d:

    # "Too bad for Stu..."
    "Lástima para Stu ..."

# game/script.rpy:93
translate Paloslios start_190e9f22:

    # "Hey, sweet stuff~"
    "Oye, cosas dulces ~"

# game/script.rpy:98
translate Paloslios start_5811919d:

    # "Good luck with Erika!"
    "¡Buena suerte con Erika!"

# game/script.rpy:103
translate Paloslios start_4ed653a9:

    # "Are you sure you wanna pursue for Stu...?"
    "¿Estás seguro de que quieres seguir por STU ...?"

# game/script.rpy:108
translate Paloslios start_1cc3564e:

    # "You're not gonna get your grumpy French man here."
    "No vas a conseguir a tu gruñón francés aquí."

# game/script.rpy:113
translate Paloslios start_d1d9d089:

    # "Flower..."
    "Flor..."

# game/script.rpy:118
translate Paloslios start_6622b06d:

    # "Where are you off to, Guineapig?"
    "¿A dónde vas, Guineapig?"

# game/script.rpy:123
translate Paloslios start_b07ebdfd:

    # "My Doe... hehe..."
    "Mi cierva ... jeje ..."

# game/script.rpy:128
translate Paloslios start_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:133
translate Paloslios start_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:138
translate Paloslios start_ad50f537:

    # "Hello, sunshine!"
    "¡Hola, sol!"

# game/script.rpy:143
translate Paloslios start_62c1633d:

    # "The apple of my eye."
    "La manzana de mi ojo."

# game/script.rpy:170
translate Paloslios genderc_4fcd6144:

    # "Please type in your custom pronouns for each selection."
    "Escriba sus pronombres personalizados para cada selección."

# game/script.rpy:225
translate Paloslios prologue_3bc261de:

    # "I tend to run away from my problems. It's how I ended up here in the first place."
    "Tiendo a huir de mis problemas. Así es como terminé aquí en primer lugar."

# game/script.rpy:232
translate Paloslios prologue_1b4ce020:

    # "Doomsbury. Located somewhere in Massachusetts, with a small population of thirty-thousand people or so."
    "Doomsbury. Ubicado en algún lugar de Massachusetts, con una pequeña población de treinta mil personas más o menos."

# game/script.rpy:233
translate Paloslios prologue_032056a2:

    # "It's known for being a college town, where most young adults have taken over the streets and businesses."
    "Es conocido por ser una ciudad universitaria, donde la mayoría de los adultos jóvenes se han apoderado de las calles y las empresas."

# game/script.rpy:235
translate Paloslios prologue_73a61e89:

    # "It's got a rich history, from cryptids to devil-worshiping cults. If you were a gang of crime-solving teens you'd have your work cut out for you..."
    "Tiene una rica historia, desde criptidos hasta cultos que adoran al diablo. Si fueras una pandilla de adolescentes que resuelven el crimen, te cortarías el trabajo para ti ..."

# game/script.rpy:236
translate Paloslios prologue_e3b4a4fd:

    # "But the townspeople revel in the mystery, urban legends and strange folklore. Considering how quiet the town was usually, anything that was a break from the monotony gained notoriety."
    "Pero la gente del pueblo se deleita con el misterio, las leyendas urbanas y el folklore extraño. Teniendo en cuenta lo silenciosa que era generalmente la ciudad, cualquier cosa que fuera un descanso de la monotonía ganó notoriedad."

# game/script.rpy:238
translate Paloslios prologue_3d4910bd:

    # "Many people, especially families, would come and dump their kids for spring or summer break."
    "Muchas personas, especialmente las familias, vendrían y tirarían a sus hijos para las vacaciones de primavera o verano."

# game/script.rpy:240
translate Paloslios prologue_afab1c78:

    # "You know."
    "Sabes."

# game/script.rpy:242
translate Paloslios prologue_bf906142:

    # "A boomer's worst nightmare."
    "La peor pesadilla de un boomer."

# game/script.rpy:244
translate Paloslios prologue_a5ead5e8:

    # "I dug my claws into this sleepy town, attending Doomsbury University."
    "Cavé mis garras en esta somnolienta ciudad, asistiendo a la Universidad de Doomsbury."

# game/script.rpy:245
translate Paloslios prologue_63aef123:

    # "For the past few months of my fall semester, to settle I fell into a routine. Eat, sleep, study, repeat."
    "Durante los últimos meses de mi semestre de otoño, para establecerme, caí en una rutina. Coma, duerme, estudia, repite."

# game/script.rpy:247
translate Paloslios prologue_7973c513:

    # "At first, I was excited to come from the next town over. Receiving that acceptance letter was the best thing to happen to me."
    "Al principio, estaba emocionado de venir de la próxima ciudad. Recibir esa carta de aceptación fue lo mejor que me había pasado."

# game/script.rpy:248
translate Paloslios prologue_ccebbb9f:

    # "I was handed a new life, one way more different than who I was. I wanted it more than anything."
    "Me entregaron una nueva vida, una forma más diferente de lo que era. Lo quería más que a nada."

# game/script.rpy:250
translate Paloslios prologue_86338c7c:

    # "So once the chance was given to me, I took it—hook, line, and sinker."
    "Entonces, una vez que se me dio la oportunidad, la tomé: arrojar, línea y hundimiento."

# game/script.rpy:252
translate Paloslios prologue_0367ded1:

    # "I was doing fine for a while. But, it was hard to make friends. I was isolated, the only times I left my house was to grab a slice of pizza or some coffee from the cafe."
    "Estuve bien por un tiempo. Pero, era difícil hacer amigos. Estaba aislado, las únicas veces que salí de mi casa era tomar una porción de pizza o un poco de café del café."

# game/script.rpy:253
translate Paloslios prologue_7e756d25:

    # "I sorta trapped myself in this cycle, sometimes I wouldn't bother to eat and slug down sleeping pills."
    "Me atrapé en este ciclo, a veces no me molestaba en comer y golpear las pastillas para dormir."

# game/script.rpy:255
translate Paloslios prologue_fdd55b8e:

    # "To say this move wasn't going smoothly would be the understatement of the century."
    "Decir que este movimiento no iba sin problemas sería la subestimación del siglo."

# game/script.rpy:260
translate Paloslios prologue_88bad616:

    # "It's not like I hate it here. Maybe I was just doomed to be miserable no matter where I went."
    "No es como si lo odiara aquí. Tal vez estaba condenado a ser miserable sin importar a dónde fuera."

# game/script.rpy:261
translate Paloslios prologue_98b47f50:

    # "I mean, I'm much happier here than where I used to be. That's not saying much, though..."
    "Quiero decir, estoy mucho más feliz aquí que donde solía estar. Sin embargo, eso no dice mucho ..."

# game/script.rpy:269
translate Paloslios prologue_c319d71c:

    # "I wandered into the woods, thinking that maybe a walk could wear me out and I could catch up on some sleep."
    "Vacié en el bosque, pensando que tal vez una caminata podría desgastarme y podría ponerme al día con un poco de sueño."

# game/script.rpy:270
translate Paloslios prologue_681fc92e:

    # "There was nothing fun about laying on my bed, dissociating until I passed out."
    "No había nada divertido en acostarse en mi cama, disociándose hasta que me desmayé."

# game/script.rpy:272
translate Paloslios prologue_460fe779:

    # "So I decided to leave my cave for some late-night snacks from the local convenience store. Another staple of Doomsbury is the mystical and expansive forest that surrounds it."
    "Así que decidí dejar mi cueva para bocadillos nocturnos de la tienda local de conveniencia. Otro elemento básico de Doomsbury es el bosque místico y expansivo que lo rodea."

# game/script.rpy:273
translate Paloslios prologue_1988db32:

    # "Wood trails that could take you to the many businesses and homes. All the natives knew the trails like the back of their hand, and I was so sure I did too."
    "Senderos de madera que podrían llevarlo a las muchas empresas y hogares. Todos los nativos conocían los senderos como el dorso de su mano, y estaba tan seguro de que yo también."

# game/script.rpy:275
translate Paloslios prologue_3bc6ba3a:

    # "I was pretty familiar with my usual path on my walks, staring at the same fucked up sidewalks or kicking the occasional pebble along the dirt paths."
    "Estaba bastante familiarizado con mi camino habitual en mis caminatas, mirando las mismas aceras jodidas o pateando el guijarro ocasional a lo largo de los caminos de tierra."

# game/script.rpy:276
translate Paloslios prologue_5b581604:

    # "Walking didn't take up much of my time, though I wished it did. I wouldn't say I'm much of a nature lover, but the woods do look nice, especially during golden hour."
    "Caminar no tomó gran parte de mi tiempo, aunque deseé que lo hiciera. No diría que soy un gran amante de la naturaleza, pero los bosques se ven bien, especialmente durante la hora dorada."

# game/script.rpy:278
translate Paloslios prologue_5e67e963:

    # "Tonight I decided to take a different path, I wanted to see what the woods could bring me. A shortcut, or maybe an epiphany you could say."
    "Esta noche decidí tomar un camino diferente, quería ver lo que el bosque podía traerme. Un atajo, o tal vez una epifanía que se podría decir."

# game/script.rpy:279
translate Paloslios prologue_1d6b4ca4:

    # "Maybe I could find a cool-looking stick from the ground and pretend it's a sword. I'll admit, it doesn't sound like much, but given the circumstances, I have to work with what I got."
    "Tal vez podría encontrar un palo de aspecto fresco del suelo y fingir que es una espada. Admito que no suena mucho, pero dadas las circunstancias, tengo que trabajar con lo que obtuve."

# game/script.rpy:281
translate Paloslios prologue_3c251699:

    # "It was starting to get colder, I could tell by the numbness nipping at my fingertips. I jammed my hands into the pockets of my pants, trying to get some feeling in them."
    "Estaba empezando a ponerse más frío, podía decir por el entumecimiento que me mordió a mis dedos. Me atascé las manos en los bolsillos de mis pantalones, tratando de sentir un poco en ellos."

# game/script.rpy:283
translate Paloslios prologue_a20cefa7:

    # "..."
    "..."

# game/script.rpy:285
translate Paloslios prologue_dda575f7:

    # "Wait a minute—"
    "Espera un minuto—"

# game/script.rpy:290
translate Paloslios prologue_eef5038c:

    # "Where exactly am I?"
    "¿Dónde estoy exactamente?"

# game/script.rpy:292
translate Paloslios prologue_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:294
translate Paloslios prologue_55222d8b:

    # u "Goddammit."
    u "Maldita sea."

# game/script.rpy:300
translate Paloslios prologue_1644fc2c:

    # "Well, this was just perfect."
    "Bueno, esto fue perfecto."

# game/script.rpy:302
translate Paloslios prologue_edf1714f:

    # "I'm all alone in the woods, with no service, no sense of direction and it's dark out."
    "Estoy solo en el bosque, sin servicio, sin sentido de dirección y está oscuro."

# game/script.rpy:304
translate Paloslios prologue_1949483c:

    # "That's what I get for being adventurous."
    "Eso es lo que obtengo por ser aventurero."

# game/script.rpy:306
translate Paloslios prologue_f2db3fea:

    # u "I'm an idiot."
    u "Soy un idiota."

# game/script.rpy:308
translate Paloslios prologue_efa411f8:

    # "My eyes scanned around through the thick foliage of the trees. How long was I walking for?"
    "Mis ojos escanearon a través del grueso follaje de los árboles. ¿Cuánto tiempo pasaba por el que caminaba?"

# game/script.rpy:309
translate Paloslios prologue_26c65d40:

    # "I couldn't have walked that far out but it was too little too late for that now. The soles of my feet were aching."
    "No podría haber caminado tan lejos, pero ahora era demasiado poco tarde para eso. Las plantas de mis pies estaban doliendo."

# game/script.rpy:311
translate Paloslios prologue_54b3eb49:

    # "Begrudgingly, I sat on a large rock as a sort of makeshift seat to relax, and collect my thoughts before I had a mental breakdown."
    "A regañadientes, me senté en una gran roca como una especie de asiento improvisado para relajarme y recoger mis pensamientos antes de tener un colapso mental."

# game/script.rpy:313
translate Paloslios prologue_177e1109:

    # "I sigh, slightly grimacing from the cold, hard surface of the rock. I drop my plastic bag of goodies onto the grass, my warm face crinkling from the frigid breeze."
    "Suspiro, ligeramente mueca de la superficie fría y dura de la roca. Dejo caer mi bolsa de plástico de golosinas sobre la hierba, mi cara cálida arrugando de la fría brisa."

# game/script.rpy:315
translate Paloslios prologue_32d9874d:

    # u "I don't know what to do..."
    u "No sé qué hacer ..."

# game/script.rpy:317
translate Paloslios prologue_051db89a:

    # "I can't believe I'm lost out here! That if I died it could be weeks before my body was found."
    "¡No puedo creer que esté perdido aquí! Que si muriera podría pasar semanas antes de que se encontrara mi cuerpo."

# game/script.rpy:319
translate Paloslios prologue_7997f243:

    # "I sniffle, wiping away the small tears forming at the corners of my eyes."
    "Yo resoplé, limpiando las pequeñas lágrimas que se forman en las esquinas de mis ojos."

# game/script.rpy:321
translate Paloslios prologue_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:323
translate Paloslios prologue_5e800618:

    # "At least I have my snacks."
    "Al menos tengo mis bocadillos."

# game/script.rpy:325
translate Paloslios prologue_2529d1d4:

    # "My hand reaches down to rummage the bottom of the bag, feeling around for what I could get my hands on. I feel something wrapped in plastic, and pull it out."
    "Mi mano se extiende para hurgar en el fondo de la bolsa, sintiendo lo que podría tener en mis manos. Siento algo envuelto en plástico y lo saqué."

# game/script.rpy:327
translate Paloslios prologue_2e2648aa:

    # "I grabbed an off-brand “healthy” granola bar that was coated in chocolate and some caramel drizzle. Not exactly the most exciting choice but fuck it, I needed something to chew on."
    "Agarré una barra de granola \"saludable\" fuera de marca que estaba cubierta de chocolate y algo de llovizna de caramelo. No es exactamente la opción más emocionante, pero jódelo, necesitaba algo para masticar."

# game/script.rpy:329
translate Paloslios prologue_8a66da49:

    # "I struggled with the wrapping, it was getting in between me and my pseudo-healthy crunchy bar."
    "Luché con el envoltorio, se estaba metiendo entre mí y mi pseudo saludable bar crujiente."

# game/script.rpy:335
translate Paloslios prologue_cc9a5909:

    # "!!!"
    "!"

# game/script.rpy:337
translate Paloslios prologue_557cde31:

    # "The deafening silence was disturbed by what seemed like the sound of a twig snapping..."
    "El silencio ensordecedor estaba perturbado por lo que parecía el sonido de una ramita que se rompe ..."

# game/script.rpy:341
translate Paloslios prologue_59ab87df:

    # "My legs lock me in place as I shoot upwards in fear. What the hell made that noise? I was starting to get the sense I wasn't the only one here and that I was being watched."
    "Mis piernas me encierran en su lugar mientras disparo con miedo. ¿Qué diablos hizo ese ruido? Estaba empezando a tener la sensación de que no era el único aquí y que estaba siendo observado."

# game/script.rpy:343
translate Paloslios prologue_91cc0098:

    # u "Calm down, [name]. Maybe it was just an animal."
    u "Cálmate, [name]. Tal vez era solo un animal."

# game/script.rpy:348
translate Paloslios prologue_31d3d1f5:

    # u "Or maybe not. Of course I would be murdered in the most cliche way ever."
    u "O tal vez no. Por supuesto, sería asesinado de la manera más cliché de la historia."

# game/script.rpy:352
translate Paloslios prologue_8cc59ebb:

    # "My eyes frantically dart around looking for an exit. I wanted to run far, far away from whatever was approaching."
    "Mis ojos se lanzan frenéticamente buscando una salida. Quería correr muy, muy lejos de lo que se estaba acercando."

# game/script.rpy:354
translate Paloslios prologue_91cc0098_1:

    # u "Calm down, [name]. Maybe it was just an animal."
    u "Cálmate, [name]. Tal vez era solo un animal."

# game/script.rpy:359
translate Paloslios prologue_19d68759:

    # u "Or maybe not. Fuck I'm not ready to die!"
    u "O tal vez no. ¡Joder, no estoy listo para morir!"

# game/script.rpy:367
translate Paloslios prologue_bf31bca6:

    # "I gawk at a pair of glowing, predatorial eyes emerging from the flora of the forest."
    "Me miro a un par de ojos brillantes y depredadores que emergen de la flora del bosque."

# game/script.rpy:373
translate Paloslios prologue_461485b3:

    # "My heart was racing, and I could feel my blood running cold."
    "Mi corazón estaba acelerando y podía sentir que mi sangre se enfría."

# game/script.rpy:375
translate Paloslios prologue_0793db41:

    # "I think... He was getting closer to me."
    "Creo que ... se estaba acercando a mí."

# game/script.rpy:380
translate Paloslios prologue_b4bfbcf1:

    # "I didn't have anything else I could do. I huddled myself, trying to desperately appear small like some kind of scared animal, not putting up a fight."
    "No tenía nada más que pudiera hacer. Me acurrucé, tratando de parecer desesperadamente pequeño como algún tipo de animal asustado, sin pelear."

# game/script.rpy:382
translate Paloslios prologue_a839467f:

    # "I let out more of a yelp than a scream, out of sheer desperation, I threw a random snack from my bag at them. Is that all I could really muster?"
    "Dejé escapar más un grito que un grito, por pura desesperación, les tiré un refrigerio al azar de mi bolso. ¿Eso es todo lo que realmente podría reunir?"

# game/script.rpy:383
translate Paloslios prologue_66c28742:

    # "Nothing but a pathetic call for help? I shut my eyes, waiting for some sort of shock or a hit on the head but-"
    "¿Nada más que un llamado patético para obtener ayuda? Cierra los ojos, esperando algún tipo de conmoción o un golpe en la cabeza pero"

# game/script.rpy:387
translate Paloslios prologue_52ecd406:

    # voice "audio/MDHM_Alan voicelines/Prologue + Day 1/01_ Are ya lost.mp3"
    # a "Um... Are ya lost?"
    voice "audio/mdhm_alan VoicElines/Prologue + Day 1/01_ Are YA Lost.mp3"
    a "Um ... ¿estás perdido?"

# game/script.rpy:390
translate Paloslios prologue_f5d8c517:

    # "I hear a concerned voice."
    "Escucho una voz preocupada."

# game/script.rpy:392
translate Paloslios prologue_4be2b397:

    # "Cautiously, I lowered my guard, taking a peek at who exactly was in front of me."
    "Con cautela, bajé mi guardia, echando un vistazo a quién estaba exactamente frente a mí."

# game/script.rpy:396
translate Paloslios prologue_5bed0a04:

    # u "Stay the hell away from me!"
    u "¡Manténgase lejos de mí!"

# game/script.rpy:398
translate Paloslios prologue_3ea01ccc:

    # "I look around for anything to use as a weapon. Now I regret tossing that cool stick aside while on my way back."
    "Busco cualquier cosa para usar como arma. Ahora me arrepiento de dejar ese palo genial a un lado mientras regresa."

# game/script.rpy:400
translate Paloslios prologue_83c08d04:

    # "Wait! My snacks!"
    "¡Esperar! Mis bocadillos!"

# game/script.rpy:402
translate Paloslios prologue_3c262f74:

    # "I grabbed my plastic bag, while not weighted in the slightest, I could throw a snack or two to make him at least mildly annoyed."
    "Agarré mi bolsa de plástico, aunque no estaba pesada en lo más mínimo, pude lanzar un refrigerio o dos para que al menos se moleste."

# game/script.rpy:403
translate Paloslios prologue_3e548c1f:

    # "I also pointed my granola bar at him, like some kind of sword."
    "También le señalé mi bar de granola, como una especie de espada."

# game/script.rpy:405
translate Paloslios prologue_36bcc2e1:

    # "Not exactly the most threatening sight."
    "No es exactamente la vista más amenazante."

# game/script.rpy:407
translate Paloslios prologue_bfc869c1:

    # u "If you're gonna try to kill me you're gonna work for it! And you better hope I don't turn the tables!"
    u "¡Si vas a intentar matarme, vas a trabajar para ello! ¡Y mejor, espero que no gire las mesas!"

# game/script.rpy:414
translate Paloslios prologue_415fe999:

    # voice "audio/MDHM_Alan voicelines/Prologue + Day 1/02_ How cute.mp3"
    # a "How cute."
    voice "audio/mdhm_alan VoicElines/Prologue + Day 1/02_ que lindo.mp3"
    a "Que lindo."

# game/script.rpy:424
translate Paloslios prologue_272a86ac:

    # "I couldn't make out his features well, but his hair stuck every which way out of his head. He appeared to be holding something..."
    "No pude distinguir bien sus rasgos, pero su cabello se quedó fuera de su cabeza. Parecía estar sosteniendo algo ..."

# game/script.rpy:426
translate Paloslios prologue_334760d7:

    # "A hatchet."
    "Un hacha."

# game/script.rpy:429
translate Paloslios prologue_59dc79b3:

    # a "Something wrong? You look like you've seen a ghost."
    a "¿Ocurre algo? Parece que has visto un fantasma."

# game/script.rpy:431
translate Paloslios prologue_be7a2201:

    # "This guy seemed oblivious to the situation at play here. I was so stunned I couldn't even speak."
    "Este tipo parecía ajeno a la situación en juego aquí. Estaba tan aturdido que ni siquiera podía hablar."

# game/script.rpy:432
translate Paloslios prologue_b65bc07f:

    # "My eyes were too focused on the hatchet he had resting across his shoulder, just so casual-like."
    "Mis ojos estaban demasiado enfocados en el hacha que tenía descansando sobre su hombro, tan casual."

# game/script.rpy:435
translate Paloslios prologue_de7e7a99:

    # "The guy tilts his head to the side, confused by my uneasiness."
    "El tipo inclina la cabeza hacia un lado, confundida por mi inquietud."

# game/script.rpy:438
translate Paloslios prologue_1705eb24:

    # a "Oh! This."
    a "¡Oh! Este."

# game/script.rpy:440
translate Paloslios prologue_1d9f3167:

    # "He held one of his hands up before letting the hatchet slip from his fingers onto the patch of grass beneath him, moving slowly to emphasize that he was harmless."
    "Sostuvo una de sus manos antes de dejar que el hacha se deslizara de sus dedos sobre el parche de hierba debajo de él, moviéndose lentamente para enfatizar que era inofensivo."

# game/script.rpy:442
translate Paloslios prologue_7f315b9b:

    # "He did all of this while putting up a friendly smile."
    "Hizo todo esto mientras puso una sonrisa amistosa."

# game/script.rpy:444
translate Paloslios prologue_51935d33:

    # a "Take it easy. I'm not gonna hurt ya'. Are ya lost?"
    a "Tómalo con calma. No voy a lastimarte '. ¿Estás perdido?"

# game/script.rpy:447
translate Paloslios prologue_cd3a04f4:

    # u "Oh Yeah? What makes you think I can trust some guy with an ax in the middle of the forest like it's nothing?!"
    u "¿Oh sí? ¿Qué te hace pensar que puedo confiar en un tipo con un hacha en el medio del bosque como si no fuera nada?"

# game/script.rpy:450
translate Paloslios prologue_cbf7e9c9:

    # "The stranger only replied to my question with a smile. It was only making me more nervous."
    "El extraño solo respondió a mi pregunta con una sonrisa. Solo me estaba poniendo más nervioso."

# game/script.rpy:452
translate Paloslios prologue_6ce93f28:

    # u "Well? Answer me."
    u "¿Bien? Contestarme."

# game/script.rpy:454
translate Paloslios prologue_6aed5513:

    # a "It's a hatchet."
    a "Es un hacha."

# game/script.rpy:456
translate Paloslios prologue_8b258704:

    # u "Huh?"
    u "¿Eh?"

# game/script.rpy:459
translate Paloslios prologue_05928d16:

    # a "It's a hatchet, not an ax."
    a "Es un hacha, no un hacha."

# game/script.rpy:463
translate Paloslios prologue_8eb4532a:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Laugh.mp3"
    # "I blink at him. Was he mocking me? Is this all just one big joke at me for him to laugh at? He was acting way too casual and didn't try to pull anything once."
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_laugh.mp3"
    "Parpadeo hacia él. ¿Se estaba burlando de mí? ¿Es todo esto solo una gran broma para que él se ría? Estaba actuando demasiado informal y no trató de tirar de nada una vez."

# game/script.rpy:467
translate Paloslios prologue_14c3464a:

    # "Was I overreacting? I didn't put down any of my defenses though, as I continued to eye him suspiciously."
    "¿Estaba exagerando? Sin embargo, no dejé ninguna de mis defensas, ya que seguí mirándolo sospechosamente."

# game/script.rpy:470
translate Paloslios prologue_e5512856:

    # a "Are you gonna answer my question now?"
    a "¿Vas a responder mi pregunta ahora?"

# game/script.rpy:473
translate Paloslios prologue_4ba35e0d:

    # "He continued to have that small, almost innocent smile plastered on his face."
    "Continuó teniendo esa pequeña sonrisa casi inocente en su rostro."

# game/script.rpy:477
translate Paloslios prologue_0b3ca4f3:

    # "I let out a huff, rolling my eyes."
    "Dejé escapar un resoplido, rodando los ojos."

# game/script.rpy:479
translate Paloslios prologue_355f0c46:

    # u "Answer mine first."
    u "Responde el mío primero."

# game/script.rpy:483
translate Paloslios prologue_4e41f4d2:

    # "Slowly, but still cautiously, I lowered my guard. However, my eyes stayed glued to him, waiting for the moment he may do something unexpected."
    "Lentamente, pero aún con cautela, bajé mi guardia. Sin embargo, mis ojos se mantuvieron pegados a él, esperando el momento en que pueda hacer algo inesperado."

# game/script.rpy:485
translate Paloslios prologue_355f0c46_1:

    # u "Answer mine first."
    u "Responde el mío primero."

# game/script.rpy:487
translate Paloslios prologue_e1f5419f:

    # "He let out a chuckle at my response. I noticed his movements weren't threatening and seemed to be casual."
    "Él dejó escapar una risa por mi respuesta. Noté que sus movimientos no eran amenazantes y parecían ser casuales."

# game/script.rpy:489
translate Paloslios prologue_4690790e:

    # a "Alright, alright, I'll comply."
    a "Muy bien, está bien, cumpliré."

# game/script.rpy:491
translate Paloslios prologue_d973dc84:

    # "He put his arms up, almost like he was trying to surrender and play off my interrogation."
    "Levantó los brazos, casi como si estuviera tratando de rendirse y jugar con mi interrogatorio."

# game/script.rpy:494
translate Paloslios prologue_18fa671e:

    # a "Would ya rather be stuck in the woods then?"
    a "¿Preferiría estar atrapado en el bosque entonces?"

# game/script.rpy:496
translate Paloslios prologue_a20cefa7_3:

    # "..."
    "..."

# game/script.rpy:498
translate Paloslios prologue_5bbbfbee:

    # u "... No."
    u "... No."

# game/script.rpy:501
translate Paloslios prologue_cfe35a3d:

    # a "Then you should trust me."
    a "Entonces deberías confiar en mí."

# game/script.rpy:503
translate Paloslios prologue_9e2cf54d:

    # u "Easier said than done."
    u "Más fácil decirlo que hacerlo."

# game/script.rpy:505
translate Paloslios prologue_4249a376:

    # "He placed a hand over his mouth, trying to hold back a chuckle at my snarky remark."
    "Se colocó una mano sobre su boca, tratando de contener una sonrisa ante mi comentario sarcástico."

# game/script.rpy:509
translate Paloslios prologue_8d655865:

    # voice "audio/MDHM_Alan voicelines/Noises/Neutral/Alan_Well.mp3"
    voice "audio/mdhm_alan VoicElines/ruidos/neutral/alan_well.mp3"

# game/script.rpy:512
translate Paloslios prologue_71618e50:

    # a "You got me there. But do ya know how to navigate your way back?"
    a "Me tienes allí. ¿Pero sabes cómo navegar de regreso?"

# game/script.rpy:514
translate Paloslios prologue_d39747af:

    # u "Do you?"
    u "¿Tú?"

# game/script.rpy:516
translate Paloslios prologue_d55652bb:

    # "There was a small beat of silence before he raised his hand. He was wearing brown, fingerless gloves."
    "Hubo un pequeño ritmo de silencio antes de levantar la mano. Llevaba guantes marrones y sin dedo."

# game/script.rpy:519
translate Paloslios prologue_0d595f1f:

    # a "I know these woods like the back of my hand, you learn a thing or two when you live out here. I'll even walk in front of ya so you don't feel all antsy."
    a "Sé que estos bosques como el dorso de mi mano, aprendes una o dos cosas cuando vives aquí. Incluso caminaré frente a ti para que no te sientas ansioso."

# game/script.rpy:521
translate Paloslios prologue_9bbbcd63:

    # "I took a few seconds to think over his offer. I didn't exactly want to be stuck here forever until my body got discovered by a search party or eaten by vultures."
    "Tomé unos segundos para pensar en su oferta. No quería exactamente quedar atrapado aquí para siempre hasta que mi cuerpo fuera descubierto por una fiesta de búsqueda o comido por buitres."

# game/script.rpy:523
translate Paloslios prologue_30d2b0a8:

    # "Whoever this guy was, he was the best choice I had for now."
    "Quienquiera que fuera este tipo, fue la mejor opción que tuve por ahora."

# game/script.rpy:525
translate Paloslios prologue_56f008fc:

    # u "Fine. Lead the way."
    u "Bien. Liderar el camino."

# game/script.rpy:528
translate Paloslios prologue_5af406b1:

    # "He smiled at me, reaching down to the ground and picking up his sturdy hatchet, perfectly sticking out from the soft tufts of grass. He swung the tool back on his shoulder."
    "Él me sonrió, llegando al suelo y recogiendo su sólido hacha, sobresaliendo perfectamente de los suaves mechones de hierba. Él volvió a girar la herramienta sobre su hombro."

# game/script.rpy:530
translate Paloslios prologue_2da21d9a:

    # u "If I catch you doing anything remotely suspicious, I'll start swinging."
    u "Si te veo haciendo algo remotamente sospechoso, comenzaré a balancearse."

# game/script.rpy:532
translate Paloslios prologue_e2fe0f57:

    # a "I hear ya loud n' clear."
    a "Te escucho fuerte y claro."

# game/script.rpy:538
translate Paloslios prologue_59efab3a:

    # "He offered me his hand, I could barely make out the callouses and a few scratches from his hand. I was still a bit hesitant, but I took it anyway."
    "Me ofreció su mano, apenas podía distinguir los callos y algunos rasguños de su mano. Todavía dudaba un poco, pero lo tomé de todos modos."

# game/script.rpy:541
translate Paloslios prologue_779a8145:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Let_s go.mp3"
    # a "Let's get going and get ya somewhere safer."
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_let_s go.mp3"
    a "Vamos a ir y llevarte a un lugar más seguro."

# game/script.rpy:545
translate Paloslios prologue_b07d15cf:

    # "His grip was surprisingly strong, but he wasn't squeezing my hand or anything."
    "Su agarre era sorprendentemente fuerte, pero no estaba apretando mi mano ni nada."

# game/script.rpy:547
translate Paloslios prologue_704da877:

    # "The trees were becoming less dense the more we walked together with the light of the moon guiding us through the foliage."
    "Los árboles se volvían menos densos cuanto más caminamos junto con la luz de la luna que nos guiaba a través del follaje."

# game/script.rpy:548
translate Paloslios prologue_3abf3896:

    # "Now and again, he would give me small glances, and in return, I got a better glimpse of his features."
    "De vez en cuando, me daba pequeñas miradas, y a cambio, obtuve una mejor visión de sus rasgos."

# game/script.rpy:550
translate Paloslios prologue_9c5577df:

    # "Particularly, his eyes were the most noticeable. Both of them are a different color. I couldn't help but stare at them like I had spotted a rare creature in the wild."
    "Particularmente, sus ojos fueron los más notables. Ambos son un color diferente. No pude evitar mirarlos como si hubiera visto a una criatura rara en la naturaleza."

# game/script.rpy:552
translate Paloslios prologue_ac129d7d:

    # a "I don't think I have seen ya before. Are ya new around by any chance?"
    a "No creo que te haya visto antes. ¿Eres nuevo por casualidad?"

# game/script.rpy:554
translate Paloslios prologue_f849b335:

    # "I was a bit caught off by surprise, not expecting him to bring up a conversation. I just realized that I had been looking up at him without saying a word."
    "Estaba un poco sorprendido por sorpresa, sin esperar que él mencionara una conversación. Me acabo de dar cuenta de que lo había estado mirando sin decir una palabra."

# game/script.rpy:556
translate Paloslios prologue_dc9b6ce0:

    # u "Well- I moved from the next town over, not too long ago."
    u "Bueno, me mudé de la siguiente ciudad, no hace mucho."

# game/script.rpy:558
translate Paloslios prologue_b1077940:

    # "He perked up with interest."
    "Se animó con interés."

# game/script.rpy:560
translate Paloslios prologue_d7761981:

    # a "What made you decide to stay in good ol' Doomsbury?"
    a "¿Qué te hizo decidir quedarte en el buen doomsbury?"

# game/script.rpy:562
translate Paloslios prologue_4b89291b:

    # "I merely shrugged at him. I had lots of reasons for staying here."
    "Simplemente me encogí de hombros. Tenía muchas razones para quedarme aquí."

# game/script.rpy:564
translate Paloslios prologue_7ddea3e8:

    # "I doubt this guy wants to hear about my problems, and to be frank he was a near perfect stranger. I won't spill my guts but I'll tell him something."
    "Dudo que este tipo quiera escuchar sobre mis problemas, y ser sincero, él era un extraño casi perfecto. No me derramaré las entrañas, pero le diré algo."

# game/script.rpy:566
translate Paloslios prologue_630606ce:

    # u "Wanted to get out of my bubble, to put it simply. Doomsbury University seemed like the best school for me."
    u "Quería salir de mi burbuja, para decirlo en pocas palabras. La Universidad de Doomsbury parecía la mejor escuela para mí."

# game/script.rpy:568
translate Paloslios prologue_092f60cb:

    # a "How is that going for ya?"
    a "¿Cómo va eso para ti?"

# game/script.rpy:570
translate Paloslios prologue_7dc7b735:

    # u "Oh you know."
    u "Oh, ya sabes."

# game/script.rpy:572
translate Paloslios prologue_a6a4a4e5:

    # u "Perfect. Fine. Super."
    u "Perfecto. Bien. Súper."

# game/script.rpy:577
translate Paloslios prologue_80dc6b30:

    # voice "audio/MDHM_Alan voicelines/Prologue + Day 1/03_That bad.mp3"
    # a "Oh. That bad, huh?"
    voice "audio/mdhm_alan VoicElines/Prologue + Day 1/03_That Bad.mp3"
    a "Oh. Eso es malo, ¿eh?"

# game/script.rpy:580
translate Paloslios prologue_c349e78c:

    # "I cringed. So much for being vague and mysterious."
    "Me encogí. Demasiado por ser vago y misterioso."

# game/script.rpy:582
translate Paloslios prologue_9ec1a989:

    # a "Heheh."
    a "Jeje."

# game/script.rpy:584
translate Paloslios prologue_6b3c6e98:

    # "The guy chuckled more under his breath as he continued to guide me through the trees and bushes."
    "El tipo se rió más bajo su aliento mientras continuaba guiándome a través de los árboles y arbustos."

# game/script.rpy:585
translate Paloslios prologue_4ce497af:

    # "We both stayed silent, occasionally shattering the silence with small talk, he could tell I was uneasy around him."
    "Ambos nos quedamos en silencio, ocasionalmente rompiendo el silencio con una pequeña charla, podía decir que estaba inquieto a su alrededor."

# game/script.rpy:587
translate Paloslios prologue_bd6a7820:

    # "He seemed a bit sullen, like he had been looking forward to talking with me. My short responses and constant fidgeting told him that I was still on my guard."
    "Parecía un poco hosco, como si hubiera estado esperando hablar conmigo. Mis respuestas cortas y mis constantes inquietantes le dijeron que todavía estaba en guardia."

# game/script.rpy:588
translate Paloslios prologue_d29ec873:

    # "Not that he blamed me, he was sure he'd be cautious of some dude with a hatchet too."
    "No es que me culpara, estaba seguro de que también sería cauteloso con un tipo con un hacha."

# game/script.rpy:590
translate Paloslios prologue_6a8f908c:

    # "As we continued our trek, the tension we had before slowly dissipated and I stopped being afraid of my own shadow."
    "Mientras continuamos nuestra caminata, la tensión que teníamos antes de disipar lentamente y dejé de tener miedo de mi propia sombra."

# game/script.rpy:597
translate Paloslios prologue_111d8147:

    # "With time, the unkempt dirt path of the woods merges with the edge of the sidewalk, a sign of civilization! What a relief! I could practically kiss the ground right now!"
    "Con el tiempo, el camino de tierra descuidado del bosque se fusiona con el borde de la acera, ¡un signo de civilización! ¡Qué alivio! ¡Prácticamente podría besar el suelo ahora mismo!"

# game/script.rpy:601
translate Paloslios prologue_201e212a:

    # a "Looks like we finally made it."
    a "Parece que finalmente lo logramos."

# game/script.rpy:603
translate Paloslios prologue_ebd5b7e3:

    # u "Oh my god, thank you! Geez, I owe you one..."
    u "¡Dios mío, gracias! Dios, te debo uno ..."

# game/script.rpy:605
translate Paloslios prologue_d898785a:

    # "I finally let go of his hand, stuffing mine into my pockets."
    "Finalmente solté su mano, metiendo la mía en mis bolsillos."

# game/script.rpy:607
translate Paloslios prologue_7e67497e:

    # a "Don't mention it, it wasn't an issue at all."
    a "No lo menciones, no fue un problema en absoluto."

# game/script.rpy:609
translate Paloslios prologue_0f46a42f:

    # "I turn over to him, scratching the back of my neck and feeling the chills of the cold air tickling my skin."
    "Me doy la vuelta a él, rascándome la parte posterior de mi cuello y sintiendo los escalofríos del aire frío que le hacía cosquillas en mi piel."

# game/script.rpy:612
translate Paloslios prologue_c2281ecc:

    # u "Listen, you didn't murder me, and that's all I could ask for. I should at least return the favor."
    u "Escucha, no me asesinaste, y eso es todo lo que pude pedir. Al menos debería devolver el favor."

# game/script.rpy:615
translate Paloslios prologue_e99da648:

    # "The guy didn't even give it a thought, as he grinned ear to ear."
    "El tipo ni siquiera lo pensó, ya que sonrió de oreja a oreja."

# game/script.rpy:617
translate Paloslios prologue_17150b6c:

    # a "Tomorrow. Meet me back in the woods and we could get some more snacks from that place."
    a "Mañana. Encuéntrame en el bosque y podríamos obtener más bocadillos de ese lugar."

# game/script.rpy:619
translate Paloslios prologue_acc3075b:

    # "He pointed to my plastic bag."
    "Señaló mi bolsa de plástico."

# game/script.rpy:621
translate Paloslios prologue_8ef76bbb:

    # u "Oh! Sure thi-"
    u "¡Oh! Seguro que thi-"

# game/script.rpy:623
translate Paloslios prologue_1818699f:

    # "It wasn't until I looked down at it that and saw a decently sized hole had torn its way. Only a few of my snacks have survived. It must've ripped along the way."
    "No fue hasta que lo miré y vi que un agujero de tamaño decente había desgarrado. Solo unos pocos de mis bocadillos han sobrevivido. Debe haber destrozado el camino."

# game/script.rpy:625
translate Paloslios prologue_28c2ea6a:

    # "I groaned."
    "Gimí."

# game/script.rpy:628
translate Paloslios prologue_e52214e1:

    # u "Are you kidding me? That was my dinner!"
    u "¿Me estás tomando el pelo? Esa fue mi cena!"

# game/script.rpy:631
translate Paloslios prologue_db9d97d7:

    # a "I'll get you some more stuff tomorrow. Deal?"
    a "Mañana te conseguiré algunas cosas más. ¿Trato?"

# game/script.rpy:633
translate Paloslios prologue_a3b1bf36:

    # "I looked at him with sad, tired eyes. He gave me a sympathetic smile. For some reason, I trusted him. I don't know how else I could explain it."
    "Lo miré con ojos tristes y cansados. Me dio una sonrisa comprensiva. Por alguna razón, confié en él. No sé cómo podría explicarlo."

# game/script.rpy:635
translate Paloslios prologue_e7c5e154:

    # u "Deal, and thanks, again. I'll see you around then..."
    u "Trato, y gracias, de nuevo. Te veré entonces ..."

# game/script.rpy:640
translate Paloslios prologue_eb6a297d:

    # "He continued to stand in his place while I turned my back from the woods, walking into my neighborhood once again."
    "Continuó parado en su lugar mientras yo giraba la espalda del bosque, entrando en mi vecindario una vez más."

# game/script.rpy:641
translate Paloslios prologue_64532307:

    # "Stopping at the front door, I gave him one last wave. I couldn't tell from the distance, but he seemed to wave back."
    "Deteniéndome en la puerta principal, le di una última ola. No podía decir desde la distancia, pero parecía retroceder."

# game/script.rpy:649
translate Paloslios prologue_2651e3ba:

    # u "I'm so tired..."
    u "Estoy tan cansado..."

# game/script.rpy:655
translate Paloslios prologue_6eb8c50c:

    # "Exhausted, I immediately threw myself onto my bed, tossing the plastic bag on the floor. Finally, I can get some rest."
    "Agotado, inmediatamente me arrojé a mi cama, arrojando la bolsa de plástico al piso. Finalmente, puedo descansar un poco."

# game/script.rpy:656
translate Paloslios prologue_43e029c2:

    # "God, my feet are already aching. How long did I walk? It seems incredibly late. My eyes... They feel heavy..."
    "Dios, mis pies ya están doliendo. ¿Cuánto tiempo caminé? Parece increíblemente tarde. Mis ojos ... se sienten pesados ..."

# game/script.rpy:658
translate Paloslios prologue_ce72ba39:

    # "Whoever that guy was..."
    "Quienquiera que fuera ese tipo ..."

# game/script.rpy:660
translate Paloslios prologue_e7f04dc1:

    # "Wait. I didn't get his name."
    "Esperar. No obtuve su nombre."

# game/script.rpy:662
translate Paloslios prologue_b2d9b2c7:

    # "I'll ask him tomorrow."
    "Le preguntaré mañana."

# game/script.rpy:667
translate Paloslios prologue_b8f2577f:

    # "I feel heavy... Like I can't get up."
    "Me siento pesado ... como si no pudiera levantarme."

# game/script.rpy:671
translate Paloslios prologue_a20cefa7_4:

    # "..."
    "..."

# game/script.rpy:673
translate Paloslios prologue_b9aeae8b:

    # "Something is on top of me-!"
    "Algo está encima de mí-!"

# game/script.rpy:675
translate Paloslios prologue_cc9a5909_1:

    # "!!!"
    "!"

# game/script.rpy:681
translate Paloslios prologue_33aca463:

    # "Oh god. How long did I sleep? I must've passed out and slept like a rock."
    "Oh Dios. ¿Cuánto tiempo dormí? Debo haberme desmayado y dormido como una roca."

# game/script.rpy:686
translate Paloslios prologue_a20cefa7_5:

    # "..."
    "..."

# game/script.rpy:688
translate Paloslios prologue_6c012bb7:

    # "Last night..."
    "Anoche..."

# game/script.rpy:690
translate Paloslios prologue_baabd0c7:

    # "Oh yeah. I got lost in the woods, met a strange dude after he scared the living daylights out of me, and he promised me some snacks for today. I feel some mix of comforting jitters sinking in."
    "Oh sí. Me perdí en el bosque, conocí a un tipo extraño después de que me asustó la luz del día y me prometió algunos bocadillos por hoy. Siento que se hunde una mezcla de nerviosistas reconfortantes."

# game/script.rpy:692
translate Paloslios prologue_651350ce:

    # "It hasn't been long since I've moved in and I wasn't exactly rubbing shoulders with my neighbors but I still talked to them."
    "No ha pasado mucho tiempo desde que me mudé y no me froté exactamente con mis vecinos, pero aún así hablé con ellos."

# game/script.rpy:693
translate Paloslios prologue_63a974f0:

    # "I never heard them mention anything about a man living in the forest. If they knew, they would've given me a heads-up and I probably would've reacted differently."
    "Nunca los escuché mencionar nada sobre un hombre que vive en el bosque. Si supieran, me habrían dado un aviso y probablemente habría reaccionado de manera diferente."

# game/script.rpy:695
translate Paloslios prologue_6de00524:

    # "... Right?"
    "... ¿Bien?"

# game/script.rpy:697
translate Paloslios prologue_f33ffb87:

    # "Was I overthinking this?"
    "¿Estaba pensando demasiado?"

# game/script.rpy:699
translate Paloslios prologue_a20cefa7_6:

    # "..."
    "..."

# game/script.rpy:701
translate Paloslios prologue_abc3ff42:

    # "Probably."
    "Probablemente."

# game/script.rpy:706
translate Paloslios prologue_7daf5d6e:

    # "I should probably check my phone."
    "Probablemente debería revisar mi teléfono."

# game/script.rpy:708
translate Paloslios prologue_b647a4ed:

    # "I held the button on the side, tapping my foot as I waited for it to light up. My home screen brightens as the notifications trickle onto it."
    "Sostuve el botón al costado, golpeando mi pie mientras esperaba a que se iluminara. Mi pantalla de inicio se ilumina a medida que las notificaciones gotan en ella."

# game/script.rpy:710
translate Paloslios prologue_ade4ab8e:

    # "An unknown number..."
    "Un número desconocido ..."

# game/script.rpy:712
translate Paloslios prologue_62bb7cfa:

    # e "{i}Hey.{/i}"
    e "{i} hey. {/i}"

# game/script.rpy:713
translate Paloslios prologue_865325c3:

    # e "{i}Sorry to bother you. What chapter are we studying for Prof. Mocroix?{/i}"
    e "{i} Lamento molestarte. ¿Qué capítulo estamos estudiando para el Prof. Mocroix? {/i}"

# game/script.rpy:715
translate Paloslios prologue_d6e71d55:

    # e "{i}This is Erika btw.{/i}"
    e "{i} Esto es Erika por cierto. {/i}"

# game/script.rpy:717
translate Paloslios prologue_45959e04:

    # "Ah."
    "Ah."

# game/script.rpy:719
translate Paloslios prologue_daa3fd61:

    # "Erika, ah yeah she's a part of my English class... I think we exchanged phone numbers because our professor recommended it."
    "Erika, Ah sí, ella es parte de mi clase de inglés ... Creo que intercambiamos números de teléfono porque nuestro profesor lo recomendó."

# game/script.rpy:720
translate Paloslios prologue_a21a7ac6:

    # "Initially, I didn't plan to ask for anyone's number, especially since I didn't know anyone in that class. I barely even talked to them other than occasionally asking someone for a pencil."
    "Inicialmente, no planeé pedir el número de nadie, especialmente porque no conocía a nadie en esa clase. Apenas hablé con ellos, aparte de ocasionalmente pedirle a alguien un lápiz."

# game/script.rpy:722
translate Paloslios prologue_84b4a68f:

    # "Erika was the one to approach me first. She wasn't talkative either, only answered questions sometimes and gave snarky remarks on a whim."
    "Erika fue quien se acercó a mí primero. Ella tampoco era habladora, solo respondió preguntas a veces y daba comentarios sarcásticos por capricho."

# game/script.rpy:723
translate Paloslios prologue_e80259ca:

    # "I didn't know much about her, other than she'd be a constant center of attention with her outfits."
    "No sabía mucho sobre ella, aparte de que ella sería un centro de atención constante con sus atuendos."

# game/script.rpy:725
translate Paloslios prologue_0162ddbc:

    # "She had a keen eye for fashion and she would constantly amaze me with how she would walk into class. She'd breeze in effortlessly like a runway model."
    "Tenía un buen ojo para la moda y constantemente me sorprendería cómo entraría en clase. Ella se esforzaría sin esfuerzo como una modelo de pista."

# game/script.rpy:726
translate Paloslios prologue_af3f2c0e:

    # "Some outfits were her projects for her fashion design class, others were simply her wanting to look good that day."
    "Algunos atuendos eran sus proyectos para su clase de diseño de moda, otros simplemente querían verse bien ese día."

# game/script.rpy:728
translate Paloslios prologue_9aced3d7:

    # "It was pretty surprising to find out that she was majoring in interior design. She'd be the chicest interior designer that's for sure."
    "Fue bastante sorprendente descubrir que se estaba especializando en el diseño de interiores. Ella sería la diseñadora de interiores más elegante que es segura."

# game/script.rpy:730
translate Paloslios prologue_3e74c88b:

    # "Erika seemed like she had her shit together, from what I could glean from the few times I spoke to her."
    "Erika parecía que tenía su mierda juntos, por lo que podía obtener de las pocas veces que le hablé."

# game/script.rpy:732
translate Paloslios prologue_8334eeac:

    # u "{i}Chapter 4.{/i}"
    u "{i} Capítulo 4. {/i}"

# game/script.rpy:734
translate Paloslios prologue_f1371119:

    # "I send the text and proceed to let out a groan while dragging myself up from my bed. I would much rather sleep the day away but I was promised snacks!"
    "Envío el mensaje de texto y procedo a dejar escapar un gemido mientras me arrastra de mi cama. ¡Preferiría dormir todo el día, pero me prometieron bocadillos!"

# game/script.rpy:737
translate Paloslios prologue_0c69d748:

    # "It's been the first time in a while that I've been motivated to do something other than rot in my room."
    "Ha sido la primera vez en un tiempo que he estado motivado para hacer algo más que pudrirse en mi habitación."

# game/script.rpy:739
translate Paloslios prologue_8038d5d9:

    # "Damn..."
    "Maldición..."

# game/script.rpy:741
translate Paloslios prologue_a20cefa7_7:

    # "..."
    "..."

# game/script.rpy:743
translate Paloslios prologue_8c5f5a36:

    # "That's kinda sad."
    "Eso es un poco triste."

# game/script.rpy:748
translate Paloslios prologue_42f37fc1:

    # e "{i}Thanks =^.^={/i}"
    e "{i} gracias =^.^= {/i}"

# game/script.rpy:750
translate Paloslios prologue_d1dffac9:

    # "I chuckled at her response. That was kinda cute."
    "Me reí de su respuesta. Eso fue un poco lindo."

# game/script.rpy:755
translate Paloslios prologue_b6eb240d:

    # "Before I go out, I need to refuel for the day."
    "Antes de salir, necesito repostar el día."

# game/script.rpy:757
translate Paloslios prologue_6843fded:

    # "I reached out to the fridge, pulling with a bit of force thanks to how janky the handle had become over time."
    "Me acerqué al refrigerador, tirando con un poco de fuerza gracias a lo janky que se había vuelto el mango con el tiempo."

# game/script.rpy:759
translate Paloslios prologue_7894fa84:

    # u "I should get that looked at."
    u "Debería obtener eso."

# game/script.rpy:761
translate Paloslios prologue_672da709:

    # "Everything around this house needed some touch-ups though. Maybe I shouldn't have turned down the idea of having a roommate."
    "Sin embargo, todo alrededor de esta casa necesitaba algunos retoques. Tal vez no debería haber rechazado la idea de tener un compañero de cuarto."

# game/script.rpy:764
translate Paloslios prologue_aca9a6d3:

    # "But I do enjoy my privacy a lot and I wasn't keen on losing that anytime soon."
    "Pero disfruto mucho de mi privacidad y no estaba interesado en perder eso en el corto plazo."

# game/script.rpy:766
translate Paloslios prologue_d0b4e3eb:

    # "The cool air of the fridge nicked the tip of my nose, as my eyes searched for food."
    "El aire fresco de la nevera le quitó la punta de mi nariz, mientras mis ojos buscaban comida."

# game/script.rpy:768
translate Paloslios prologue_fdf53179:

    # "It was practically empty."
    "Estaba prácticamente vacío."

# game/script.rpy:773
translate Paloslios prologue_dc0a9d96:

    # "This could fill me up for the time being. It's been there for a while, might as well not let it go to waste."
    "Esto podría llenarme por el momento. Ha estado allí por un tiempo, también podría no dejarlo desperdiciar."

# game/script.rpy:777
translate Paloslios prologue_40b05b1d:

    # "Quick and easy. I'm craving something sweet too. Now where did I leave that bottle of syrup?"
    "Rápido y fácil. También estoy ansiando algo dulce. Ahora, ¿dónde dejé esa botella de jarabe?"

# game/script.rpy:781
translate Paloslios prologue_afcdad4a:

    # "It's not much but it's a classic staple for breakfast. Plain and simple. I don't have much to eat with it."
    "No es mucho, pero es un elemento básico clásico para el desayuno. Simple y llanamente. No tengo mucho para comer con eso."

# game/script.rpy:783
translate Paloslios prologue_e4003e45:

    # "A fried egg is the way to go then."
    "Un huevo frito es el camino a seguir entonces."

# game/script.rpy:806
translate Paloslios day1_8329569a:

    # "I squeeze my eyes shut, feeling attacked by the blinding glow of the sun."
    "Aprieto los ojos, sintiéndome atacado por el brillo cegador del sol."

# game/script.rpy:808
translate Paloslios day1_809bdc92:

    # u "... It's too bright today."
    u "... hoy es demasiado brillante."

# game/script.rpy:810
translate Paloslios day1_d913447c:

    # "I walk to the other side of the road, frisking to the overgrown forest again."
    "Camino hacia el otro lado de la carretera, freciendo hacia el bosque cubierto de vegetación nuevamente."

# game/script.rpy:815
translate Paloslios day1_29284ab3:

    # "I stuff my phone in my pocket. It wouldn't be of any use since my service couldn't reach in the middle of the woods. I walk through my familiar path, trying to remember where exactly the guy wanted to meet."
    "Llevo mi teléfono en mi bolsillo. No sería de ningún uso ya que mi servicio no pudo alcanzar en el medio del bosque. Camino por mi camino familiar, tratando de recordar dónde exactamente el chico quería encontrarse."

# game/script.rpy:817
translate Paloslios day1_c7382537:

    # "He was pretty vague on the details, telling me to simply “meet him in the woods.” Not gonna lie, it just hit me how sketchy that sounded."
    "Era bastante vago en los detalles, diciéndome que simplemente \"lo conozca en el bosque\". No voy a mentir, solo me golpeó lo incompleto que sonó."

# game/script.rpy:819
translate Paloslios day1_b7eb0b89:

    # "I fell into a daze, walking until everything around me looked strange."
    "Caí aturdido, caminando hasta que todo a mi alrededor se veía extraño."

# game/script.rpy:821
translate Paloslios day1_3819d0d8:

    # "Well, that didn't take long. I guess I just have to sit back and wait for him to find me."
    "Bueno, eso no tardó mucho. Supongo que solo tengo que sentarme y esperar a que me encuentre."

# game/script.rpy:826
translate Paloslios day1_3e4c74fc:

    # voice "audio/MDHM_Alan voicelines/Prologue + Day 1/04_You actually came.mp3"
    # a "Oh- You actually came..."
    voice "audio/mdhm_alan VoicElines/Prologue + Day 1/04_YOU realmente vino.mp3"
    a "Oh- realmente viniste ..."

# game/script.rpy:829
translate Paloslios day1_96ac5ab1:

    # "I heard his voice again. It sounded almost in disbelief. I turn around to face him, his eyes are wide but a smile slowly forms. He seemed happy to see me."
    "Escuché su voz de nuevo. Sonaba casi con incredulidad. Me doy la vuelta para mirarlo, sus ojos son anchos, pero se forma una sonrisa lentamente. Parecía feliz de verme."

# game/script.rpy:834
translate Paloslios day1_4a0265f2:

    # u "You thought I was gonna ditch you or something?"
    u "¿Pensaste que iba a abandonarte o algo?"

# game/script.rpy:837
translate Paloslios day1_e9dac30c:

    # a "W-Well... Maybe?"
    a "Bu-Bueno ... ¿tal vez?"

# game/script.rpy:839
translate Paloslios day1_cf72f988:

    # "He laughs nervously under his breath, scratching the back of his neck."
    "Se ríe nerviosamente por lo bajo, rascándose la parte posterior de su cuello."

# game/script.rpy:842
translate Paloslios day1_57e56f9b:

    # u "Like I said, I owe you one and I want my snacks. I can't turn down an offer like that."
    u "Como dije, te debo uno y quiero mis bocadillos. No puedo rechazar una oferta como esa."

# game/script.rpy:845
translate Paloslios day1_cb78085c:

    # "I got a chuckle out of him, easing him more and more into a conversation. It soon subsides again into an awkward silence. I shifted my eyes around, trying to think of what to say next."
    "Le quité una risa, aliviándolo cada vez más en una conversación. Pronto se reduce nuevamente en un silencio incómodo. Cambié los ojos, tratando de pensar en qué decir a continuación."

# game/script.rpy:848
translate Paloslios day1_0923cb3f:

    # u "Oh! Um, I didn't catch your name, stranger."
    u "¡Oh! Um, no atrapé tu nombre, extraño."

# game/script.rpy:850
translate Paloslios day1_bb8e4b4e:

    # a "..."
    a "..."

# game/script.rpy:853
translate Paloslios day1_a62b5eef:

    # a "I didn't throw it."
    a "No lo arrojé."

# game/script.rpy:855
translate Paloslios day1_a20cefa7:

    # "..."
    "..."

# game/script.rpy:860
translate Paloslios day1_05fd7fe3:

    # "I couldn't help but laugh, trying my best to stifle it."
    "No pude evitar reír, haciendo todo lo posible para sofocarlo."

# game/script.rpy:862
translate Paloslios day1_93416d4c:

    # u "Pfff! Are you serious? Jesus dude, just tell me your name!"
    u "¡Pfff! ¿Hablas en serio? ¡Jesús amigo, solo dime tu nombre!"

# game/script.rpy:864
translate Paloslios day1_823c61e7:

    # "I struggle to finish my sentence, every vowel would be interrupted by my laughing fit. It wasn't even that clever or funny."
    "Lucho por terminar mi oración, cada vocal sería interrumpida por mi reír. Ni siquiera fue tan inteligente o divertido."

# game/script.rpy:868
translate Paloslios day1_95997df7:

    # "Oh my god."
    "Ay dios mío."

# game/script.rpy:870
translate Paloslios day1_053a775c:

    # u "I can't believe you just said that. You're way too young to be making uncle jokes."
    u "No puedo creer que acabas de decir eso. Eres demasiado joven para hacer bromas del tío."

# game/script.rpy:872
translate Paloslios day1_38cd5156:

    # a "I couldn't resist."
    a "No pude resistirme."

# game/script.rpy:875
translate Paloslios day1_ec0974ee:

    # "He flashes a smile at me, one that was WAY too proud of himself for that line."
    "Me muestra una sonrisa, una que estaba demasiado orgullosa de sí mismo para esa línea."

# game/script.rpy:880
translate Paloslios day1_0410eb62:

    # a "Alan."
    a "Alan."

# game/script.rpy:882
translate Paloslios day1_3e7bc786:

    # u "Alan?"
    u "¿Alan?"

# game/script.rpy:884
translate Paloslios day1_438465ab:

    # a "Yup!"
    a "¡Sí!"

# game/script.rpy:889
translate Paloslios day1_eeca227d:

    # a "Alan Orion Constance Oateye Vimont the Third."
    a "Alan Orion Constance Oateye Vimont el tercero."

# game/script.rpy:891
translate Paloslios day1_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:893
translate Paloslios day1_8770ad32:

    # u "Is that really your full name?"
    u "¿Ese es realmente tu nombre completo?"

# game/script.rpy:895
translate Paloslios day1_41ad4c3e:

    # "I squint my eyes at him."
    "Presco mis ojos hacia él."

# game/script.rpy:899
translate Paloslios day1_64297bd4:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Laugh.mp3"
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_laugh.mp3"

# game/script.rpy:902
translate Paloslios day1_885214c8:

    # a "Heheh nope! It's just Alan Orion."
    a "Jejeh no! Es solo Alan Orion."

# game/script.rpy:904
translate Paloslios day1_89612068:

    # u "Wow. You're already lying to me, I can't believe you, Alan."
    u "Guau. Ya me estás mintiendo, no puedo creerte, Alan."

# game/script.rpy:906
translate Paloslios day1_ed84bd2f:

    # "I shot back at him in a snarky tone. Alan proceeds to place his arms behind his back, flashing his rather sharp teeth."
    "Le volví a disparar en un tono sarcástico. Alan procede a colocar sus brazos detrás de su espalda, mostrando sus dientes bastante afilados."

# game/script.rpy:908
translate Paloslios day1_3b08c971:

    # voice "audio/MDHM_Alan voicelines/Prologue + Day 1/05_Tell me your name.mp3"
    # a "Are ya gonna tell me your name, doe-eyes?"
    voice "audio/mdhm_alan VoicElines/Prologue + Day 1/05_tell me tu nombre.mp3"
    a "¿Me vas a decir tu nombre, Doe-Eyes?"

# game/script.rpy:911
translate Paloslios day1_7f0d903d:

    # "He leans in, not too close for comfort but enough that I could take a good look at his features. He had scars on both sides of his cheeks, they were small, and one looked like a marked ‘x' on his face."
    "Se inclina, no demasiado cerca para la comodidad, pero lo suficiente como para poder echar un buen vistazo a sus rasgos. Tenía cicatrices en ambos lados de sus mejillas, eran pequeñas y una parecía una marcada \"X\" en su rostro."

# game/script.rpy:913
translate Paloslios day1_c71f4cce:

    # "His shaggy hair had bleached tips on some ends. Then my eyes fall onto his. Staring directly at me like some new creature he discovered. Both of them are different in color."
    "Su cabello peludo tenía puntas blanqueadas en algunos extremos. Entonces mis ojos caen sobre los suyos. Mirándome directamente como una nueva criatura que descubrió. Ambos son de color diferente."

# game/script.rpy:915
translate Paloslios day1_0c71af9a:

    # "I couldn't help but feel a chill run down my spine. It seemed creepy but also..."
    "No pude evitar sentir un escalofrío corriendo por mi columna vertebral. Parecía espeluznante pero también ..."

# game/script.rpy:917
translate Paloslios day1_91b9410f:

    # "Familiar."
    "Familiar."

# game/script.rpy:921
translate Paloslios day1_b9b4a2d7:

    # "I was staring at him again."
    "Lo estaba mirando de nuevo."

# game/script.rpy:923
translate Paloslios day1_f4b84863:

    # u "O-Oh! [name]!"
    u "¡Oh! [name]!"

# game/script.rpy:930
translate Paloslios day1_1c6da0e5:

    # a "Pleasure to meet ya, [name]."
    a "Es un placer conocerte, [name]."

# game/script.rpy:932
translate Paloslios day1_2633582a:

    # "Alan's hand reaches out to shake mine, and I gladly take it."
    "La mano de Alan se extiende para sacudir la mía, y con mucho gusto la tomo."

# game/script.rpy:935
translate Paloslios day1_0e96da0c:

    # a "So..."
    a "Entonces..."

# game/script.rpy:937
translate Paloslios day1_047ceca7:

    # a "About those snacks-"
    a "Sobre esos bocadillos"

# game/script.rpy:939
translate Paloslios day1_a2c985b3:

    # "I grin mischievously as soon as he brought up the topic of snacks. That's exactly what I was here for!"
    "Sonrío con misquías tan pronto como él mencionó el tema de los bocadillos. ¡Eso es exactamente para lo que estaba aquí!"

# game/script.rpy:941
translate Paloslios day1_ca38ce26:

    # u "Oh right! We should get some, there is this convenience store arou-"
    u "¡Oh, claro! Deberíamos obtener algunos, existe esta tienda de conveniencia."

# game/script.rpy:944
translate Paloslios day1_8ac35efb:

    # a "The Food Box, right? I go there from time to time!"
    a "La caja de comida, ¿verdad? ¡Voy allí de vez en cuando!"

# game/script.rpy:946
translate Paloslios day1_5c49c3b7:

    # u "And I would assume you know your way out of the woods, right? Hopefully?"
    u "Y supongo que conoces tu salida del bosque, ¿verdad? ¿Con un poco de suerte?"

# game/script.rpy:948
translate Paloslios day1_b4a91b97:

    # "Alan chuckles, sensing my anxiety about being able to get out of the forest."
    "Alan se ríe, sintiendo mi ansiedad por poder salir del bosque."

# game/script.rpy:950
translate Paloslios day1_71084cf6:

    # a "You seem to get lost easily, huh? What would you do without me, doe-eyes?"
    a "Parece que te pierdes fácilmente, ¿eh? ¿Qué harías sin mí, Doe-Eyes?"

# game/script.rpy:952
translate Paloslios day1_1bd46872:

    # "He keeps calling me that, even after I told him my name."
    "Él sigue llamándome eso, incluso después de decirle mi nombre."

# game/script.rpy:957
translate Paloslios day1_f253e5c6:

    # "My face turns red..."
    "Mi cara se vuelve roja ..."

# game/script.rpy:959
translate Paloslios day1_9ca19f19:

    # "My eyes shifted around and I began to laugh. I was merely trying to brush off his comment. Come to think of it, I did find him to be cute..."
    "Mis ojos se movieron y comencé a reír. Simplemente estaba tratando de cepillar su comentario. Van a pensarlo, lo encontré como lindo ..."

# game/script.rpy:963
translate Paloslios day1_d00bbc0f:

    # "That kind of attention made me feel uncomfortable..."
    "Ese tipo de atención me hizo sentir incómodo ..."

# game/script.rpy:966
translate Paloslios day1_9f19618a:

    # "I scratch the back of my neck and shift around awkwardly. I'm not sure how I feel about him or that nickname..."
    "Me raso la parte posterior de mi cuello y me cambio torpemente. No estoy seguro de cómo me siento por él o ese apodo ..."

# game/script.rpy:968
translate Paloslios day1_4dc006f0:

    # "There was a beat of silence."
    "Hubo un ritmo de silencio."

# game/script.rpy:971
translate Paloslios day1_37d9ed73:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Alright.mp3"
    # a "I'll lead the way!"
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_alright.mp3"
    a "¡Lideraré el camino!"

# game/script.rpy:975
translate Paloslios day1_da52a567:

    # u "Cool."
    u "Fresco."

# game/script.rpy:978
translate Paloslios day1_66bd5d6a:

    # "We both walked together or more like, I followed wherever Alan walked. On the occasion, he would stop and mutter to himself under his breath."
    "Ambos caminamos juntos o más como, seguí donde caminó Alan. En la ocasión, se detendría y murmuraba para sí mismo en lo que respecta."

# game/script.rpy:979
translate Paloslios day1_a9ed6df4:

    # "I could've sworn I heard him counting the trees, pointing at them before smiling at me and beginning to walk again."
    "Podría haber jurado que lo escuché contar los árboles, señalándolos antes de sonreírme y comenzar a caminar nuevamente."

# game/script.rpy:981
translate Paloslios day1_083fe534:

    # "It made me curious about just how he seemed to know where we were. Despite how far we walked, it all looked the same to me. It was starting to scramble my brain."
    "Me dio curiosidad sobre cómo parecía saber dónde estábamos. A pesar de lo lejos que caminamos, todo me pareció lo mismo. Estaba empezando a revolver mi cerebro."

# game/script.rpy:983
translate Paloslios day1_9c873d87:

    # u "So what's your whole... thing here?"
    u "Entonces, ¿cuál es tu ... cosa aquí?"

# game/script.rpy:986
translate Paloslios day1_09db9eaf:

    # a "Huh?"
    a "¿Eh?"

# game/script.rpy:988
translate Paloslios day1_81442d79:

    # u "I mean- I'm assuming you live on your own out here, not anywhere in town. It's none of my business but how come no one has ever told me about you?"
    u "Quiero decir, asumo que vives solo aquí, no en ningún lugar de la ciudad. No es asunto mío, pero ¿cómo es que nadie me ha contado de ti?"

# game/script.rpy:991
translate Paloslios day1_6d28e0ce:

    # "Alan looks up to the sky, giving some thought to my question, as his arms droop side to side as he walks. He didn't appear to be slowing down."
    "Alan mira hacia el cielo, pensando en mi pregunta, ya que sus brazos caen de lado a lado mientras camina. No parecía estar disminuyendo."

# game/script.rpy:995
translate Paloslios day1_d3de2920:

    # voice "audio/MDHM_Alan voicelines/Noises/Neutral/Alan_Hmm.mp3"
    # a "I guess no one really acknowledges me or knows that I live here. Everyone here kinda keeps to themselves here, which I appreciate."
    voice "audio/mdhm_alan VoicElines/ruidos/neutral/alan_hmm.mp3"
    a "Supongo que nadie realmente me reconoce o sabe que yo vivo aquí. Todos aquí se mantienen un poco aquí, lo que aprecio."

# game/script.rpy:999
translate Paloslios day1_70863f21:

    # u "Wait... Do you not have any friends?"
    u "Espera ... ¿no tienes amigos?"

# game/script.rpy:1001
translate Paloslios day1_26a821de:

    # "Alan shook his head."
    "Alan sacudió la cabeza."

# game/script.rpy:1004
translate Paloslios day1_e4eb2bd0:

    # a "Nope. The most faces I've seen are when I visit the store to restock on food."
    a "No. La mayoría de las caras que he visto son cuando visito la tienda para reabastecer la comida."

# game/script.rpy:1006
translate Paloslios day1_06650198:

    # u "Family?"
    u "¿Familia?"

# game/script.rpy:1008
translate Paloslios day1_2c1075b5:

    # "There was a small pause, but Alan didn't stop walking."
    "Hubo una pequeña pausa, pero Alan no dejó de caminar."

# game/script.rpy:1011
translate Paloslios day1_a8c9743b:

    # a "Left them a long time ago."
    a "Los dejó hace mucho tiempo."

# game/script.rpy:1013
translate Paloslios day1_fdbce207:

    # u "Oh..."
    u "Oh..."

# game/script.rpy:1015
translate Paloslios day1_723fe78d:

    # a "Dunno... I figured that I lived better by myself. Nobody bothers me, I don't bother them."
    a "No sé ... Pensé que vivía mejor solo. Nadie me molesta, no los molesto."

# game/script.rpy:1017
translate Paloslios day1_5df71b63:

    # u "Sooo you're a hermit?"
    u "¿Entonces eres un ermitaño?"

# game/script.rpy:1020
translate Paloslios day1_ce46363e:

    # "Alan chuckled, scratching his cheek."
    "Alan se rió entre dientes, rascándose la mejilla."

# game/script.rpy:1022
translate Paloslios day1_54170cd6:

    # a "Ya could say that."
    a "Podrías decir eso."

# game/script.rpy:1024
translate Paloslios day1_f0dda93d:

    # "I nodded, understanding Alan in a way. Not wanting to interact with others, living peacefully out in the woods. And then a funny thought came to my mind."
    "Asentí, entendiendo a Alan de alguna manera. No querer interactuar con los demás, viviendo pacíficamente en el bosque. Y luego se me ocurrió un pensamiento divertido."

# game/script.rpy:1027
translate Paloslios day1_21a73f87:

    # u "But you do realize that you are talking to me and joining in on a snack quest, right? Not very hermit-like. Did I break your zero human interaction record?"
    u "Pero te das cuenta de que me estás hablando y te unes en una búsqueda de bocadillos, ¿verdad? No es muy parecido a un ermitaño. ¿Rompí tu récord de interacción humana cero?"

# game/script.rpy:1030
translate Paloslios day1_72885d1c:

    # "Alan's eyes latched onto me, his lips tugging a smile."
    "Los ojos de Alan se aferraron a mí, sus labios tiran de una sonrisa."

# game/script.rpy:1032
translate Paloslios day1_35667aa0:

    # a "I guess you did. I don't mind you being my first..."
    a "Supongo que lo hiciste. No me importa que seas mi primera ..."

# game/script.rpy:1041
translate Paloslios day1_ec3d7659:

    # "It didn't take us long to get to the convenience store, I didn't think I minded the distance. Didn't know a conversation with someone I knew for less than 24 hours could be so distracting."
    "No nos llevó mucho tiempo llegar a la tienda de conveniencia, no pensé que me importara la distancia. No sabía que una conversación con alguien que conocía durante menos de 24 horas podría distraer."

# game/script.rpy:1043
translate Paloslios day1_f6601d20:

    # "The obnoxiously bright lights of the store pulls me out of the trance. There were a couple of people in the store, mostly older men getting cases of beer or students getting a quick lunch."
    "Las luces desagradablemente brillantes de la tienda me sacan del trance. Había un par de personas en la tienda, en su mayoría hombres mayores que recibían cajas de cerveza o estudiantes que almorzaban rápidamente."

# game/script.rpy:1045
translate Paloslios day1_e5b8948c:

    # "A worker mutters ‘welcome' as we step in, not bothering to look up from their phone."
    "Un trabajador murmura \"bienvenido\" a medida que intervimos, sin molestarnos en mirar hacia arriba desde su teléfono."

# game/script.rpy:1049
translate Paloslios day1_3b15b096:

    # a "Well, pick anything you want. It's on me."
    a "Bueno, elige lo que quieras. Es sobre mí."

# game/script.rpy:1051
translate Paloslios day1_f380051c:

    # "I perked up as soon as he said that. My eyes scan around every corner of the store, wondering what I could get..."
    "Me animé tan pronto como él dijo eso. Mis ojos escanean en cada esquina de la tienda, preguntándose qué podría obtener ..."

# game/script.rpy:1057
translate Paloslios day1_70249ac1:

    # "I reach into the cold freezer, grabbing myself whatever seemed most appealing. Alan flashes me a cheeky smile, he seemed giddy that we got the same thing."
    "Alto al congelador frío, agarrándome de mí mismo lo que parecía más atractivo. Alan me muestra una sonrisa descarada, parecía vertiginoso que obtuvimos lo mismo."

# game/script.rpy:1062
translate Paloslios day1_4d09737b:

    # "I quickly ran to the back of the store, grabbing myself a huge cup of frozen syrupy goodness. They were fairly cheap."
    "Rápidamente corrí a la parte trasera de la tienda, agarrándome una gran taza de bondad de almíbar congelado. Eran bastante baratos."

# game/script.rpy:1067
translate Paloslios day1_ffaaf469:

    # "I walked up towards the soda fountain. I was craving something more refreshing than anything and it was pretty cheap."
    "Caminé hacia la fuente de soda. Anhelaba algo más refrescante que cualquier cosa y era bastante barato."

# game/script.rpy:1069
translate Paloslios day1_d460aa95:

    # "I looked back and saw that Alan was also scavenging around for snacks. Both of us were smiling brightly like children running amok the isles, not even bothering to get a basket for our collection."
    "Miré hacia atrás y vi que Alan también estaba buscando bocadillos. Ambos estábamos sonriendo brillantemente como los niños que corrían a las islas, sin molestarse en obtener una canasta para nuestra colección."

# game/script.rpy:1071
translate Paloslios day1_0c6c4fe1:

    # "Alan instantly flashes a proud smile at me, holding his snacks securely."
    "Alan instantáneamente me muestra una sonrisa orgullosa, sosteniendo sus bocadillos de forma segura."

# game/script.rpy:1073
translate Paloslios day1_347d40d4:

    # a "Got everything you need?"
    a "¿Tienes todo lo que necesitas?"

# game/script.rpy:1075
translate Paloslios day1_f8aa1e69:

    # u "Yeah! Let's go!"
    u "¡Sí! ¡Vamos!"

# game/script.rpy:1077
translate Paloslios day1_f1bf1562:

    # "Alan dropped everything to the counter to pay, only to receive an eye roll from the cashier. They seemed like they just wanted to be done with their shift. To clock out and go home."
    "Alan dejó caer todo al mostrador para pagar, solo para recibir un rollo de ojos del cajero. Parecían que solo querían terminar con su turno. Para salir y irse a casa."

# game/script.rpy:1081
translate Paloslios day1_fbb04ae4:

    # "We quickly leave the store after paying, bags filled with a bunch of goodies."
    "Rápidamente salimos de la tienda después de pagar, bolsas llenas de un montón de golosinas."

# game/script.rpy:1085
translate Paloslios day1_3f6485ea:

    # a "I'm already gettin' hungry-"
    a "Ya tengo hambre"

# game/script.rpy:1087
translate Paloslios day1_7364089c:

    # "He mumbles out loud as I enjoy my [snack]."
    "Él murmura en voz alta mientras disfruto mi [snack!t]."

# game/script.rpy:1091
translate Paloslios day1_94b75596:

    # "I expected him to reach for the bags and start rummaging through our snacks, but instead, he unzips his jacket. He exposes a hoard of chocolate bars."
    "Esperaba que alcanzara las bolsas y comenzara a hurgar en nuestros bocadillos, pero en cambio, se desabrochó la chaqueta. Expone un tesoro de barras de chocolate."

# game/script.rpy:1093
translate Paloslios day1_2d4b3c74:

    # "I blink, confused."
    "Parpadeo, confundido."

# game/script.rpy:1095
translate Paloslios day1_b2e8ee05:

    # u "When did you get those?"
    u "¿Cuándo obtuviste eso?"

# game/script.rpy:1098
translate Paloslios day1_66cb7b80:

    # a "When they weren't looking."
    a "Cuando no estaban mirando."

# game/script.rpy:1100
translate Paloslios day1_95859906:

    # "Alan pulled a chocolate bar out of his coat, his fingers fidget with the plastic wrapper as he tears it open."
    "Alan sacó una barra de chocolate de su abrigo, sus dedos se inquieta con el envoltorio de plástico mientras la abre."

# game/script.rpy:1102
translate Paloslios day1_3c9f96b4:

    # u "You... Stole it?"
    u "Tu ... lo robó?"

# game/script.rpy:1104
translate Paloslios day1_426597f6:

    # "He then takes a bite, smiling proudly to himself."
    "Luego toma un bocado, sonriendo con orgullo para sí mismo."

# game/script.rpy:1108
translate Paloslios day1_aabf88ab:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Yes.mp3"
    # a "Yup! I said it was on me."
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_yes.mp3"
    a "¡Sí! Dije que era sobre mí."

# game/script.rpy:1112
translate Paloslios day1_6194c49d:

    # "Alan continues to munch on his chocolate, proceeding wordlessly to fish another one out."
    "Alan continúa comiendo su chocolate, continuando sin palabras para pescar otro."

# game/script.rpy:1114
translate Paloslios day1_1b48228d:

    # voice "audio/MDHM_Alan voicelines/Prologue + Day 1/06_Boop.mp3"
    # a "Boop."
    voice "audio/mdhm_alan VoicElines/Prologue + Day 1/06_Boop.mp3"
    a "Boop."

# game/script.rpy:1117
translate Paloslios day1_af33d4da:

    # "He playfully nudges it on the tip of my nose, tantalizing me to partake in his stolen loot."
    "Lo empuja juguetonamente sobre la punta de mi nariz, tentándose para participar en su botín robado."

# game/script.rpy:1119
translate Paloslios day1_300d40c9:

    # a "I promise it'll taste better."
    a "Prometo que sabrá mejor."

# game/script.rpy:1123
translate Paloslios day1_c26b0af8:

    # "I was a bit hesitant, but I did end up taking the chocolate and unwrapping it. It was just candy. What's going to be so special about it? That's what I thought until..."
    "Dudaba un poco, pero terminé tomando el chocolate y desenvolviéndolo. Era solo dulces. ¿Qué va a ser tan especial? Eso es lo que pensé hasta ..."

# game/script.rpy:1125
translate Paloslios day1_ffc99b27:

    # "I ate it."
    "Me lo comí."

# game/script.rpy:1127
translate Paloslios day1_4778d210:

    # "And he was right. It does taste better."
    "Y tenía razón. Sabe mejor."

# game/script.rpy:1131
translate Paloslios day1_7a54807a:

    # "I laughed in disbelief."
    "Me reí con incredulidad."

# game/script.rpy:1133
translate Paloslios day1_c6b888e4:

    # u "Wow! You were actually right- Holy shit."
    u "¡Guau! En realidad tenías razón, mierda."

# game/script.rpy:1135
translate Paloslios day1_0fecf35b:

    # a "Ya see!"
    a "¡Ves!"

# game/script.rpy:1137
translate Paloslios day1_53ea0e3a:

    # "I still couldn't believe that he had stolen candy. While it was kind of impressive that he did it so nonchalantly and with ease, I still couldn't help but feel bad that he went out of his way to grab enough to share."
    "Todavía no podía creer que hubiera robado dulces. Si bien fue un poco impresionante que lo hiciera tan despreocupadamente y con facilidad, todavía no pude evitar sentirme mal que hizo todo lo posible para agarrar lo suficiente para compartir."

# game/script.rpy:1142
translate Paloslios day1_927ca15a:

    # "It only seems fair, right? I motion my [snack] towards him. I was shaking it to signal Alan to indulge a bit. He tilts his head like a confused dog before getting the hint."
    "Solo parece justo, ¿verdad? Me muevo de mi [snack!t] hacia él. Lo estaba sacudiendo para indicarle a Alan que se entregue un poco. Se inclina la cabeza como un perro confundido antes de obtener la pista."

# game/script.rpy:1143
translate Paloslios day1_7891e355:

    # a "Oh."
    a "Oh."

# game/script.rpy:1144
translate Paloslios day1_1ee9ea45:

    # "He leans forward."
    "Se inclina hacia adelante."

# game/script.rpy:1148
translate Paloslios day1_c1809374:

    # "I felt his hand graze against mine, pulling me a little bit closer to take a bite. His lips smacked, he takes a moment to savor the taste."
    "Sentí que su mano pastaba contra la mía, acercándome un poco más para darle un bocado. Sus labios golpearon, se toma un momento para saborear el sabor."

# game/script.rpy:1150
translate Paloslios day1_93cab352:

    # "I felt his hand graze against mine, pulling me a little bit closer to take a sip. His lips smacked, he takes a moment to savor the taste."
    "Sentí que su mano pastaba contra la mía, acercándome un poco más para tomar un sorbo. Sus labios golpearon, se toma un momento para saborear el sabor."

# game/script.rpy:1152
translate Paloslios day1_0c49ab7d:

    # "Then his eyes gaze up at me, staring with a smirk spread on his face. One I couldn't exactly pinpoint what he was trying to say, but my heart felt like it was pounding."
    "Entonces sus ojos me miran, mirando con una sonrisa extendida en su rostro. Uno no pude identificar exactamente lo que estaba tratando de decir, pero mi corazón sentía que estaba golpeando."

# game/script.rpy:1153
translate Paloslios day1_cc51111a:

    # a "You have good taste, doe-eyes."
    a "Tienes buen gusto, doe-Eyes."

# game/script.rpy:1155
translate Paloslios day1_b6d5d773:

    # "Alan then steps away, continuing to eat his forbidden chocolate."
    "Alan se aleja, continuando comiendo su chocolate prohibido."

# game/script.rpy:1156
translate Paloslios day1_0879917b:

    # u "H-Hey!"
    u "¡H-HEY!"

# game/script.rpy:1157
translate Paloslios day1_26013c78:

    # "I call out before following him right on his tail."
    "Llamo antes de seguirlo en su cola."

# game/script.rpy:1160
translate Paloslios day1_de59b85d:

    # "maybe that wasn't a good idea..."
    "Tal vez esa no fue una buena idea ..."

# game/script.rpy:1171
translate Paloslios day1_8c784985:

    # "We kept walking for a few minutes, our bag of snacks almost empty, the only thing left was wrappers and packaging. We seemed to have lost track of the time. As I finally began to notice the sun was about to set."
    "Seguimos caminando durante unos minutos, nuestra bolsa de bocadillos casi vacías, lo único que quedaba era envoltorios y empaques. Parecíamos haber perdido la noción del tiempo. Cuando finalmente comencé a notar que el sol estaba a punto de ponerse."

# game/script.rpy:1173
translate Paloslios day1_f64dc915:

    # "It was really quiet, with only the occasional rustling of the leaves from the trees and the rush of the water growing louder."
    "Estaba realmente tranquilo, con solo el susurro ocasional de las hojas de los árboles y la prisa del agua se hacía más fuerte."

# game/script.rpy:1175
translate Paloslios day1_acdcd80a:

    # u "Martian Lake?"
    u "Lago marciano?"

# game/script.rpy:1177
translate Paloslios day1_e98686c7:

    # "I note, seeing a rather silly-looking sign of an alien. During my short time here, I had never visited the lake, but it was the first thing you would see when driving here."
    "Noto, viendo un signo bastante tonto de un alienígena. Durante mi corto tiempo aquí, nunca había visitado el lago, pero fue lo primero que verías al conducir aquí."

# game/script.rpy:1179
translate Paloslios day1_4e6bbac5:

    # "The crystal blue water and soft sand that almost looked pink thanks to the sunset caught my eye."
    "El agua de cristal azul y la arena suave que casi se veía rosa gracias a la puesta de sol me llamó la atención."

# game/script.rpy:1181
translate Paloslios day1_108d94b7:

    # u "Why did they name it that?"
    u "¿Por qué lo nombraron eso?"

# game/script.rpy:1185
translate Paloslios day1_c1a83a1f:

    # "There was a beat of silence, and I looked over to Alan, who seemed distracted. He was hunched over the sand, he seemed to be looking for something."
    "Hubo un ritmo de silencio, y miré a Alan, quien parecía distraído. Estaba encorvado sobre la arena, parecía estar buscando algo."

# game/script.rpy:1188
translate Paloslios day1_457c082a:

    # a "Oh! Um..."
    a "¡Oh! Um ..."

# game/script.rpy:1191
translate Paloslios day1_c2f3af5c:

    # a "From what I've heard, back in the 60s people allegedly saw an alien walking around here. In a blink of an eye, the alien ran into the woods and it was never seen since."
    a "Por lo que he escuchado, en los años 60, la gente supuestamente vio a un alienígena caminando por aquí. En un abrir y cerrar de ojos, el alienígena se topó con el bosque y nunca se vio desde entonces."

# game/script.rpy:1193
translate Paloslios day1_10edc160:

    # "Sounds like a typical Doomsbury legend..."
    "Suena como una leyenda típica de Doomsbury ..."

# game/script.rpy:1195
translate Paloslios day1_dc7974fc:

    # u "Do you believe the story?"
    u "¿Crees la historia?"

# game/script.rpy:1197
translate Paloslios day1_215c4eec:

    # "Alan stood up straight again, picking up a rock and observing it. He simply shrugged at my question."
    "Alan se puso de pie de nuevo, recogiendo una roca y observándola. Simplemente se encogió de hombros ante mi pregunta."

# game/script.rpy:1199
translate Paloslios day1_14db0218:

    # a "After living here, I would believe almost anything."
    a "Después de vivir aquí, creería casi cualquier cosa."

# game/script.rpy:1201
translate Paloslios day1_e2ee4564:

    # u "So you have seen some things?"
    u "¿Entonces has visto algunas cosas?"

# game/script.rpy:1204
translate Paloslios day1_2cd54648:

    # a "Gosh, you could say that."
    a "Dios, podrías decir eso."

# game/script.rpy:1207
translate Paloslios day1_54a0966a:

    # "Alan tosses the stone up a couple of times in the air before flinging it across the lake."
    "Alan arroja la piedra un par de veces en el aire antes de arrojarla a través del lago."

# game/script.rpy:1210
translate Paloslios day1_874e6621:

    # "My eyes follow it, and to my astonishment, the stone skips across the water with accelerating speed, never stopping. I squinted my eyes the further and further it got until it was nothing more than a speck."
    "Mis ojos lo siguen, y para mi asombro, la piedra se salta el agua con velocidad de aceleración, nunca deteniéndose. Entrecí los ojos a medida que avanzaba hasta que no era más que una mota."

# game/script.rpy:1212
translate Paloslios day1_26c0aab0:

    # "Then it was gone."
    "Entonces se fue."

# game/script.rpy:1215
translate Paloslios day1_110a2f1d:

    # "Alan let out a satisfied hum and my mouth hung open in astonishment."
    "Alan dejó escapar un zumbido satisfecho y mi boca se abrió con asombro."

# game/script.rpy:1220
translate Paloslios day1_caeae5d8:

    # "I look up at Alan with hopeful eyes."
    "Miro a Alan con ojos esperanzados."

# game/script.rpy:1223
translate Paloslios day1_806c8d6c:

    # voice "audio/MDHM_Alan voicelines/Noises/Neutral/Alan_Sure.mp3"
    voice "audio/mdhm_alan VoicElines/ruidos/neutral/alan_sure.mp3"

# game/script.rpy:1225
translate Paloslios day1_009a30ce:

    # a "Sure thing, Doe-eyes."
    a "Claro, Doe-Eyes."

# game/script.rpy:1229
translate Paloslios day1_627cd0d3:

    # "In a hurry, I began to look around for a decently sized stone. I pulled back my arm, rock in hand, as far as I could."
    "A toda prisa, comencé a buscar una piedra de tamaño decente. Me retiré el brazo, la roca en la mano, por lo que pude."

# game/script.rpy:1231
translate Paloslios day1_716f4f04:

    # "With all my might, I threw it in the water."
    "Con todas mis fuerzas, lo tiré al agua."

# game/script.rpy:1233
translate Paloslios day1_1d55cd68:

    # "I eagerly look towards the water."
    "Miro ansiosamente hacia el agua."

# game/script.rpy:1239
translate Paloslios day1_63a5eceb:

    # "Only for the rock to disappear in the shallow waters."
    "Solo para que la roca desaparezca en las aguas poco profundas."

# game/script.rpy:1241
translate Paloslios day1_d678f0d5:

    # "I pout."
    "Estoy haciendo pucheros."

# game/script.rpy:1243
translate Paloslios day1_fdbce207_1:

    # u "Oh..."
    u "Oh..."

# game/script.rpy:1246
translate Paloslios day1_e6827de8:

    # a "Awww don't bum ya'self out. I'll teach ya, Doe-eyes."
    a "Awww no te salgas. Te enseñaré, Doe-Eyes."

# game/script.rpy:1248
translate Paloslios day1_ccd382ee:

    # a "Here."
    a "Aquí."

# game/script.rpy:1251
translate Paloslios day1_93c61d80:

    # "Alan approaches me, picking up a random stone as he did. He examined it, turning it over in his hand."
    "Alan se acerca a mí, recogiendo una piedra aleatoria como lo hizo. Lo examinó, volcándolo en su mano."

# game/script.rpy:1254
translate Paloslios day1_c0784a4c:

    # a "You can't just use any rock. It has to be very flat."
    a "No puedes usar ninguna roca. Tiene que ser muy plano."

# game/script.rpy:1256
translate Paloslios day1_ed9f3fae:

    # a "And there's gotta be a lil' nudge' for you to place your fingers and grab onto."
    a "Y debe haber un pequeño 'empujón' para que coloque los dedos y se agarre."

# game/script.rpy:1258
translate Paloslios day1_372487ee:

    # "Then, he grabs my wrist gently, handing me the rock, and places it in the palm of my hand for me to hold."
    "Luego, me agarra suavemente la muñeca, entregándome la roca, y la coloca en la palma de mi mano para que yo lo sostenga."

# game/script.rpy:1261
translate Paloslios day1_859e1242:

    # a "Now, before you do anything."
    a "Ahora, antes de hacer algo."

# game/script.rpy:1263
translate Paloslios day1_957d5b35:

    # a "People tend to throw it like a frisbee, don't throw it with your wrist, sling your whole arm."
    a "La gente tiende a tirarlo como un frisbee, no lo arroje con la muñeca, arroje todo el brazo."

# game/script.rpy:1265
translate Paloslios day1_65b8f89b:

    # "I focus. Taking into consideration what Alan told me. I felt a lot more confident in this throw."
    "Me concentro. Teniendo en cuenta lo que Alan me dijo. Me sentí mucho más seguro en este lanzamiento."

# game/script.rpy:1267
translate Paloslios day1_9674148c:

    # "I take a deep breath and toss it again."
    "Respiro hondo y lo arrojo nuevamente."

# game/script.rpy:1269
translate Paloslios day1_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:1274
translate Paloslios day1_d5e699c5:

    # "I DID IT!"
    "¡LO HICE!"

# game/script.rpy:1276
translate Paloslios day1_ceca687d:

    # "It was a lot slower and didn't go as far as Alan but still!"
    "¡Era mucho más lento y no fue tan lejos como Alan, pero aún así!"

# game/script.rpy:1278
translate Paloslios day1_ebd72a9e:

    # "I cheer and Alan gives me a thumbs up."
    "Me animo y Alan me da un pulgar hacia arriba."

# game/script.rpy:1285
translate Paloslios day1_d2739cd5:

    # "We walked back to my place. The sun had already set with the moon and the stars taking its place."
    "Caminamos de regreso a mi casa. El sol ya se había puesto con la luna y las estrellas tomando su lugar."

# game/script.rpy:1290
translate Paloslios day1_42d56939:

    # "I stretch, bending and stretching my legs after all that walking."
    "Me estiro, doblamos y estiro las piernas después de todo eso caminando."

# game/script.rpy:1292
translate Paloslios day1_c49df812:

    # u "I had fun today."
    u "Me divertí hoy."

# game/script.rpy:1295
translate Paloslios day1_7bc9abd7:

    # a "Did ya, now?"
    a "¿Lo hiciste ahora?"

# game/script.rpy:1297
translate Paloslios day1_5f8658a3:

    # "I nodded to him, approaching my doorstep, and leaving Alan behind."
    "Asentí con él, acercándome a mi puerta y dejando a Alan atrás."

# game/script.rpy:1299
translate Paloslios day1_7082bad5:

    # u "We should do something like that again."
    u "Deberíamos hacer algo así de nuevo."

# game/script.rpy:1302
translate Paloslios day1_41e1f300:

    # "Alan's eyes widen, he appears to be quiet for a moment."
    "Los ojos de Alan se abren, parece estar callado por un momento."

# game/script.rpy:1305
translate Paloslios day1_b23b89a0:

    # a "W-We should..."
    a "N-nosotros deberíamos ..."

# game/script.rpy:1307
translate Paloslios day1_3f4f864e:

    # "I turn my door handle, opening it slightly."
    "Giro la manija de mi puerta, abriéndola ligeramente."

# game/script.rpy:1309
translate Paloslios day1_51de1eba:

    # u "See ya around, Alan."
    u "Nos vemos, Alan."

# game/script.rpy:1315
translate Paloslios day1_f18b9e25:

    # "Much like yesterday, as soon as I entered the house, it was as if all my energy drained out of me. I didn't even bother to go upstairs to my bedroom."
    "Al igual que ayer, tan pronto como entré en la casa, fue como si toda mi energía me agotara. Ni siquiera me molesté en subir a mi habitación."

# game/script.rpy:1322
translate Paloslios day1_c1018b9d:

    # "I fall onto my sofa, face first."
    "Me caigo sobre mi sofá, primero."

# game/script.rpy:1324
translate Paloslios day1_8c6dc733:

    # u "I'm just gonna sleep here..."
    u "Solo voy a dormir aquí ..."

# game/script.rpy:1331
translate Paloslios day1_c049f89e:

    # "The sound of the TV slowly drowns out the sound of my breathing. Soon every single worry I had faded away."
    "El sonido de la televisión ahoga lentamente el sonido de mi respiración. Pronto cada preocupación que me había desvanecido."

# game/scriptday2.rpy:13
translate Paloslios scriptday2_cc9a5909:

    # "!!!"
    "!"

# game/scriptday2.rpy:18
translate Paloslios scriptday2_011ae1bd:

    # "Woah..."
    "Woah ..."

# game/scriptday2.rpy:20
translate Paloslios scriptday2_abeb056d:

    # "I could've sworn I heard the door..."
    "Podría haber jurado que escuché la puerta ..."

# game/scriptday2.rpy:22
translate Paloslios scriptday2_8b831e6a:

    # u "Holy shit."
    u "Mierda santa."

# game/scriptday2.rpy:23
translate Paloslios scriptday2_45dda75d:

    # u "My head was pounding from the intensity. What a way to start the morning."
    u "Mi cabeza golpeaba por la intensidad. Qué manera de comenzar la mañana."

# game/scriptday2.rpy:31
translate Paloslios scriptday2_a20cefa7:

    # "..."
    "..."

# game/scriptday2.rpy:33
translate Paloslios scriptday2_c3eb1c0c:

    # u "Ugh. I've gotta stop waking up like this in a cold sweat. What's up with me lately?"
    u "Puaj. Tengo que dejar de despertar así con un sudor frío. ¿Qué me pasa últimamente?"

# game/scriptday2.rpy:37
translate Paloslios scriptday2_2c019cf8:

    # "My hands scrambled to where I had left my phone. It only took a few minutes before the vibration signaled me where it was located."
    "Mis manos se apresuraron a donde había dejado mi teléfono. Solo tomó unos minutos antes de que la vibración me indicara dónde estaba ubicado."

# game/scriptday2.rpy:38
translate Paloslios scriptday2_cc1478eb:

    # u "There you are!"
    u "¡Ahí estás!"

# game/scriptday2.rpy:39
translate Paloslios scriptday2_e929fb7e:

    # "No new messages. Not from anyone I knew in particular. Just usual social media notifications that I wouldn't be bothered to check and..."
    "No hay mensajes nuevos. No de nadie que conocía en particular. Solo notificaciones habituales de las redes sociales que no me molestaría en verificar y ..."

# game/scriptday2.rpy:40
translate Paloslios scriptday2_22ee0405:

    # "A missing person alert..."
    "Una alerta de persona desaparecida ..."

# game/scriptday2.rpy:41
translate Paloslios scriptday2_eaec2259:

    # "That's probably what violently woke me up."
    "Eso es probablemente lo que me despertó violentamente."

# game/scriptday2.rpy:42
translate Paloslios scriptday2_e369a652:

    # "It gave a basic info description, but it seemed to be out of my control. I decided to ignore it."
    "Dio una descripción de información básica, pero parecía estar fuera de mi control. Decidí ignorarlo."

# game/scriptday2.rpy:45
translate Paloslios scriptday2_50ffab52:

    # "It's too early for this. I don't even wanna bother to look at my phone."
    "Es demasiado pronto para esto. Ni siquiera quiero molestarme en mirar mi teléfono."

# game/scriptday2.rpy:47
translate Paloslios scriptday2_e82c1450:

    # "I let out a yawn as I stretched, despite sleeping on the couch, I was more than comfortable. No soreness, no nothing! It was quite rare."
    "Dejé escapar un bostezo mientras me estiraba, a pesar de dormir en el sofá, era más que cómodo. ¡Sin dolor, sin nada! Era bastante raro."

# game/scriptday2.rpy:48
translate Paloslios scriptday2_e3566542:

    # "Now..."
    "Ahora..."

# game/scriptday2.rpy:49
translate Paloslios scriptday2_8bc3d614:

    # "What to do to tackle the day?"
    "¿Qué hacer para abordar el día?"

# game/scriptday2.rpy:54
translate Paloslios scriptday2_94004a03:

    # "Oh."
    "Oh."

# game/scriptday2.rpy:55
translate Paloslios scriptday2_a37f67e0:

    # "I guess I should probably eat."
    "Supongo que probablemente debería comer."

# game/scriptday2.rpy:60
translate Paloslios scriptday2_4130d509:

    # "First things first, I need some new clothes to wear for the day."
    "Lo primero es lo primero, necesito ropa nueva para usar para el día."

# game/scriptday2.rpy:61
translate Paloslios scriptday2_42fd4ef8:

    # "My room was practically overrun with dirty laundry, I could barely make out the shaggy carpet floor by the mass amount of sweaters, pants, and underwear."
    "Mi habitación estaba prácticamente invadida por la ropa sucia, apenas podía distinguir el piso de la alfombra peluda por la cantidad masiva de suéteres, pantalones y ropa interior."

# game/scriptday2.rpy:62
translate Paloslios scriptday2_f29394c7:

    # "I should clean this up, but my empty stomach was winning the battle of this one. Not that I had much money, but I needed to get at least a few groceries."
    "Debería limpiar esto, pero mi estómago vacío estaba ganando la batalla de este. No es que tuviera mucho dinero, pero necesitaba obtener al menos algunos comestibles."

# game/scriptday2.rpy:63
translate Paloslios scriptday2_216e14a4:

    # "I don't plan on starving to death."
    "No planeo morir de hambre."

# game/scriptday2.rpy:79
translate Paloslios scriptday2_3a2c5f0c:

    # "It was a little earlier than I expected to get out. It was the earliest I'd gotten up in a while. "
    "Era un poco antes de lo que esperaba salir. Fue lo más temprano que me había levantado en mucho tiempo. "

# game/scriptday2.rpy:80
translate Paloslios scriptday2_2201f6e6:

    # "Not since my first few days living alone. Geez, back then I was practically glowing with the ambition to start classes, ready to face any challenges head-on."
    "No desde mis primeros días viviendo solo. Caray, en aquel entonces estaba prácticamente brillando con la ambición de comenzar las clases, listo para enfrentar cualquier desafío de frente."

# game/scriptday2.rpy:81
translate Paloslios scriptday2_0f889056:

    # "Until, now that is..."
    "Hasta que ahora eso es ..."

# game/scriptday2.rpy:82
translate Paloslios scriptday2_5b42f48c:

    # "I would either show up late or barely manage to reach my classes. It felt like a chore, like most things."
    "Me presentaría tarde o apenas lograría llegar a mis clases. Se sentía como una tarea, como la mayoría de las cosas."

# game/scriptday2.rpy:83
translate Paloslios scriptday2_84488b48:

    # "Most days..."
    "La mayoría de los días ..."

# game/scriptday2.rpy:84
translate Paloslios scriptday2_12fc3c59:

    # "I hope I don't wake up at all."
    "Espero no despertarme en absoluto."

# game/scriptday2.rpy:89
translate Paloslios scriptday2_e4d51d3d:

    # u "Oh. I wonder who-"
    u "Oh. Me pregunto quién-"

# game/scriptday2.rpy:90
translate Paloslios scriptday2_9ab26896:

    # u "Erika."
    u "Erika."

# game/scriptday2.rpy:91
translate Paloslios scriptday2_eb934e70:

    # "She doesn't usually call, we mostly talk through text. It got me curious, what could she possibly want to call me for?"
    "Ella no suele llamar, principalmente hablamos de mensajes de texto. Me dio curiosidad, ¿por qué podría querer llamarme?"

# game/scriptday2.rpy:92
translate Paloslios scriptday2_a20cefa7_1:

    # "..."
    "..."

# game/scriptday2.rpy:93
translate Paloslios scriptday2_44f16c10:

    # u "Hello? Erika?"
    u "¿Hola? Erika?"

# game/scriptday2.rpy:94
translate Paloslios scriptday2_2d8ba6be:

    # voice "audio/MDHM_Erika voicelines/Day 2/01_Interrupting.mp3"
    # e "[name]? Hi, I'm not interrupting anything important, am I?"
    voice "audio/mdhm_erika VoicElines/Day 2/01_interrupting.mp3"
    e "[name]? Hola, no estoy interrumpiendo nada importante, ¿verdad?"

# game/scriptday2.rpy:96
translate Paloslios scriptday2_ccb1bc00:

    # u "I'm just on my way to get some food but I am fine talking."
    u "Estoy en camino de conseguir algo de comida, pero estoy bien hablando."

# game/scriptday2.rpy:97
translate Paloslios scriptday2_98f04a58:

    # e "Hmph."
    e "Hmph."

# game/scriptday2.rpy:98
translate Paloslios scriptday2_72fdc6c1:

    # u "Is there a reason you called?"
    u "¿Hay alguna razón por la que llamaste?"

# game/scriptday2.rpy:99
translate Paloslios scriptday2_3100ee9f:

    # "I was only met with silence, but I could vaguely hear Erika make some sort of noise like she was deep in thought."
    "Solo me encontré con el silencio, pero podía escuchar vagamente a Erika hacer algún tipo de ruido como si fuera un pensamiento profundo."

# game/scriptday2.rpy:100
translate Paloslios scriptday2_bdd3d82b:

    # u "Ummm Eri-"
    u "Ummm eri-"

# game/scriptday2.rpy:101
translate Paloslios scriptday2_27f60146:

    # e "Are you free later?"
    e "¿Eres libre más tarde?"

# game/scriptday2.rpy:102
translate Paloslios scriptday2_cc26bc7b:

    # u "I... I guess?"
    u "Yo ... ¿Supongo?"

# game/scriptday2.rpy:103
translate Paloslios scriptday2_96d67ddf:

    # voice "audio/MDHM_Erika voicelines/Day 2/02_Guess.mp3"
    # e "You... Guess?"
    voice "audio/mdhm_erika VoicElines/Day 2/02_Guess.mp3"
    e "Tu ... ¿adivina?"

# game/scriptday2.rpy:105
translate Paloslios scriptday2_46b7b77a:

    # "I roll my eyes."
    "Me pongo los ojos."

# game/scriptday2.rpy:110
translate Paloslios scriptday2_e3f8b948:

    # u "Get to the point, Erika. I've got a bagel and a coffee with my name on it and your little interrogation is not gonna stop me."
    u "Llega al punto, Erika. Tengo un bagel y un café con mi nombre y tu pequeño interrogatorio no me detendrá."

# game/scriptday2.rpy:111
translate Paloslios scriptday2_10b0e9c3:

    # "I heard a short but amused sound from her. Often in class, I would play around with Erika's dry sense of humor. Strangely, I enjoyed our interactions together."
    "Escuché un sonido corto pero divertido de ella. A menudo en clase, jugaba con el sentido del humor seco de Erika. Curiosamente, disfruté nuestras interacciones juntas."

# game/scriptday2.rpy:112
translate Paloslios scriptday2_4add50eb:

    # e "At ease, soldier."
    e "A gusto, soldado."

# game/scriptday2.rpy:114
translate Paloslios scriptday2_ba57541e:

    # u "I-I don't know? What do you want me to say?"
    u "¿No lo sé? ¿Qué quieres que diga?"

# game/scriptday2.rpy:115
translate Paloslios scriptday2_3f5fb63b:

    # "Erika had this strange sense of dry humor, it flew over my head. I constantly worry if I ever say the wrong thing to her. It was hard to tell by her blank expressions."
    "Erika tenía esta extraña sensación de humor seco, voló sobre mi cabeza. Me preocupa constantemente si alguna vez le digo algo incorrecto. Era difícil saberlo por sus expresiones en blanco."

# game/scriptday2.rpy:116
translate Paloslios scriptday2_4e396465:

    # e "Sorry. Let me rephrase."
    e "Lo siento. Déjame reformular."

# game/scriptday2.rpy:118
translate Paloslios scriptday2_fb73f87b:

    # e "I just want to know if you want to study together for Professor Mocroix. My Roommate is off to do some arbitrary adventure and I don't want to be cooped up here. How does that sound?"
    e "Solo quiero saber si quieres estudiar juntos para el profesor Mocroix. Mi compañero de cuarto se va a hacer una aventura arbitraria y no quiero que me coopten aquí. ¿Cómo suena eso?"

# game/scriptday2.rpy:119
translate Paloslios scriptday2_46ad25fc:

    # u "I could get caught up on some things."
    u "Podría quedar atrapado en algunas cosas."

# game/scriptday2.rpy:120
translate Paloslios scriptday2_c283d620:

    # e "Better than rotting in your hermit cave?"
    e "¿Mejor que pudrirse en tu cueva ermitaño?"

# game/scriptday2.rpy:121
translate Paloslios scriptday2_9230ae61:

    # "I sighed. Erika was, unfortunately, sort of aware of my situation. She has this almost supernatural sixth sense of being able to read other people."
    "Suspiré. Erika fue, desafortunadamente, consciente de mi situación. Ella tiene este sexto sentido casi sobrenatural de poder leer a otras personas."

# game/scriptday2.rpy:122
translate Paloslios scriptday2_b498b615:

    # u "You wound me, Erika..."
    u "Me enrollaste, Erika ..."

# game/scriptday2.rpy:123
translate Paloslios scriptday2_6a6a95d6:

    # e "I'll meet you at the park."
    e "Te encontraré en el parque."

# game/scriptday2.rpy:124
translate Paloslios scriptday2_545649f1:

    # "With that, we both hung up."
    "Con eso, ambos colgamos."

# game/scriptday2.rpy:125
translate Paloslios scriptday2_d9f2b396:

    # u "Guess those are my plans for today."
    u "Supongo que esos son mis planes para hoy."

# game/scriptday2.rpy:126
translate Paloslios scriptday2_4f45b959:

    # "I continued to walk, taking the opportunity to make a mental grocery list."
    "Continué caminando, aprovechando la oportunidad para hacer una lista de comestibles mental."

# game/scriptday2.rpy:131
translate Paloslios scriptday2_dadfea9d:

    # "I could pick up the faint sound of... Chopping?"
    "Podría recoger el débil sonido de ... ¿Picar?"

# game/scriptday2.rpy:132
translate Paloslios scriptday2_17239a7e:

    # "Chopping wood..."
    "Picar la madera ..."

# game/scriptday2.rpy:133
translate Paloslios scriptday2_700a79a4:

    # "It must've been Alan."
    "Debe haber sido Alan."

# game/scriptday2.rpy:138
translate Paloslios scriptday2_7b25f7c1:

    # "I followed the sound to where it led me, not too far off from the small neighborhood of the college dorms. Even when I went into the thick wood, I could still see the houses from a distance."
    "Seguí el sonido a donde me llevó, no muy lejos del pequeño vecindario de los dormitorios universitarios. Incluso cuando entré en la espesa madera, aún podía ver las casas desde la distancia."

# game/scriptday2.rpy:143
translate Paloslios scriptday2_2baf1297:

    # "Occasionally, the sound would deafen but I was getting closer. Alan had to be around here somewhere."
    "Ocasionalmente, el sonido ensordecería, pero me estaba acercando. Alan tenía que estar por aquí en alguna parte."

# game/scriptday2.rpy:144
translate Paloslios scriptday2_1b84c213:

    # "That is if it was Alan and not some other weird guy from the woods lurking about."
    "Eso es si fuera Alan y no algún otro tipo extraño del bosque acechando."

# game/scriptday2.rpy:145
translate Paloslios scriptday2_9c730eab:

    # "I snorted out through my nose at the laughable idea."
    "Bustaron por mi nariz ante la idea ridícula."

# game/scriptday2.rpy:152
translate Paloslios scriptday2_9ca4f08f:

    # "It only took a few moments of walking and I was able to spot that familiar wild man from the woods."
    "Solo tomó unos momentos de caminar y pude detectar a ese hombre salvaje familiar del bosque."

# game/scriptday2.rpy:154
translate Paloslios scriptday2_ebe2f430:

    # a "Oh! Doe-eyes, what a pleasant surprise! Can't help yerself but go in the woods, eh?"
    a "¡Oh! Doe-Eyes, ¡qué sorpresa tan agradable! No puedo ayudar a Yerself sino ir al bosque, ¿eh?"

# game/scriptday2.rpy:155
translate Paloslios scriptday2_a365dcff:

    # u "I'm just as surprised as you are, Alan. I just followed the sound of chopping wood and I figured it was you."
    u "Estoy tan sorprendido como tú, Alan. Simplemente seguí el sonido de cortar madera y pensé que eras tú."

# game/scriptday2.rpy:156
translate Paloslios scriptday2_dfd43350:

    # "I could see beads of sweat slowly falling off of Alan's temple. There were a bunch of small pieces of wood scattered around him. He dropped his hatchet to the ground and dusted himself off any remaining wood chips."
    "Pude ver cuentas de sudor cayendo lentamente del templo de Alan. Había un montón de pequeños trozos de madera esparcidos a su alrededor. Dejó caer su hacha al suelo y se desempolvó de las chips de madera restantes."

# game/scriptday2.rpy:158
translate Paloslios scriptday2_cf9f8b6e:

    # a "Just gathering firewood, it was startin' to get cold in my cabin and I used up my last batch last night after I dropped you off."
    a "Solo reuniendo leña, fue comenzar a enfriar en mi cabaña y solté mi último lote anoche después de dejarlo."

# game/scriptday2.rpy:159
translate Paloslios scriptday2_05a0dc6e:

    # u "A fireplace and a cabin in the woods? Sounds like you're living the dream."
    u "¿Una chimenea y una cabaña en el bosque? Suena como si estuvieras viviendo el sueño."

# game/scriptday2.rpy:161
translate Paloslios scriptday2_d08dea41:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Laugh.mp3"
    # "Alan's hand went to the back of his neck and he laughed."
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_laugh.mp3"
    "La mano de Alan fue a la parte posterior de su cuello y se rió."

# game/scriptday2.rpy:163
translate Paloslios scriptday2_f8cc8cdc:

    # a "Far from it, but..."
    a "Lejos de eso, pero ..."

# game/scriptday2.rpy:164
translate Paloslios scriptday2_f7f0e54e:

    # "He took a second to pause, a huge gust of wind blew away some leaves, dancing along with the rustling of the branches from the trees. A short, cold breeze hit us by surprise."
    "Tomó un segundo para detenerse, una gran ráfaga de viento sopló algunas hojas, bailando junto con el susurro de las ramas de los árboles. Una breve brisa fría nos golpeó por sorpresa."

# game/scriptday2.rpy:167
translate Paloslios scriptday2_7f0cc006:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Sigh.mp3"
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_sigh.mp3"

# game/scriptday2.rpy:169
translate Paloslios scriptday2_40d2ce04:

    # a "It's nice most of the time."
    a "Es bueno la mayor parte del tiempo."

# game/scriptday2.rpy:170
translate Paloslios scriptday2_1f125152:

    # u "You're the type to say you are one with nature, huh?"
    u "Eres del tipo que dice que eres uno con la naturaleza, ¿eh?"

# game/scriptday2.rpy:172
translate Paloslios scriptday2_2d045cee:

    # a "Is that really a bad thing? I get to feed the raccoons from my trash! I can't imagine what else I'd do on a Wednesday night. They're like my pets!"
    a "¿Es eso realmente algo malo? ¡Puedo alimentar a los mapaches de mi basura! No puedo imaginar qué más haría un miércoles por la noche. ¡Son como mis mascotas!"

# game/scriptday2.rpy:173
translate Paloslios scriptday2_0d15c22d:

    # u "Raccoons? Alan, that's how you get your face scratched..."
    u "Mapaches? Alan, así es como te rascas la cara ..."

# game/scriptday2.rpy:175
translate Paloslios scriptday2_1abf5fab:

    # "Alan flashed me a smile, not speaking but proceeded to point to both of his cheeks, almost as if he was showing them off proudly like badges of honor. Don't tell me..."
    "Alan me hizo una sonrisa, sin hablar, pero procedió a señalar sus dos mejillas, casi como si los estaba mostrando con orgullo como insignias de honor. No me digas ..."

# game/scriptday2.rpy:176
translate Paloslios scriptday2_78d5c0c4:

    # voice "audio/MDHM_Alan voicelines/Day 2/01_Rocky and Horror.mp3"
    # a "Rocky and Horror can be quite a handful. It was all my fault, though. I was being a little pushy with 'em."
    voice "audio/mdhm_alan VoicElines/Day 2/01_Rocky y Horror.mp3"
    a "Rocky y Horror pueden ser un puñado. Sin embargo, todo fue mi culpa. Estaba siendo un poco agresivo con ellos."

# game/scriptday2.rpy:178
translate Paloslios scriptday2_0ea5114c:

    # u "YOU NAMED THEM?"
    u "¿Los llamaste?"

# game/scriptday2.rpy:179
translate Paloslios scriptday2_708ab7b7:

    # a "I like giving them names."
    a "Me gusta darles nombres."

# game/scriptday2.rpy:180
translate Paloslios scriptday2_b8534032:

    # "Oh. So there were multiple animals included."
    "Oh. Entonces se incluyeron múltiples animales."

# game/scriptday2.rpy:181
translate Paloslios scriptday2_13011e97:

    # a "You should meet them. They are cute lil' guys."
    a "Deberías conocerlos. Son lindos chicos."

# game/scriptday2.rpy:185
translate Paloslios scriptday2_2ca03a54:

    # u "I don't wanna catch rabies or get my face scratched. I leave wild animals alone."
    u "No quiero atrapar a la rabia ni rayarme la cara. Dejo a los animales salvajes solo."

# game/scriptday2.rpy:187
translate Paloslios scriptday2_27b0e437:

    # a "Your loss."
    a "Tu pérdida."

# game/scriptday2.rpy:190
translate Paloslios scriptday2_23c7baa5:

    # u "As long as I can leave with a full set of eyes, nose, and mouth by the end of it."
    u "Mientras pueda irme con un juego completo de ojos, nariz y boca al final."

# game/scriptday2.rpy:192
translate Paloslios scriptday2_69cf136b:

    # a "I'll be sure they won't even touch a single hair on that head of yours, Doe-eyes."
    a "Me aseguraré de que ni siquiera tocen un solo cabello en esa cabeza tuya, Doe-Eyes."

# game/scriptday2.rpy:193
translate Paloslios scriptday2_9e51d5b4:

    # "I simply shook my head. The idea of raccoons sounded cute but I know not to mess with the wildlife."
    "Simplemente sacudí la cabeza. La idea de los mapaches sonaba linda, pero sé que no debía meterse con la vida silvestre."

# game/scriptday2.rpy:195
translate Paloslios scriptday2_34717bd6:

    # u "That's still really dangerous, Alan."
    u "Eso sigue siendo realmente peligroso, Alan."

# game/scriptday2.rpy:196
translate Paloslios scriptday2_19cb41f4:

    # "Alan's expression seemed like that of an innocent kid who had no idea what he did was wrong."
    "La expresión de Alan parecía la de un niño inocente que no tenía idea de lo que hizo estaba mal."

# game/scriptday2.rpy:198
translate Paloslios scriptday2_80286518:

    # a "Hey, I'm still alive! Besides you should've gotten the hint that I disregard most things. You didn't complain about living so dangerously when I stole that chocolate."
    a "¡Oye, todavía estoy vivo! Además, deberías haber obtenido la pista de que ignoro la mayoría de las cosas. No te quejaste de vivir tan peligrosamente cuando robé ese chocolate."

# game/scriptday2.rpy:199
translate Paloslios scriptday2_9e1d69e8:

    # u "Hey, don't drag me into that! You stole that chocolate!"
    u "¡Oye, no me arrastres a eso! ¡Robaste ese chocolate!"

# game/scriptday2.rpy:201
translate Paloslios scriptday2_d9c2240e:

    # a "And you're my accomplice. In the eyes of the law, that makes us BOTH criminals, my Doe.~"
    a "Y eres mi cómplice. A los ojos de la ley, eso nos hace a ambos delincuentes, mi cierva. ~"

# game/scriptday2.rpy:205
translate Paloslios scriptday2_ffe32cc0:

    # u "I volunteer you as my cellmate. That way, it will be easier to break out of prison."
    u "Te ofrece voluntario como mi compañero de celda. De esa manera, será más fácil salir de la prisión."

# game/scriptday2.rpy:208
translate Paloslios scriptday2_a9b75e6c:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Laugh.mp3"
    # "Alan laughed at my jailmate escapism plan."
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_laugh.mp3"
    "Alan se rió de mi plan de escapismo de compañero de cárcel."

# game/scriptday2.rpy:210
translate Paloslios scriptday2_06f852e2:

    # a "Sounds perfect. I wouldn't mind you being my partner in crime. I can pick the locks for us."
    a "Suena perfecto. No me importaría que seas mi compañero en el crimen. Puedo elegir las cerraduras para nosotros."

# game/scriptday2.rpy:211
translate Paloslios scriptday2_2748ad4c:

    # u "Of course you know how to pick locks."
    u "Por supuesto que sabes cómo elegir cerraduras."

# game/scriptday2.rpy:213
translate Paloslios scriptday2_394a5584:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Laugh.mp3"
    # a "Hehehe~"
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_laugh.mp3"
    a "Jejeje ~"

# game/scriptday2.rpy:216
translate Paloslios scriptday2_36cd2c44:

    # u "I'm completely innocent! You will not rope me into petty theft here! That was just one time!"
    u "¡Soy completamente inocente! ¡No me llevarás al robo menor aquí! ¡Eso fue solo una vez!"

# game/scriptday2.rpy:217
translate Paloslios scriptday2_f30218ca:

    # a "Will they believe ya? If I can convince them that you were my partner in crime..."
    a "¿Te creerán? Si puedo convencerlos de que eras mi compañero en el crimen ..."

# game/scriptday2.rpy:218
translate Paloslios scriptday2_7412a44b:

    # "Alan placed his arms behind his back and swayed his way over to me. A devilish smile never left his face."
    "Alan colocó sus brazos detrás de su espalda y se abrió camino hacia mí. Una sonrisa diabólica nunca dejó su rostro."

# game/scriptday2.rpy:219
translate Paloslios scriptday2_ba254492:

    # u "Cease, Alan!"
    u "¡Cesa, Alan!"

# game/scriptday2.rpy:221
translate Paloslios scriptday2_40c51de6:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Sigh.mp3"
    # a "Hehehe~"
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_sigh.mp3"
    a "Jejeje ~"

# game/scriptday2.rpy:224
translate Paloslios scriptday2_b1cfce48:

    # "We continued to play around back and forth. It took nearly a solid minute for it to die down until we were left with a small, awkward silence, but smiling at each other nonetheless."
    "Continuamos jugando de un lado a otro. Tomó casi un minuto sólido para morir hasta que nos quedamos con un pequeño e incómodo silencio, pero sonreír el uno al otro de todos modos."

# game/scriptday2.rpy:225
translate Paloslios scriptday2_240d4e37:

    # "It was only then that Alan finally said something."
    "Fue solo entonces que Alan finalmente dijo algo."

# game/scriptday2.rpy:227
translate Paloslios scriptday2_0b963f55:

    # a "By the way- Is there a reason you came to find me?"
    a "Por cierto, ¿hay alguna razón por la que viniste a encontrarme?"

# game/scriptday2.rpy:228
translate Paloslios scriptday2_0f3e03d4:

    # u "Actually, I got out of my house to get some food, but I heard some chopping noises and I instinctively knew it was you."
    u "En realidad, salí de mi casa para obtener algo de comida, pero escuché algunos ruidos de corte e instintivamente supe que eras tú."

# game/scriptday2.rpy:230
translate Paloslios scriptday2_cf9acb1a:

    # "Alan's eyes stared at me, I could tell his face just brightened up."
    "Los ojos de Alan me miraron, pude decir que su rostro se iluminó."

# game/scriptday2.rpy:231
translate Paloslios scriptday2_40907763:

    # a "Aww you knew..."
    a "Aww sabías ..."

# game/scriptday2.rpy:232
translate Paloslios scriptday2_17bd9553:

    # u "I did."
    u "Hice."

# game/scriptday2.rpy:233
translate Paloslios scriptday2_82140305:

    # "I could've sworn Alan giggled to himself, his face turning red and he swayed around ever so slightly."
    "Podría haber jurado que Alan se rió para sí mismo, su rostro se puso rojo y se balanceó muy ligeramente."

# game/scriptday2.rpy:234
translate Paloslios scriptday2_4227af1a:

    # "I stayed a bit longer for small talk, I had forgotten why I was out here."
    "Me quedé un poco más para hablar, había olvidado por qué estaba aquí."

# game/scriptday2.rpy:238
translate Paloslios scriptday2_8b05a6b3:

    # u "I can't stay much longer. I should get some food before I pass out from malnourishment."
    u "No puedo quedarme mucho más tiempo. Debería obtener algo de comida antes de desmayarme por desnutrición."

# game/scriptday2.rpy:240
translate Paloslios scriptday2_1cd3a072:

    # "Alan gave me a worried expression. I felt a little bad for making a joke like that. I know that some people take skipping meals very seriously."
    "Alan me dio una expresión preocupada. Me sentí un poco mal por hacer una broma como esa. Sé que algunas personas se toman muy en serio las comidas."

# game/scriptday2.rpy:241
translate Paloslios scriptday2_5b48dd5c:

    # "I tried to eat as much as I could, I wasn't trying to starve myself on purpose."
    "Traté de comer tanto como pude, no estaba tratando de morir de hambre a propósito."

# game/scriptday2.rpy:242
translate Paloslios scriptday2_deb0a6be:

    # "I just forget to eat and sometimes it felt like a chore."
    "Solo me olvido de comer y a veces se sintió como una tarea."

# game/scriptday2.rpy:243
translate Paloslios scriptday2_69895692:

    # a "You didn't eat?"
    a "¿No comiste?"

# game/scriptday2.rpy:244
translate Paloslios scriptday2_315a487f:

    # u "That's the life of a college student for ya, Alan. Speaking of which, I gotta do boring class stuff. I'll see ya around when I get the chance."
    u "Esa es la vida de un estudiante universitario para ti, Alan. Hablando de eso, tengo que hacer cosas de clase aburrida. Te veré cuando tenga la oportunidad."

# game/scriptday2.rpy:246
translate Paloslios scriptday2_d9fc5bd6:

    # a "W-Wait! Um..."
    a "¡W-WAIT! Um ..."

# game/scriptday2.rpy:247
translate Paloslios scriptday2_554e1bb6:

    # "I stopped dead in my tracks with Alan calling out for me."
    "Me detuve en mi camino con Alan llamándome."

# game/scriptday2.rpy:248
translate Paloslios scriptday2_5ed28831:

    # a "Leaving so soon? We could h-hang out some more... How about we get you something to eat first?"
    a "¿Te va tan pronto? Podríamos hang más ... ¿qué tal si te consiguemos algo para comer primero?"

# game/scriptday2.rpy:249
translate Paloslios scriptday2_18baa0de:

    # u "I appreciate it, Alan, but it's just me doing some studies. I wouldn't wanna bore you with that."
    u "Lo aprecio, Alan, pero solo soy yo haciendo algunos estudios. No quisiera aburrirte con eso."

# game/scriptday2.rpy:251
translate Paloslios scriptday2_5a6c5753:

    # "Alan looked like a kicked puppy, his eyes growing wider and clasping his hands together. I can already see him going down on his knees and begging me at this point."
    "Alan parecía un cachorro pateado, sus ojos se crecieron y juntaban sus manos. Ya puedo verlo caer de rodillas y régame en este momento."

# game/scriptday2.rpy:252
translate Paloslios scriptday2_dd04286e:

    # voice "audio/MDHM_Alan voicelines/Day 2/02_Come oooon.mp3"
    # a "Come oooon..."
    voice "audio/mdhm_alan VoicElines/Day 2/02_come oooon.mp3"
    a "Ven oooon ..."

# game/scriptday2.rpy:254
translate Paloslios scriptday2_424fe884:

    # u "Alan, I have to go. Sorry..."
    u "Alan, tengo que irme. Lo siento..."

# game/scriptday2.rpy:255
translate Paloslios scriptday2_6ef48765:

    # "I turned around, setting my sights to head to the convenience store like how I originally intended. Alan's tone sounded disappointed."
    "Me di la vuelta, configurando mi mira para dirigirme a la tienda de conveniencia como lo intentaba originalmente. El tono de Alan sonaba decepcionado."

# game/scriptday2.rpy:256
translate Paloslios scriptday2_13627e73:

    # "I felt kinda bad to leave him behind... But I didn't have time to faffle about with some guy I just met. I needed food and I had to meet up with Erika later."
    "Me sentí un poco malo dejarlo atrás ... pero no tuve tiempo de buscar con un tipo que acabo de conocer. Necesitaba comida y tuve que reunirme con Erika más tarde."

# game/scriptday2.rpy:262
translate Paloslios scriptday2_4337cbd5:

    # "I've made my way out of the woods, a few twigs scratching my pants. I was greeted again by the worn-out sidewalk, the path lining on the horizon along with the houses on the other side of the street."
    "He salido del bosque, algunas ramitas ramitas me rascan los pantalones. Me recibieron nuevamente por la acera desgastada, el camino que se alineaba en el horizonte junto con las casas al otro lado de la calle."

# game/scriptday2.rpy:263
translate Paloslios scriptday2_5d482fff:

    # "I didn't waste any time hurrying to the Food Box, nor did I want to be late for that study date. It's not like my grades were the worst but they could be a lot better."
    "No perdí el tiempo apresurándome a la caja de alimentos, ni quería llegar tarde a esa fecha de estudio. No es que mis calificaciones fueran los peores, pero podrían ser mucho mejores."

# game/scriptday2.rpy:264
translate Paloslios scriptday2_89bb710e:

    # "The most recent grade on my English assignment was... Rather humbling. The image of Professor Mocroix shamefully shaking his head was burned in my mind."
    "La calificación más reciente en mi tarea de inglés fue ... bastante humillante. La imagen del profesor Mocroix sacudiendo vergonzosamente su cabeza fue quemada en mi mente."

# game/scriptday2.rpy:273
translate Paloslios scriptday2_9b2bb486:

    # "I was hit with the cool, air-conditioned breeze as I walked in. The same usual 'Ding!' of the store was then followed by the most unenthusiastic 'Welcome,' from two employees. Both in unison."
    "Fui golpeado con la brisa fresca y con aire acondicionado cuando entré. ¡La misma \"ding\" habitual! \" de la tienda fue seguido por la \"bienvenida\" más poco entusiasta de dos empleados. Ambos al unísono."

# game/scriptday2.rpy:274
translate Paloslios scriptday2_b855bebb:

    # "My hand reached over to the stack of plastic baskets, and I made my way around the store. I thought about what I could even eat, checking the prices so I would be within my budget."
    "Mi mano se acercó a la pila de cestas de plástico, y me dirigí a la tienda. Pensé en lo que podía comer, revisando los precios para estar dentro de mi presupuesto."

# game/scriptday2.rpy:275
translate Paloslios scriptday2_c2d36869:

    # "And perhaps buy a snack on my way back home."
    "Y tal vez compre un refrigerio en mi camino de regreso a casa."

# game/scriptday2.rpy:276
translate Paloslios scriptday2_03503458:

    # "Just a little treat."
    "Solo un pequeño regalo."

# game/scriptday2.rpy:279
translate Paloslios scriptday2_ffe62766:

    # voice "audio/MDHM_Stu voicelines/noises/Neutral/Stu_Huh confused.mp3"
    # s "[name]?"
    voice "audio/mdhm_stu VoicElines/ruidos/neutral/stu_huh confundido.mp3"
    s "[name]?"

# game/scriptday2.rpy:282
translate Paloslios scriptday2_d0b3af9a:

    # "I was pulled out of focus, hearing my name being called."
    "Me pusieron fuera de foco, escuchando mi nombre llamado."

# game/scriptday2.rpy:283
translate Paloslios scriptday2_1a5fa80f:

    # voice "audio/MDHM_Stu voicelines/Day 2/01_OMG is that you.mp3"
    # s "Oh my god, [name]! Is that you?"
    voice "audio/mdhm_stu VoicElines/Day 2/01_omg es que yo.mp3"
    s "Dios mío, [name]! ¿Eres tu?"

# game/scriptday2.rpy:285
translate Paloslios scriptday2_46657b43:

    # "I heard a voice coming to my right, and I was met with a bright, cheerful face."
    "Escuché una voz que llegaba a mi derecha, y me encontré con una cara brillante y alegre."

# game/scriptday2.rpy:292
translate Paloslios scriptday2_a2a23130:

    # u "!!!"
    u "!"

# game/scriptday2.rpy:295
translate Paloslios scriptday2_3c501fa9:

    # voice "audio/MDHM_Stu voicelines/noises/Happy/Stu_Hey.mp3"
    # s "Hey [name]!"
    voice "audio/mdhm_stu VoicElines/ruidos/happy/stu_hey.mp3"
    s "Hola [name]!"

# game/scriptday2.rpy:298
translate Paloslios scriptday2_ad6989fb:

    # "I recognize that dorky smile from anywhere."
    "Reconozco esa sonrisa tonta desde cualquier lugar."

# game/scriptday2.rpy:300
translate Paloslios scriptday2_2e46191d:

    # u "... Stu?"
    u "... Stu?"

# game/scriptday2.rpy:302
translate Paloslios scriptday2_42ed152c:

    # "My eyes slowly blinked and the hamster wheels in my head quickly started to turn."
    "Mis ojos parpadearon lentamente y las ruedas de hámster en mi cabeza rápidamente comenzaron a girar."

# game/scriptday2.rpy:305
translate Paloslios scriptday2_c1017bb0:

    # voice "audio/MDHM_Stu voicelines/noises/Happy/Stu_Laugh 1.mp3"
    # s "Fancy seein' you here!"
    voice "audio/mdhm_stu VoicElines/ruidos/happy/stu_laugh 1.mp3"
    s "¡Falta verte aquí!"

# game/scriptday2.rpy:308
translate Paloslios scriptday2_196b2387:

    # "If I weren't in a public area, I would've dropped my basket right then and there. Stu flashed me a grin, the bastard I hadn't seen since High School standing right before me."
    "Si no estuviera en un área pública, habría dejado caer mi canasta en ese momento. Stu me mostró una sonrisa, el bastardo que no había visto desde la escuela secundaria parada justo delante de mí."

# game/scriptday2.rpy:309
translate Paloslios scriptday2_a9a91801:

    # u "Seeing me here?! How the hell did you get here?! Why are you here?!"
    u "¿Me vemos aquí?! ¿Cómo diablos llegaste aquí? ¿Por qué estás aquí?"

# game/scriptday2.rpy:311
translate Paloslios scriptday2_fe58a621:

    # s "It's my job to bother you, is it not?"
    s "Es mi trabajo molestarte, ¿no?"

# game/scriptday2.rpy:312
translate Paloslios scriptday2_e6e99b2a:

    # "That cheeky comment he made was met with a playful punch on his arm. Stu let out a soft 'oof', rubbing his side but kept that smile on his face."
    "Ese descarado comentario que hizo se encontró con un golpe juguetón en su brazo. Stu dejó escapar un suave 'OOF', frotando su costado pero mantuvo esa sonrisa en su rostro."

# game/scriptday2.rpy:313
translate Paloslios scriptday2_bf7b4741:

    # u "That's not what I meant! I thought you said you didn't have a chance to move here. So..."
    u "¡Eso no es lo que quise decir! Pensé que dijiste que no tenías la oportunidad de mudarte aquí. Entonces..."

# game/scriptday2.rpy:315
translate Paloslios scriptday2_ab343aa7:

    # "As my words trailed off, Stu scratched the back of his head uncomfortably, letting out a nervous laugh."
    "Mientras mis palabras se apagaban, Stu se rascó la parte posterior de su cabeza incómoda, dejando escapar una risa nerviosa."

# game/scriptday2.rpy:316
translate Paloslios scriptday2_50942370:

    # voice "audio/MDHM_Stu voicelines/Day 2/04_Guess.mp3"
    # s "Your guess is as good as mine. I don't know what the forces of the universe are doing, but I'll be sure to thank them!"
    voice "audio/mdhm_stu VoicElines/Day 2/04_Guess.mp3"
    s "Tu suposición es tan buena como la mía. No sé qué están haciendo las fuerzas del universo, ¡pero me aseguraré de agradecerles!"

# game/scriptday2.rpy:318
translate Paloslios scriptday2_a0dff9f1:

    # u "You got accepted?"
    u "¿Te aceptan?"

# game/scriptday2.rpy:320
translate Paloslios scriptday2_2d7d6d5c:

    # "Stu didn't give me an answer. His teeth flashed a proud smile and a wink, his hand comically placed under his chin."
    "Stu no me dio una respuesta. Sus dientes pisaron una sonrisa orgullosa y un guiño, su mano colocada cómicamente debajo de la barbilla."

# game/scriptday2.rpy:321
translate Paloslios scriptday2_5aecad84:

    # u "And you didn't tell me?"
    u "¿Y no me lo dijiste?"

# game/scriptday2.rpy:323
translate Paloslios scriptday2_10e4b787:

    # s "W-Well, I was going to!"
    s "Bu-Bueno, ¡iba a hacerlo!"

# game/scriptday2.rpy:324
translate Paloslios scriptday2_fca58f08:

    # u "You see, I want to believe that."
    u "Ya ves, quiero creer eso."

# game/scriptday2.rpy:326
translate Paloslios scriptday2_8d0f2778:

    # "Stu pouted his lips. His brows creased together while throwing his head back like a child not getting the toy he wanted."
    "Stu puso sus labios. Sus cejas arrugaron juntas mientras arrojaban la cabeza hacia atrás como un niño que no tenía el juguete que quería."

# game/scriptday2.rpy:329
translate Paloslios scriptday2_8b0369ea:

    # voice "audio/MDHM_Stu voicelines/noises/Happy/Stu_Happy Sigh 2.mp3"
    # voice "audio/MDHM_Stu voicelines/Day 2/03_Glad to see me.mp3"
    # s "[name]... At least say you're glad to see me..."
    voice "audio/mdhm_stu VoicElines/ruidos/happy/stu_happy sigh 2.mp3"
    voice "audio/mdhm_stu VoicElines/Day 2/03_Glad para verme.mp3"
    s "[name] ... al menos diga que estás contento de verme ..."

# game/scriptday2.rpy:333
translate Paloslios scriptday2_373aba1d:

    # "Okay, that's enough torturing the poor guy. I can't promise that I can hold myself back, it's been a while since I've last even spoken with Stu. We used to text each other almost every day but over time..."
    "Bien, eso es suficiente torturar al pobre tipo. No puedo prometer que puedo detenerme, ha pasado un tiempo desde que he hablado incluso con Stu. Solíamos enviarnos mensajes de texto casi todos los días, pero con el tiempo ..."

# game/scriptday2.rpy:334
translate Paloslios scriptday2_80ecf228:

    # "Our conversations would stop being engaging and eventually, he just stopped responding."
    "Nuestras conversaciones dejarían de ser atractivas y, finalmente, él dejó de responder."

# game/scriptday2.rpy:335
translate Paloslios scriptday2_f10d553b:

    # "I shouldn't dwell on that right now, I mean, he's here now."
    "No debería detenerme en eso ahora mismo, quiero decir, él está aquí ahora."

# game/scriptday2.rpy:336
translate Paloslios scriptday2_58f65b29:

    # u "I really am glad to see you, Stu."
    u "Realmente me alegro de verte, Stu."

# game/scriptday2.rpy:338
translate Paloslios scriptday2_716e38f3:

    # "He smiled at me."
    "Me sonrió."

# game/scriptday2.rpy:339
translate Paloslios scriptday2_61c5a35f:

    # s "Yeah... It's nice to finally see you again."
    s "Sí ... es bueno finalmente verte de nuevo."

# game/scriptday2.rpy:341
translate Paloslios scriptday2_4e933a7b:

    # "We both fell to a silence, with Stu's eyes falling to the floor, and his hands stuffing the bags of his pockets."
    "Ambos cayeron en silencio, con los ojos de Stu cayendo al suelo, y sus manos rellenando las bolsas de sus bolsillos."

# game/scriptday2.rpy:342
translate Paloslios scriptday2_cb88037f:

    # s "So Um... Got any plans right now?"
    s "Entonces, um ... ¿tienes algún plan en este momento?"

# game/scriptday2.rpy:343
translate Paloslios scriptday2_b68109d8:

    # "Oh! I almost forgot what I was even here for."
    "¡Oh! Casi olvido para qué estaba aquí."

# game/scriptday2.rpy:344
translate Paloslios scriptday2_531293a6:

    # u "Y-Yeah, actually. I was gonna make breakfast and study with a friend."
    u "Y-Yeah, en realidad. Iba a preparar el desayuno y estudiar con un amigo."

# game/scriptday2.rpy:345
translate Paloslios scriptday2_a0d24bb3:

    # s "Oh."
    s "Oh."

# game/scriptday2.rpy:346
translate Paloslios scriptday2_bcb9371c:

    # "Stu shifted awkwardly in place, his well-worn, scuffed white sneakers tapped at the tiled floor of the store. By that tone of his voice, he sounded disappointed."
    "Stu cambió torpemente en su lugar, sus zapatillas blancas desgastadas y desgarradas tocadas en el piso de los mosaicos de la tienda. Por ese tono de su voz, sonaba decepcionado."

# game/scriptday2.rpy:347
translate Paloslios scriptday2_8d0ceaf6:

    # s "That's too bad. I was looking forward to catching up with you."
    s "Eso es una lástima. Tenía muchas ganas de ponerme al día contigo."

# game/scriptday2.rpy:349
translate Paloslios scriptday2_44d672cd:

    # "Stu's lips slowly tugged at a sad, but hopeful smile. His eyes widened, all teary-eyed."
    "Los labios de Stu tiraron lentamente ante una sonrisa triste pero esperanzadora. Sus ojos se abrieron, todos con los ojos llorosos."

# game/scriptday2.rpy:350
translate Paloslios scriptday2_3a9bcc26:

    # "I let out a loud sigh. I should be happy that he now has the decency to reach out to me this time. However, I can't just let him tag along out of nowhere."
    "Dejé escapar un fuerte suspiro. Debería estar feliz de que ahora tenga la decencia de contactarme esta vez. Sin embargo, no puedo dejar que salga de la nada."

# game/scriptday2.rpy:351
translate Paloslios scriptday2_fe750171:

    # u "Stu, do you want to come?"
    u "Stu, ¿quieres venir?"

# game/scriptday2.rpy:353
translate Paloslios scriptday2_f394a9b5:

    # "His face brightened as if he wasn't begging me to take him out just a minute ago."
    "Su rostro se iluminó como si no me rogara que lo sacara hace solo un minuto."

# game/scriptday2.rpy:354
translate Paloslios scriptday2_7474602a:

    # s "Oh wow, [name]! I would LOVE to!"
    s "Oh wow, [name]! ¡Me encantaría!"

# game/scriptday2.rpy:355
translate Paloslios scriptday2_de7fa07a:

    # "Guess that settles it."
    "Supongo que eso lo resuelve."

# game/scriptday2.rpy:364
translate Paloslios scriptday2_f98700d7:

    # "It has been forever since I've last talked to Stu. While I didn't add much to the conversation on our way to the park, he kept things lively, even making me laugh. It's been a while since I've been this happy."
    "Ha sido una eternidad desde la última vez que hablé con Stu. Si bien no agregué mucho a la conversación en nuestro camino al parque, él mantuvo las cosas animadas, incluso me hacía reír. Ha pasado un tiempo desde que he estado tan feliz."

# game/scriptday2.rpy:365
translate Paloslios scriptday2_73227abb:

    # s "Sooo anything new lately?"
    s "¿Entonces algo nuevo últimamente?"

# game/scriptday2.rpy:370
translate Paloslios scriptday2_97dbac27:

    # s "Have classes been easy on ya? Made any friends?"
    s "¿Las clases han sido fáciles de ti? ¿Hizo amigos?"

# game/scriptday2.rpy:371
translate Paloslios scriptday2_298b3e9e:

    # u "Well... Made a couple."
    u "Bueno ... hizo una pareja."

# game/scriptday2.rpy:372
translate Paloslios scriptday2_7a01ebbc:

    # "Those two being a college classmate I barely talk to and a guy I just met."
    "Esos dos son compañeros de clase universitarios con el que apenas hablo y un chico que acabo de conocer."

# game/scriptday2.rpy:374
translate Paloslios scriptday2_d8efbe2f:

    # s "I'm guessing this 'Erika' person is one of them?"
    s "Supongo que esta persona 'Erika' es una de ellas."

# game/scriptday2.rpy:375
translate Paloslios scriptday2_9bbbea13:

    # u "That she is."
    u "Que ella es."

# game/scriptday2.rpy:380
translate Paloslios scriptday2_6d507e37:

    # "Stu gave me a playful expression after he had pestered me with questions. While I loved Stu and he is my best friend, I hope he doesn't embarrass me in front of Erika."
    "Stu me dio una expresión juguetona después de que me había molestado con preguntas. Si bien amaba a Stu y él es mi mejor amigo, espero que no me avergüence frente a Erika."

# game/scriptday2.rpy:381
translate Paloslios scriptday2_163d6157:

    # "While we weren't close by any means, Erika did try to talk to me. Whether that was because she truly wanted to be a friend or she pitied me I don't really wanna know."
    "Si bien no estábamos cerca de ninguna manera, Erika intentó hablar conmigo. Si eso era porque realmente quería ser una amiga o me compadecía, realmente no quiero saberlo."

# game/scriptday2.rpy:382
translate Paloslios scriptday2_9d82acab:

    # "Erika has told me that she doesn't usually pass time with classmates outside of class. Said that she had too many instances of guys wanting to 'borrow her bras'."
    "Erika me ha dicho que generalmente no pasa tiempo con compañeros de clase fuera de clase. Dijo que tenía demasiados casos de tipos que querían 'tomar prestados sus sostenes'."

# game/scriptday2.rpy:383
translate Paloslios scriptday2_920691b3:

    # "Yikes."
    "Ay."

# game/scriptday2.rpy:385
translate Paloslios scriptday2_10c8f107:

    # e "[name]."
    e "[name]."

# game/scriptday2.rpy:387
translate Paloslios scriptday2_ffd0c649:

    # "I hear my name through the whole commotion of the park. There, sat Erika on a bed of green grass, an intricate lacey pink blanket spread on the ground."
    "Escucho mi nombre a través de toda la conmoción del parque. Allí, se sentó Erika en una cama de hierba verde, una intrincada manta rosa lacey extendida en el suelo."

# game/scriptday2.rpy:388
translate Paloslios scriptday2_42232bb7:

    # "Did she set up this study date like a picnic? She even packed snacks and drinks."
    "¿Estableció esta fecha de estudio como un picnic? Incluso empacó bocadillos y bebidas."

# game/scriptday2.rpy:393
translate Paloslios scriptday2_a3df40bc:

    # voice "audio/MDHM_Erika voicelines/Day 2/03_Made it.mp3"
    # e "You made it."
    voice "audio/mdhm_erika VoicElines/Day 2/03_Made It.mp3"
    e "Lo hiciste."

# game/scriptday2.rpy:395
translate Paloslios scriptday2_ea74e567:

    # "I briefly waved at Erika as we both approached her. Her usual, apathetic face never faltered, even when she caught a glance at the sight of Stu."
    "Salí brevemente a Erika cuando ambos nos acercamos a ella. Su cara habitual y apática nunca vaciló, incluso cuando miró a la vista de Stu."

# game/scriptday2.rpy:396
translate Paloslios scriptday2_7cee07aa:

    # e "Um and who's this?"
    e "Um y ¿quién es este?"

# game/scriptday2.rpy:397
translate Paloslios scriptday2_fd541eb2:

    # u "Ah, this is a friend of mine, Stu-"
    u "Ah, este es un amigo mío, Stu-"

# game/scriptday2.rpy:399
translate Paloslios scriptday2_71aedbdb:

    # s "Heeeey! Nice to meet ya! Name's Stu!"
    s "¡HEEEEY! ¡Encantado de conocerte! ¡El nombre es Stu!"

# game/scriptday2.rpy:400
translate Paloslios scriptday2_1c2ba578:

    # "I sighed, and Stu extended his hand toward Erika. The look on her face I could tell she wasn't exactly charmed. At least from what I could see."
    "Suspiré y Stu extendió su mano hacia Erika. La expresión de su rostro que podría decir que no estaba exactamente encantada. Al menos por lo que pude ver."

# game/scriptday2.rpy:401
translate Paloslios scriptday2_96989dc8:

    # "Erika took Stu's hand, her usual dead expressionless eyes never faltered."
    "Erika tomó la mano de Stu, sus ojos inexpresivos habituales nunca vacilaron."

# game/scriptday2.rpy:402
translate Paloslios scriptday2_5b3f37c3:

    # e "Pleasure's all mine."
    e "El placer es todo mío."

# game/scriptday2.rpy:403
translate Paloslios scriptday2_bc07b7ae:

    # "Her voice remained monotonous, but there was a drag to her words, almost like she's sarcastic."
    "Su voz permaneció monótona, pero había un arrastre para sus palabras, casi como si fuera sarcástica."

# game/scriptday2.rpy:404
translate Paloslios scriptday2_e1f74fa2:

    # "I stared at both of them, two extremes shaking hands. One was happy to be there and the other one's gaze slowly made their way towards my direction."
    "Los miré a los dos, dos extremos estrechando la mano. Uno estaba feliz de estar allí y la mirada del otro lentamente se dirigió hacia mi dirección."

# game/scriptday2.rpy:406
translate Paloslios scriptday2_1db87ccb:

    # "Erika is staring daggers at me."
    "Erika me está mirando dagas."

# game/scriptday2.rpy:407
translate Paloslios scriptday2_1a3a36c4:

    # e "Want to tell me the change of plans, [name]?"
    e "¿Quieres decirme el cambio de planes, [name]?"

# game/scriptday2.rpy:408
translate Paloslios scriptday2_faf568be:

    # u "S-Sorry! It was kinda last minute and I haven't seen Stu since High School-"
    u "S-sorry! Fue un poco en el último minuto y no he visto Stu desde la escuela secundaria"

# game/scriptday2.rpy:411
translate Paloslios scriptday2_4e17d25d:

    # voice "audio/MDHM_Erika voicelines/noises/Neautral/Erika_Hmm.mp3"
    # e "Hmm."
    voice "audio/mdhm_erika VoicElines/ruidos/neautral/erika_hmm.mp3"
    e "Mmm."

# game/scriptday2.rpy:414
translate Paloslios scriptday2_a9f2d75d:

    # "My rambling was cut short and a slight shiver ran down my spine. It was so hard to tell what Erika was thinking due to her blank demeanor. Maybe I should just shut up instead of coming up with an excuse."
    "Mi divagación se interrumpió y un ligero escalofrío corrió por mi columna vertebral. Era muy difícil saber qué estaba pensando Erika debido a su comportamiento en blanco. Tal vez debería callarme en lugar de tener una excusa."

# game/scriptday2.rpy:416
translate Paloslios scriptday2_5c932138:

    # e "Well- Are we gonna study or not? I packed some lunch just in case."
    e "¿Vamos a estudiar o no? Empacé un poco de almuerzo por si acaso."

# game/scriptday2.rpy:418
translate Paloslios scriptday2_44c40e2b:

    # "Both me and Stu look over to the setup. There were only a couple of things that could be eaten along with small amounts of snacks scattered. Stu frowned."
    "Tanto yo como Stu miran la configuración. Solo había un par de cosas que se podían comer junto con pequeñas cantidades de bocadillos dispersos. Stu frunció el ceño."

# game/scriptday2.rpy:419
translate Paloslios scriptday2_c138c238:

    # s "I guess there's not enough food for one more?"
    s "¿Supongo que no hay suficiente comida para uno más?"

# game/scriptday2.rpy:421
translate Paloslios scriptday2_6ec6e0e9:

    # e "Well what do you think?"
    e "Bueno, ¿qué piensas?"

# game/scriptday2.rpy:423
translate Paloslios scriptday2_0c781cc8:

    # s "N-No...?"
    s "N-no ...?"

# game/scriptday2.rpy:424
translate Paloslios scriptday2_cb6cfeff:

    # "There was a beat of silence. If looks could kill, Stu would be dead on the spot with Erika's cold stare. Even I felt a chill down my spine."
    "Hubo un ritmo de silencio. Si los looks pudieran matar, Stu estaría muerto en el acto con la mirada fría de Erika. Incluso sentí un escalofrío por mi columna vertebral."

# game/scriptday2.rpy:426
translate Paloslios scriptday2_0de637c7:

    # voice "audio/MDHM_Erika voicelines/Day 2/06_Good boy.mp3"
    # e "Fast learner. Good boy, keep up."
    voice "audio/mdhm_erika VoicElines/Day 2/06_Good Boy.mp3"
    e "Aprendiz rápido. Buen chico, sigue el ritmo."

# game/scriptday2.rpy:428
translate Paloslios scriptday2_bff33aee:

    # "Erika immediately perked back up and walked back to her spot, with us following suit. Stu looked at me with a puzzled expression, confused about what happened. I could only return a supportive, albeit apprehensive smile."
    "Erika inmediatamente volvió a subir y regresó a su lugar, con nosotros siguiendo su ejemplo. Stu me miró con una expresión perpleja, confundida sobre lo que sucedió. Solo podía devolver una sonrisa de apoyo, aunque aprensiva."

# game/scriptday2.rpy:429
translate Paloslios scriptday2_044974cb:

    # "Erika didn't brush him off or insult him outright, so I guess that was a good sign."
    "Erika no lo cepilló ni lo insultó directamente, así que supongo que fue una buena señal."

# game/scriptday2.rpy:431
translate Paloslios scriptday2_781940a4:

    # "We all sat down together, both right across from me, the basket of food perfectly sat in the middle. I saw Erika take out some assignments and a book we had been assigned."
    "Todos nos sentamos juntos, ambos justo frente a mí, la canasta de comida se sentó perfectamente en el medio. Vi a Erika sacar algunas tareas y un libro que nos habían asignado."

# game/scriptday2.rpy:432
translate Paloslios scriptday2_d7df23a8:

    # e "Should I go over the lesson for you?"
    e "¿Debería revisar la lección por ti?"

# game/scriptday2.rpy:433
translate Paloslios scriptday2_57733e32:

    # u "That would be nice."
    u "Eso sería bueno."

# game/scriptday2.rpy:434
translate Paloslios scriptday2_79f70d45:

    # "Erika nodded at me, graciously placing a pencil right behind her ear while flipping through the textbook."
    "Erika me asintió, colocando gentilmente un lápiz justo detrás de la oreja mientras hojeaba el libro de texto."

# game/scriptday2.rpy:435
translate Paloslios scriptday2_1282fb08:

    # "Throughout the day, we mostly talked amongst ourselves, sometimes Stu would join in with a brief conversation when he got too antsy about being left out."
    "A lo largo del día, hablamos principalmente entre nosotros, a veces Stu se uniría a una breve conversación cuando se puso demasiado ansioso por quedarse fuera."

# game/scriptday2.rpy:436
translate Paloslios scriptday2_eeb84e3c:

    # "It's not that I was purposely trying to ignore him. Far from it but him being a part of our study date wasn't exactly the plan."
    "No es que intentara deliberadamente ignorarlo. Lejos de eso, pero él es parte de nuestra fecha de estudio no fue exactamente el plan."

# game/scriptday2.rpy:437
translate Paloslios scriptday2_bfd6da1e:

    # "I care enough for him to come along, but then again, it's not like he gave me much to think about. It was very last minute."
    "Me importa lo suficiente como para que venga, pero, de nuevo, no es como si me haya dado mucho en qué pensar. Fue muy último minuto."

# game/scriptday2.rpy:438
translate Paloslios scriptday2_31786078:

    # "I don't know whether to feel bad or be frustrated at Stu. He was the one who wanted to tag along."
    "No sé si sentirme mal o sentirse frustrado en Stu. Él fue el que quería acompañarlo."

# game/scriptday2.rpy:439
translate Paloslios scriptday2_caeb15d6:

    # "My eyes kept glancing over at him, he kept looking behind him, staring up at some bushes and trees, and the occasional stray dog walking around. Anything to distract him, I figured."
    "Mis ojos seguían mirándolo, seguía mirando detrás de él, mirando algunos arbustos y árboles, y el perro callejero ocasional caminando. Cualquier cosa para distraerlo, pensé."

# game/scriptday2.rpy:441
translate Paloslios scriptday2_ca95b42c:

    # e "Hey."
    e "Ey."

# game/scriptday2.rpy:442
translate Paloslios scriptday2_5f78b926:

    # "I lost my train of thought when I heard Erika calling for... Stu? I'm surprised by that, even more so Stu."
    "Perdí mi tren de pensamiento cuando escuché a Erika pedir ... ¿Stu? Me sorprende eso, aún más Stu."

# game/scriptday2.rpy:444
translate Paloslios scriptday2_be3da303:

    # "Erika was the first to reach over the picnic basket, pulling out a cold drink, and handing it over to Stu, his eyes widening at her in surprise."
    "Erika fue la primera en alcanzar la canasta de picnic, sacando una bebida fría y entregándola a Stu, sus ojos se abrieron sorprendidos."

# game/scriptday2.rpy:445
translate Paloslios scriptday2_e1554201:

    # s "..."
    s "..."

# game/scriptday2.rpy:447
translate Paloslios scriptday2_2d89bf8c:

    # e "What? You think I wouldn't offer you at least a drink? I'm not that rude. Take it."
    e "¿Qué? ¿Crees que no te ofrecería al menos una bebida? No soy tan grosero. Tómalo."

# game/scriptday2.rpy:450
translate Paloslios scriptday2_10dd9c01:

    # voice "audio/MDHM_Stu voicelines/noises/Happy/Stu_Laugh 1.mp3"
    voice "audio/mdhm_stu VoicElines/ruidos/happy/stu_laugh 1.mp3"

# game/scriptday2.rpy:453
translate Paloslios scriptday2_ef551c33:

    # s "Sweet!"
    s "¡Dulce!"

# game/scriptday2.rpy:454
translate Paloslios scriptday2_41dd1ed0:

    # "Stu beamed, shifting closer to Erika and reaching out to take the can of soda."
    "Stu se dirigió, cambiando más cerca de Erika y extendiendo la lata de refrescos."

# game/scriptday2.rpy:455
translate Paloslios scriptday2_09e3b957:

    # "Only for Erika to pull back out of his reach."
    "Solo para que Erika se retire de su alcance."

# game/scriptday2.rpy:457
translate Paloslios scriptday2_0a327b0e:

    # e "Say the magic words."
    e "Di las palabras mágicas."

# game/scriptday2.rpy:459
translate Paloslios scriptday2_51fe7841:

    # s "H-Huh?"
    s "¿H-huh?"

# game/scriptday2.rpy:460
translate Paloslios scriptday2_a20cefa7_2:

    # "..."
    "..."

# game/scriptday2.rpy:462
translate Paloslios scriptday2_c08087e6:

    # e "I'm just messing with you. Here."
    e "Solo estoy jugando contigo. Aquí."

# game/scriptday2.rpy:464
translate Paloslios scriptday2_feaf406f:

    # "Stu could only let out a light-hearted, but nervous chuckle, grabbing the soda slowly as if he was afraid that Erika could pull another move. Maybe I should've warned him about Erika's dry sense of humor."
    "Stu solo podía dejar escapar una risa alegre, pero nerviosa, agarrando el refresco lentamente como si tuviera miedo de que Erika pudiera hacer otro movimiento. Tal vez debería haberle advertido sobre el sentido del humor seco de Erika."

# game/scriptday2.rpy:467
translate Paloslios scriptday2_57336ddb:

    # "It was awkward, but it was good to see them getting along at least. I didn't know much about Erika, her presence was intimidating in the admirable kind of way."
    "Fue incómodo, pero fue bueno verlos llevarse al menos. No sabía mucho sobre Erika, su presencia era intimidante de la manera admirable."

# game/scriptday2.rpy:468
translate Paloslios scriptday2_6645e230:

    # "She was just so cool. I wanted to get to know her better."
    "Ella era tan genial. Quería conocerla mejor."

# game/scriptday2.rpy:469
translate Paloslios scriptday2_ef34ea95:

    # "Not trying to imply that Stu is a complete loser, but that we were both complete losers back in the day."
    "No tratar de implicar que Stu es un completo perdedor, pero que ambos éramos perdedores completos en el pasado."

# game/scriptday2.rpy:470
translate Paloslios scriptday2_da7da16a:

    # "I know that high school reputation doesn't exactly matter in the real world, but I still welcomed the change with open arms."
    "Sé que la reputación de la escuela secundaria no importa exactamente en el mundo real, pero aún así agradecí el cambio con los brazos abiertos."

# game/scriptday2.rpy:471
translate Paloslios scriptday2_60e40fa7:

    # "I looked over to Erika, noting how her fingers lightly trace over the text on the surface of the page."
    "Miré a Erika, notando cómo sus dedos trazan ligeramente sobre el texto en la superficie de la página."

# game/scriptday2.rpy:475
translate Paloslios scriptday2_435a8126:

    # "The book Erika was holding caught my attention. It looked rather old, the edges already fading from its original color, and the paper crinkled with every movement."
    "El libro que Erika estaba sosteniendo me llamó la atención. Parecía bastante viejo, los bordes ya se desvanecían de su color original, y el papel se arrugó con cada movimiento."

# game/scriptday2.rpy:476
translate Paloslios scriptday2_71cc3f02:

    # u "So, what book did you pick for our assignment?"
    u "Entonces, ¿qué libro elegiste para nuestra tarea?"

# game/scriptday2.rpy:477
translate Paloslios scriptday2_f640de4c:

    # "Erika turned over to the cover of the book, and I read its title."
    "Erika dio la vuelta a la portada del libro, y leí su título."

# game/scriptday2.rpy:478
translate Paloslios scriptday2_da73751d:

    # u "Whispers of the Hanged?"
    u "Susurros del ahorcado?"

# game/scriptday2.rpy:479
translate Paloslios scriptday2_13734d0e:

    # "The title sounded a little gruesome."
    "El título sonaba un poco horrible."

# game/scriptday2.rpy:480
translate Paloslios scriptday2_310311ba:

    # u "Sooo what's it about?"
    u "Entonces, ¿de qué se trata?"

# game/scriptday2.rpy:481
translate Paloslios scriptday2_9ac9fffb:

    # e "The actual history of the Salem Witch Trials. It goes through all the grim details of what women of that time went through. The excruciating executions-"
    e "La historia real de los juicios de bruja de Salem. Pasa por todos los detalles sombríos de lo que pasaron las mujeres de esa época. Las ejecuciones insoportables-"

# game/scriptday2.rpy:482
translate Paloslios scriptday2_2e80f41e:

    # e "Most were hangings, but there is a case that involved being slowly crushed by heavy stones- think like a medieval hydrologic press- and we haven't even covered the awful conditions for those kept in jail."
    e "La mayoría eran colgantes, pero hay un caso que implicaba ser aplastado lentamente por piedras pesadas, piensan como una prensa hidrológica medieval, y ni siquiera hemos cubierto las horribles condiciones para los que se mantienen en la cárcel."

# game/scriptday2.rpy:483
translate Paloslios scriptday2_5c3b1b34:

    # e "Literally waiting for months without a trial, many of them being tortured during it- "
    e "Literalmente esperando durante meses sin juicio, muchos de ellos son torturados durante "

# game/scriptday2.rpy:484
translate Paloslios scriptday2_a20cefa7_3:

    # "..."
    "..."

# game/scriptday2.rpy:489
translate Paloslios scriptday2_e8aad902:

    # e "If I'm starting to ramble, you're free to tell me to stop."
    e "Si estoy empezando a divagar, eres libre de decirme que me detenga."

# game/scriptday2.rpy:490
translate Paloslios scriptday2_b0d578a8:

    # u "No you're fine. That's rather interesting. Come to think of it, Salem is not that far from here, right?"
    u "No, estás bien. Eso es bastante interesante. Ahora que lo pienso, Salem no está tan lejos de aquí, ¿verdad?"

# game/scriptday2.rpy:492
translate Paloslios scriptday2_8a61d4f4:

    # "Erika nodded at me, she looked beaming with enthusiasm that I engaged with her in the conversation."
    "Erika me asintió, parecía radiante de entusiasmo que me involucré con ella en la conversación."

# game/scriptday2.rpy:493
translate Paloslios scriptday2_044af6b5:

    # e "Yes. Back in the day, Doomsbury used to be a safe haven for those who were accused of witchcraft."
    e "Sí. En el pasado, Doomsbury solía ser un refugio seguro para aquellos acusados de brujería."

# game/scriptday2.rpy:495
translate Paloslios scriptday2_57fbbbef:

    # "Erika smiled at me, her eyes shifting back to her book cover."
    "Erika me sonrió, sus ojos volvieron a la portada de su libro."

# game/scriptday2.rpy:498
translate Paloslios scriptday2_13f3f177:

    # u "Anything new going on?"
    u "¿Algo nuevo?"

# game/scriptday2.rpy:499
translate Paloslios scriptday2_b4b68539:

    # "Erika perked up, her eyes now focusing onto to me. It took her a moment to respond, but there was a vague smile on her face. One I could barely noticed as she flipped the page."
    "Erika se animó, sus ojos ahora se enfocan en mí. Le tomó un momento responder, pero había una sonrisa vaga en su rostro. Uno que apenas podía notar mientras ella volteaba la página."

# game/scriptday2.rpy:500
translate Paloslios scriptday2_7610fdec:

    # e "Nothing eventful or important for me to comment on. But I don't think that's the answer you want."
    e "Nada lleno de accesorios o importantes para mí. Pero no creo que esa sea la respuesta que quieres."

# game/scriptday2.rpy:501
translate Paloslios scriptday2_e6a451d1:

    # u "Um..."
    u "Um ..."

# game/scriptday2.rpy:502
translate Paloslios scriptday2_d0952f29:

    # "There was a small, awkward silence as Erika proceeds to highlight a passage from the book. She was holding a lavender highlighter marker that had a small cat paw at the end of the cap."
    "Hubo un pequeño e incómodo silencio cuando Erika procede a resaltar un pasaje del libro. Estaba sosteniendo un marcador de resaltador de lavanda que tenía una pequeña pata de gato al final de la tapa."

# game/scriptday2.rpy:503
translate Paloslios scriptday2_3413f8fa:

    # e "I tried one of the local bakeries in here. Suffice to say, their pastries were decent. Then again, I'm a snob when it comes to them. Their coffee was good, though. Better than the school cafe."
    e "Probé una de las panaderías locales aquí. Baste decir que sus pasteles eran decentes. Por otra parte, soy un snob cuando se trata de ellos. Sin embargo, su café era bueno. Mejor que el café escolar."

# game/scriptday2.rpy:504
translate Paloslios scriptday2_4789e1ee:

    # u "A pastry snob? I didn't know you had expensive taste."
    u "¿Un snob de pastelería? No sabía que tenías un gusto costoso."

# game/scriptday2.rpy:506
translate Paloslios scriptday2_d711208b:

    # "Erika huffed out a chuckle."
    "Erika resopló una risa."

# game/scriptday2.rpy:507
translate Paloslios scriptday2_fd72e698:

    # voice "audio/MDHM_Erika voicelines/Day 2/07_Ingredient.mp3"
    # e "Not even. I'm just used to what my dad would bake. Love and nostalgia bias is the best ingredient."
    voice "audio/mdhm_erika VoicElines/Day 2/07_ingredient.mp3"
    e "Ni siquiera. Estoy acostumbrado a lo que mi papá hornearía. El sesgo de amor y nostalgia es el mejor ingrediente."

# game/scriptday2.rpy:510
translate Paloslios scriptday2_35ac6a84:

    # "Me and Stu both laughed collectively."
    "Stu y yo nos reímos colectivamente."

# game/scriptday2.rpy:513
translate Paloslios scriptday2_e6efc7d1:

    # voice "audio/MDHM_Stu voicelines/noises/Happy/Stu_Cough_2.mp3"
    voice "audio/mdhm_stu VoicElines/ruidos/happy/stu_cough_2.mp3"

# game/scriptday2.rpy:515
translate Paloslios scriptday2_d35fc114:

    # "Before we could continue, we heard an awkward cough coming from none other than Stu himself. Oh."
    "Antes de que pudiéramos continuar, escuchamos una tos incómoda proveniente de nada menos que el propio Stu. Oh."

# game/scriptday2.rpy:516
translate Paloslios scriptday2_ed1d1113:

    # "I totally had forgotten he was even there, I was so wrapped up with Erika."
    "Había olvidado totalmente que estaba incluso allí, estaba tan envuelto con Erika."

# game/scriptday2.rpy:518
translate Paloslios scriptday2_6a087f2f:

    # voice "audio/MDHM_Stu voicelines/Day 2/10_Soooo.mp3"
    # s "Soooo..."
    voice "audio/mdhm_stu VoicElines/Day 2/10_Soooo.mp3"
    s "Soooo ..."

# game/scriptday2.rpy:520
translate Paloslios scriptday2_20dcc6ef:

    # voice "audio/MDHM_Stu voicelines/Day 2/11_Do you guys.mp3"
    # s "Do you guys..."
    voice "audio/mdhm_stu VoicElines/Day 2/11_Do Guys.mp3"
    s "¿Ustedes ..."

# game/scriptday2.rpy:522
translate Paloslios scriptday2_6f061301:

    # voice "audio/MDHM_Stu voicelines/Day 2/12_Watch.mp3"
    # s "Watch..."
    voice "audio/mdhm_stu VoicElines/Day 2/12_watch.mp3"
    s "Mirar..."

# game/scriptday2.rpy:525
translate Paloslios scriptday2_cc5cd9a5:

    # voice "audio/MDHM_Stu voicelines/Day 2/13_Anime.mp3"
    # s "Anime...?"
    voice "audio/mdhm_stu VoicElines/Day 2/13_anime.mp3"
    s "Anime ...?"

# game/scriptday2.rpy:527
translate Paloslios scriptday2_c516d568:

    # "Oh great."
    "Oh genial."

# game/scriptday2.rpy:529
translate Paloslios scriptday2_66b89728:

    # "Erika looked over to me with an unamused look but there was a tiny smile slowly creeping in."
    "Erika me miró con una mirada sin amonestar, pero había una pequeña sonrisa que se arrastraba lentamente."

# game/scriptday2.rpy:530
translate Paloslios scriptday2_b7df7933:

    # e "Not much but yeah."
    e "No mucho pero sí."

# game/scriptday2.rpy:532
translate Paloslios scriptday2_697560c8:

    # "Stu perked right up, happy to be included in the conversation. He sighed in relief."
    "Stu se fue, feliz de ser incluido en la conversación. Suspiró aliviado."

# game/scriptday2.rpy:533
translate Paloslios scriptday2_98247cca:

    # s "C-Cool! Maybe we could have like- A watch party. I was thinking we could have a show play in the background."
    s "C-Cool! Tal vez podríamos tener una fiesta de relojes. Estaba pensando que podríamos tener un espectáculo en el fondo."

# game/scriptday2.rpy:534
translate Paloslios scriptday2_42e4adb8:

    # s "Dubs are way better now so we wouldn't have to be laser focused on subtitles, it can sort of work as white noise without getting completely confused on the plot!"
    s "Los dubs son mucho mejores ahora, por lo que no tendríamos que estar centrados en los subtítulos, ¡puede funcionar como ruido blanco sin confundirnos por completo en la trama!"

# game/scriptday2.rpy:536
translate Paloslios scriptday2_fa7965e8:

    # "Erika let out a hum, almost like she wasn't even going to try to entertain the idea."
    "Erika dejó escapar un zumbido, casi como si ni siquiera iba a tratar de entretener la idea."

# game/scriptday2.rpy:537
translate Paloslios scriptday2_b8faccd4:

    # e "What kind of show were you thinking?"
    e "¿Qué tipo de programa estabas pensando?"

# game/scriptday2.rpy:538
translate Paloslios scriptday2_eece40b7:

    # "I was taken a bit by surprise. Was she actually considering it? I could see Stu darting his eyes to look towards me, as if he was crying out for help."
    "Me sorprendieron un poco. ¿Ella realmente lo estaba considerando? Pude ver a Stu lanzando sus ojos para mirar hacia mí, como si estuviera llorando por ayuda."

# game/scriptday2.rpy:540
translate Paloslios scriptday2_b04ec546:

    # s "I was thinking you two would like 'Crimson Face', it's a mecha anime with lots of action and humor!"
    s "Estaba pensando que a ustedes dos les gustaría 'Crimson Face', ¡es un anime mecha con mucha acción y humor!"

# game/scriptday2.rpy:541
translate Paloslios scriptday2_2e24734a:

    # "Another hum erupted from Erika."
    "Otro zumbido estalló de Erika."

# game/scriptday2.rpy:542
translate Paloslios scriptday2_aad182d8:

    # e "Mecha isn't really my cup of tea, I'm more into magical girls."
    e "Mecha no es realmente mi taza de té, me gustan más las chicas mágicas."

# game/scriptday2.rpy:543
translate Paloslios scriptday2_6c6ae2fe:

    # s "I'm sure we can find something that could work. What are you into [name]?"
    s "Estoy seguro de que podemos encontrar algo que pueda funcionar. ¿En qué te gusta [name]?"

# game/scriptday2.rpy:549
translate Paloslios scriptday2_88507f99:

    # s "Sweet! I got a few in mind! Just tell me what you're looking for and I can find the perfect one!"
    s "¡Dulce! ¡Tengo algunos en mente! ¡Solo dime lo que estás buscando y puedo encontrar el perfecto!"

# game/scriptday2.rpy:551
translate Paloslios scriptday2_8de1d99d:

    # e "Aren't they usually toy tie-ins?"
    e "¿No suelen ser los vínculos de juguete?"

# game/scriptday2.rpy:553
translate Paloslios scriptday2_b1d9e79a:

    # s "Don't a good chunk of magical girl shows have those too?"
    s "¿No tienen una buena parte de los espectáculos mágicos de chicas también?"

# game/scriptday2.rpy:555
translate Paloslios scriptday2_b9eb05dd:

    # e "Okay, you're not wrong there."
    e "Bien, no te equivocas allí."

# game/scriptday2.rpy:556
translate Paloslios scriptday2_de58d99f:

    # s "Even if they are, it doesn't mean it isn't good."
    s "Incluso si lo son, no significa que no sea bueno."

# game/scriptday2.rpy:560
translate Paloslios scriptday2_7e2d8f3d:

    # voice "audio/MDHM_Erika voicelines/Day 2/08_Good Taste.mp3"
    # e "Good to know you have good taste."
    voice "audio/mdhm_erika VoicElines/Day 2/08_Good taste.mp3"
    e "Es bueno saber que tienes buen gusto."

# game/scriptday2.rpy:563
translate Paloslios scriptday2_ea7fc253:

    # s "I'm pretty sure I can find something that fits. I think 'Dressed to Kill' could count as a magical girl anime."
    s "Estoy bastante seguro de que puedo encontrar algo que se ajuste. Creo que 'vestido para matar' podría contar como un anime mágico de niña."

# game/scriptday2.rpy:565
translate Paloslios scriptday2_a4e4eea8:

    # e "I mean, if you're getting technical."
    e "Quiero decir, si te estás volviendo técnico."

# game/scriptday2.rpy:567
translate Paloslios scriptday2_cb02bf40:

    # s "Wait, you've seen it?!"
    s "Espera, ¿lo has visto?"

# game/scriptday2.rpy:569
translate Paloslios scriptday2_dae81f6c:

    # e "Seen enough."
    e "Visto lo suficiente."

# game/scriptday2.rpy:575
translate Paloslios scriptday2_d7358b28:

    # s "Huh, I didn't even think of that."
    s "Huh, ni siquiera pensé en eso."

# game/scriptday2.rpy:577
translate Paloslios scriptday2_57abac9a:

    # e "I guess it could work pretty well for white noise."
    e "Supongo que podría funcionar bastante bien para el ruido blanco."

# game/scriptday2.rpy:579
translate Paloslios scriptday2_009a6e1a:

    # s "Most of them are pretty chill and have low stakes."
    s "La mayoría de ellos son bastante frío y tienen apuestas bajas."

# game/scriptday2.rpy:583
translate Paloslios scriptday2_0c3a9aff:

    # s "Um... I'm not sure about that, [name]."
    s "Um ... no estoy seguro de eso, [name]."

# game/scriptday2.rpy:584
translate Paloslios scriptday2_91fc0721:

    # "Stu leaned in close to me and lowered his voice."
    "Stu se inclinó cerca de mí y bajó la voz."

# game/scriptday2.rpy:586
translate Paloslios scriptday2_103c5a6f:

    # voice "audio/MDHM_Stu voicelines/Day 2/05_ Not good with horror.mp3"
    # s "Ya know how I am with... Horror..."
    voice "audio/mdhm_stu VoicElines/Day 2/05_ No es bueno con Horror.mp3"
    s "Ya sabes cómo estoy ... horror ..."

# game/scriptday2.rpy:588
translate Paloslios scriptday2_a8d27578:

    # "I look over to Erika for her response. She simply shrugged."
    "Miro a Erika por su respuesta. Ella simplemente se encogió de hombros."

# game/scriptday2.rpy:589
translate Paloslios scriptday2_61217c9d:

    # e "I don't mind it, but it's gonna be more of a distraction than anything."
    e "No me importa, pero será más una distracción que cualquier otra cosa."

# game/scriptday2.rpy:590
translate Paloslios scriptday2_9ccefa0c:

    # "Stu let out a chill in response, his body squirming at the idea."
    "Stu dejó escapar un escalofrío en respuesta, su cuerpo se retorció ante la idea."

# game/scriptday2.rpy:594
translate Paloslios scriptday2_e4619151:

    # voice "audio/MDHM_Erika voicelines/Day 2/09_Body Pillow.mp3"
    # e "Hopefully we don't take too much time from your body pillow girlfriend."
    voice "audio/mdhm_erika VoicElines/Day 2/09_Body Pillow.mp3"
    e "Ojalá no tomemos demasiado tiempo de la novia de la almohada de tu cuerpo."

# game/scriptday2.rpy:596
translate Paloslios scriptday2_ebc4cabf:

    # "That got a snort out of me. Erika didn't have to read him to filth like that but it was funny. You have no idea Erika..."
    "Eso me sacó un resoplido. Erika no tuvo que leerlo a la suciedad así, pero fue divertido. No tienes idea de Erika ..."

# game/scriptday2.rpy:598
translate Paloslios scriptday2_d5598bce:

    # s "H-Huh?!"
    s "¿H-huh?"

# game/scriptday2.rpy:600
translate Paloslios scriptday2_5c9b41ce:

    # e "I'm joking. Again."
    e "Estoy bromeando. De nuevo."

# game/scriptday2.rpy:601
translate Paloslios scriptday2_50d08498:

    # "She let out a proud, almost smug smile, leaving Stu dumbfounded."
    "Ella dejó escapar una sonrisa orgullosa, casi petulante, dejando a Stu atónito."

# game/scriptday2.rpy:603
translate Paloslios scriptday2_09e76d2c:

    # voice "audio/MDHM_Stu voicelines/Day 2/06_Man following.mp3"
    # s "Haha, I figured you were. I thought you even had someone following us just to mess with me more."
    voice "audio/mdhm_stu VoicElines/Day 2/06_man siguientes.mp3"
    s "Jaja, pensé que eras. Pensé que incluso tenías a alguien siguiéndonos solo para meterse más conmigo."

# game/scriptday2.rpy:605
translate Paloslios scriptday2_a20cefa7_4:

    # "..."
    "..."

# game/scriptday2.rpy:606
translate Paloslios scriptday2_ef2f1671:

    # u "What?"
    u "¿Qué?"

# game/scriptday2.rpy:608
translate Paloslios scriptday2_11d242c5:

    # voice "audio/MDHM_Erika voicelines/Day 2/09_Pardon.mp3"
    # e "I beg your pardon?"
    voice "audio/mdhm_erika VoicElines/Day 2/09_Pardon.mp3"
    e "¿Disculpe?"

# game/scriptday2.rpy:611
translate Paloslios scriptday2_e18b47a2:

    # "I could see Stu's soul leaving his body."
    "Pude ver el alma de Stu dejando su cuerpo."

# game/scriptday2.rpy:612
translate Paloslios scriptday2_2993b93e:

    # s "Haha... Come on, guys. You totally got someone to follow us around... Right?"
    s "Jaja ... vamos, chicos. Tienes totalmente a alguien a quien seguirnos ... ¿verdad?"

# game/scriptday2.rpy:613
translate Paloslios scriptday2_099d68a0:

    # "I look over to Erika, only to be met with the same confused expression I have."
    "Miro a Erika, solo para encontrarme con la misma expresión confundida que tengo."

# game/scriptday2.rpy:615
translate Paloslios scriptday2_97c7bfdd:

    # s "Th-They were staring at us at those bushes over there!"
    s "¡Nos estaban mirando a esos arbustos allí!"

# game/scriptday2.rpy:616
translate Paloslios scriptday2_f3396c80:

    # "Stu pointed over his shoulder, but nothing was there."
    "Stu señaló su hombro, pero no había nada allí."

# game/scriptday2.rpy:617
translate Paloslios scriptday2_2121beca:

    # "Nothing but an uncomfortable silence between us, luckily, Erika stepped in to kill off the awkward tension."
    "Nada más que un silencio incómodo entre nosotros, por suerte, Erika intervino para matar la incómoda tensión."

# game/scriptday2.rpy:619
translate Paloslios scriptday2_ac182b5a:

    # e "Okay then."
    e "Bien entonces."

# game/scriptday2.rpy:620
translate Paloslios scriptday2_85af2ebe:

    # "Erika closed the textbook she was currently reading."
    "Erika cerró el libro de texto que estaba leyendo actualmente."

# game/scriptday2.rpy:622
translate Paloslios scriptday2_fbf5a416:

    # e "I think we should call it off from here. I need to get back home, anyways."
    e "Creo que deberíamos cancelarlo desde aquí. Necesito volver a casa, de todos modos."

# game/scriptday2.rpy:623
translate Paloslios scriptday2_fa925644:

    # "I blinked, a little taken aback by Erika's abrupt leave."
    "Parpadeé, un poco desconcertado por la abrupta clase de Erika."

# game/scriptday2.rpy:624
translate Paloslios scriptday2_439c2e36:

    # voice "audio/MDHM_Stu voicelines/Day 2/07_Not Crazy.mp3"
    # s "I swear! I'm not crazy!"
    voice "audio/mdhm_stu VoicElines/Day 2/07_Not Crazy.mp3"
    s "¡Lo juro! ¡No estoy loco!"

# game/scriptday2.rpy:626
translate Paloslios scriptday2_23623e0c:

    # "Stu frantically waved his arms, a pathetic attempt to convince Erika to believe him."
    "Stu agitó frenéticamente sus brazos, un patético intento de convencer a Erika para que le creyera."

# game/scriptday2.rpy:627
translate Paloslios scriptday2_81ebf9f7:

    # voice "audio/MDHM_Erika voicelines/Day 2/10_Don_t Worry.mp3"
    # e "Don't worry. It is not entirely your fault."
    voice "audio/mdhm_erika VoicElines/Day 2/10_don_t Willing.mp3"
    e "No te preocupes. No es completamente tu culpa."

# game/scriptday2.rpy:629
translate Paloslios scriptday2_d82632e4:

    # s "... 'Entirely'?"
    s "... 'completamente'?"

# game/scriptday2.rpy:631
translate Paloslios scriptday2_8a238b07:

    # e "I can't concentrate like this. We could try to plan out another day to study. Hopefully with no other interruptions."
    e "No puedo concentrarme así. Podríamos tratar de planificar otro día para estudiar. Ojalá sin otras interrupciones."

# game/scriptday2.rpy:632
translate Paloslios scriptday2_20b187e4:

    # "There was a beat of silence as Erika gave Stu a side eye."
    "Hubo un ritmo de silencio cuando Erika le dio a Stu un ojo lateral."

# game/scriptday2.rpy:634
translate Paloslios scriptday2_55c289cb:

    # "Without a moment to lose, Erika packed everything, but let us keep the snacks she brought."
    "Sin un momento que perder, Erika empacó todo, pero mantengamos los bocadillos que trajo."

# game/scriptday2.rpy:635
translate Paloslios scriptday2_500a7a76:

    # e "See ya, around [name]."
    e "Nos vemos, alrededor de [name]."

# game/scriptday2.rpy:637
translate Paloslios scriptday2_6664f05d:

    # "I gave her an awkward wave, which she returned but then she eyed Stu."
    "Le di una ola incómoda, que regresó, pero luego miró a Stu."

# game/scriptday2.rpy:638
translate Paloslios scriptday2_1b94dded:

    # "There was a beat of silence. I couldn't tell what she was thinking."
    "Hubo un ritmo de silencio. No podía decir lo que estaba pensando."

# game/scriptday2.rpy:639
translate Paloslios scriptday2_71eb5a8b:

    # e "It was nice knowing you, Stu."
    e "Fue agradable conocerte, Stu."

# game/scriptday2.rpy:640
translate Paloslios scriptday2_5d07545a:

    # "She didn't sound peachy, but not angry either. Just her usual tone. That had to be a good sign, right?"
    "Ella no sonó durazno, pero tampoco enojada. Solo su tono habitual. Ese tenía que ser una buena señal, ¿verdad?"

# game/scriptday2.rpy:645
translate Paloslios scriptday2_ed74408c:

    # "Just like that, she left. Once she was out of sight, I slowly turned to Stu. I gave him a look."
    "Solo así, ella se fue. Una vez que estaba fuera de la vista, lentamente me volví hacia Stu. Le di un vistazo."

# game/scriptday2.rpy:647
translate Paloslios scriptday2_461befa1:

    # s "Haha..."
    s "Ja ja..."

# game/scriptday2.rpy:648
translate Paloslios scriptday2_a6a2eabe:

    # "I'm not sure whether to be upset or be left dumbfounded like he was. I groaned. This could've gone better..."
    "No estoy seguro de si estar molesto o quedar atónito como él. Gimí. Esto podría haber ido mejor ..."

# game/scriptday2.rpy:649
translate Paloslios scriptday2_c054243f:

    # s "[name]? Hey, I'm sor-"
    s "[name]? Oye, soy sor-"

# game/scriptday2.rpy:650
translate Paloslios scriptday2_c96ca176:

    # u "It's fine, Stu."
    u "Está bien, Stu."

# game/scriptday2.rpy:651
translate Paloslios scriptday2_bde0fa0c:

    # "I said, you know, like a liar. Waving him off."
    "Dije, ya sabes, como un mentiroso. Avanzándolo."

# game/scriptday2.rpy:653
translate Paloslios scriptday2_db554b75:

    # s "If I interrupted something you could've-"
    s "Si interrumpiera algo, podrías haber"

# game/scriptday2.rpy:654
translate Paloslios scriptday2_c40855fd:

    # u "It's okay."
    u "Está bien."

# game/scriptday2.rpy:655
translate Paloslios scriptday2_3225a14c:

    # "Stu quieted down, noticing my disappointed tone. Was I being a little harsh on him? I guess I can't really blame him for wanting to hang out but things change."
    "Stu se calmó, notando mi tono decepcionado. ¿Estaba siendo un poco duro con él? Supongo que realmente no puedo culparlo por querer pasar el rato, pero las cosas cambian."

# game/scriptday2.rpy:656
translate Paloslios scriptday2_2d7a371d:

    # "Or at least I'm trying to change things."
    "O al menos estoy tratando de cambiar las cosas."

# game/scriptday2.rpy:661
translate Paloslios scriptday2_28779f46:

    # "We both sat in an uncomfortable silence until we both bid farewell to each other. During the whole walk to my dorm, I kept my eyes glued to the ground, feeling like garbage."
    "Ambos nos sentamos en un silencio incómodo hasta que ambos nos despedimos el uno del otro. Durante todo el paseo hasta mi dormitorio, mantuve mis ojos pegados al suelo, sintiéndome como basura."

# game/scriptday2.rpy:662
translate Paloslios scriptday2_c0454dd9:

    # "Maybe I was a little harsh to Stu, but he should've known not to change my plans with Erika. I'm trying to make friends and get a new life. Or as much as could."
    "Tal vez era un poco duro para Stu, pero debería haber sabido que no cambiaría mis planes con Erika. Estoy tratando de hacer amigos y obtener una nueva vida. O tanto como pudiera."

# game/scriptday2.rpy:669
translate Paloslios scriptday2_5f042704:

    # "I did miss him an awful lot. Seeing him felt like old times."
    "Lo extrañé mucho. Verlo se sentía como los viejos tiempos."

# game/scriptday2.rpy:670
translate Paloslios scriptday2_97538f8a:

    # "And it made me feel some type of way. Good times, bad times. All in a confusing, mixed bag of emotions. I wanted to try and move on from the past, but I can't help but clinging on because it was familiar."
    "Y me hizo sentir algún tipo de camino. Buenos tiempos, malos momentos. Todo en una bolsa confusa y mixta de emociones. Quería tratar de pasar del pasado, pero no puedo evitar aferrarse porque era familiar."

# game/scriptday2.rpy:671
translate Paloslios scriptday2_195db329:

    # a "Doe-eyes!"
    a "¡Doe-Eyes!"

# game/scriptday2.rpy:672
translate Paloslios scriptday2_5335e3e8:

    # "I snapped out of my trance, hearing someone call out. It was Alan."
    "Salí de mi trance, escuchando a alguien llamar. Era Alan."

# game/scriptday2.rpy:677
translate Paloslios scriptday2_b6694596:

    # "He was sitting on my porch, holding his chin in his hands. He had a wide smile, happy to see me."
    "Estaba sentado en mi porche, sosteniendo su barbilla en sus manos. Tenía una amplia sonrisa, feliz de verme."

# game/scriptday2.rpy:678
translate Paloslios scriptday2_5ce1fb8a:

    # "Not gonna lie, seeing him made me feel better."
    "No voy a mentir, verlo me hizo sentir mejor."

# game/scriptday2.rpy:679
translate Paloslios scriptday2_00ce738d:

    # u "Alan! What are you doing here?"
    u "¡Alan! ¿Qué estás haciendo aquí?"

# game/scriptday2.rpy:680
translate Paloslios scriptday2_43988005:

    # a "Waitin' for ya!"
    a "¡Te espera!"

# game/scriptday2.rpy:681
translate Paloslios scriptday2_9b7a9c53:

    # "I tilted my head, cocking an eyebrow at him."
    "Incliné mi cabeza, arrojando una ceja hacia él."

# game/scriptday2.rpy:682
translate Paloslios scriptday2_5c798c18:

    # u "How long have you been sitting here?"
    u "¿Cuánto tiempo llevas sentado aquí?"

# game/scriptday2.rpy:684
translate Paloslios scriptday2_e0046e58:

    # "Alan finally stood up, placing his hands behind his back and flashed a bright smile."
    "Alan finalmente se puso de pie, colocando sus manos detrás de su espalda y mostró una sonrisa brillante."

# game/scriptday2.rpy:685
translate Paloslios scriptday2_63ce84b2:

    # a "Not long."
    a "No mucho."

# game/scriptday2.rpy:686
translate Paloslios scriptday2_a20cefa7_5:

    # "..."
    "..."

# game/scriptday2.rpy:688
translate Paloslios scriptday2_3813e24b:

    # voice "audio/MDHM_Alan voicelines/Day 2/10_I missed ya.mp3"
    # a "I missed ya."
    voice "audio/mdhm_alan VoicElines/Day 2/10_i perdió ya.mp3"
    a "Te extrañé."

# game/scriptday2.rpy:690
translate Paloslios scriptday2_7fea44a5:

    # "I rolled my eyes, scoffing as I reached over to the doorknob, passing by him. Did Alan seriously wait all day for me to get back home? It was weird to say the least."
    "Puse los ojos en blanco, burlándose mientras me acercaba al pomo de la puerta, pasando por él. ¿Alan esperó seriamente todo el día para que volviera a casa? Era extraño decir lo menos."

# game/scriptday2.rpy:691
translate Paloslios scriptday2_9c977611:

    # "Although, picturing Alan sitting here all by himself was an amusing scenario. Hopefully none of the other students got freaked out by him."
    "Aunque, imaginar a Alan sentado aquí solo era un escenario divertido. Esperemos que ninguno de los otros estudiantes se asustara por él."

# game/scriptday2.rpy:692
translate Paloslios scriptday2_7f4b5cac:

    # u "Alan, we saw each other this morning."
    u "Alan, nos vimos esta mañana."

# game/scriptday2.rpy:693
translate Paloslios scriptday2_0e7499de:

    # a "That doesn't change anything! I was looking forward to hanging out with ya and all."
    a "¡Eso no cambia nada! Tenía muchas ganas de pasar el rato contigo y todo."

# game/scriptday2.rpy:694
translate Paloslios scriptday2_7c673b1a:

    # "I managed to open the door, not wanting to throw him out like a stray dog, I decided to let him crash for the night."
    "Me las arreglé para abrir la puerta, sin querer tirarlo como un perro callejero, decidí dejarlo chocar por la noche."

# game/scriptday2.rpy:695
translate Paloslios scriptday2_7700758b:

    # u "Awww you poor baby."
    u "Awww, pobre bebé."

# game/scriptday2.rpy:696
translate Paloslios scriptday2_679cf38d:

    # "I said sarcastically."
    "Dije sarcásticamente."

# game/scriptday2.rpy:702
translate Paloslios scriptday2_b4c17032:

    # "Alan was right behind me, he awkwardly stood at the doorstep, and he seemed hesitant to enter."
    "Alan estaba justo detrás de mí, se paró torpemente en la puerta, y parecía dudar de entrar."

# game/scriptday2.rpy:703
translate Paloslios scriptday2_f7ad71de:

    # u "Don't be shy, come in."
    u "No seas tímido, entra."

# game/scriptday2.rpy:705
translate Paloslios scriptday2_ff096e98:

    # "I beckoned him to take the first step. It was like trying to let in a cautious, stray animal, lost and confused. Alan finally stepped in, the creaky floorboards of the house releasing a soft groan under him."
    "Lo llamé para dar el primer paso. Era como tratar de dejar entrar a un animal cauteloso y callejero, perdido y confundido. Alan finalmente entró, las tablas de piso crujientes de la casa liberaron un gemido suave debajo de él."

# game/scriptday2.rpy:706
translate Paloslios scriptday2_6a679f2a:

    # u "Yeah... This place is older than the town itself but hey. It's home for now."
    u "Sí ... este lugar es más antiguo que la ciudad en sí, pero bueno. Está en casa por ahora."

# game/scriptday2.rpy:708
translate Paloslios scriptday2_debf979b:

    # a "You work with what you can get."
    a "Trabajas con lo que puedes obtener."

# game/scriptday2.rpy:709
translate Paloslios scriptday2_ef66f4bd:

    # "I shrugged, but overall I agreed with his sentiment."
    "Me encogí de hombros, pero en general estuve de acuerdo con su sentimiento."

# game/scriptday2.rpy:710
translate Paloslios scriptday2_111dc95e:

    # "I turned on the TV, letting its soft glow illuminate the entire living room. While I do have lights, I much rather be sitting in some darkness after a long day."
    "Encendí la televisión, dejando que su brillo suave ilumine toda la sala de estar. Si bien tengo luces, prefiero estar sentado en un poco de oscuridad después de un largo día."

# game/scriptday2.rpy:712
translate Paloslios scriptday2_00c0feaf:

    # "I look back to Alan, seeing that he was inspecting my home. He looked down at the floorboards, pressing the tip of his shoe to emit a harsh creak. It was as if he was trying to find something to do."
    "Miro hacia atrás a Alan, viendo que estaba inspeccionando mi casa. Miró hacia las tablas del piso, presionando la punta de su zapato para emitir un crujido duro. Era como si estuviera tratando de encontrar algo que hacer."

# game/scriptday2.rpy:713
translate Paloslios scriptday2_88a80eae:

    # u "You can make yourself at home. Don't just stand there um..."
    u "Puedes hacerte en casa. No solo te quedes allí um ..."

# game/scriptday2.rpy:714
translate Paloslios scriptday2_d5f0ee3e:

    # "I nervously motioned to the TV area."
    "Hice un gesto nervioso al área de TV."

# game/scriptday2.rpy:715
translate Paloslios scriptday2_aad1e739:

    # u "You can go ahead and sit on the couch."
    u "Puedes seguir adelante y sentarte en el sofá."

# game/scriptday2.rpy:717
translate Paloslios scriptday2_308e424c:

    # "Alan let out a surprised noise, staying in his usual place but did what was told. He smiled nervously at me as my eyes followed him, and he sat on the edge of the couch. He looked like an awkward little kid."
    "Alan dejó escapar un ruido sorprendido, permaneciendo en su lugar habitual, pero hizo lo que se le dijo. Él me sonrió nerviosamente mientras mis ojos lo seguían, y él se sentó al borde del sofá. Parecía un niño incómodo."

# game/scriptday2.rpy:720
translate Paloslios scriptday2_d34ba581:

    # u "Are ya interested in coming with me to the store? I gotta get some food so I can stock up my fridge."
    u "¿Estás interesado en venir conmigo a la tienda? Tengo que conseguir algo de comida para poder abastecerme de mi refrigerador."

# game/scriptday2.rpy:721
translate Paloslios scriptday2_a20cefa7_6:

    # "..."
    "..."

# game/scriptday2.rpy:723
translate Paloslios scriptday2_40ef4cf6:

    # a "Are we gonna steal stuff?"
    a "¿Vamos a robar cosas?"

# game/scriptday2.rpy:724
translate Paloslios scriptday2_73a5a637:

    # "His face grew sinister. I'm gonna guess he got excited about stealing again."
    "Su rostro se volvió siniestro. Voy a suponer que se emocionó por robar de nuevo."

# game/scriptday2.rpy:725
translate Paloslios scriptday2_131512cf:

    # u "Cool it, Alan. You might've swindled them by stealing candy bars but I highly doubt we're gonna get away scot-free with actual piles of food."
    u "Enfríe, Alan. Es posible que los haya estafado robando barras de caramelo, pero dudo mucho que vamos a escapar sin escocés con pilas de comida reales."

# game/scriptday2.rpy:726
translate Paloslios scriptday2_10194b22:

    # a "You don't know that."
    a "No lo sabes."

# game/scriptday2.rpy:727
translate Paloslios scriptday2_ad9cbd59:

    # u "We're not gonna rob the store, Alan."
    u "No vamos a robar la tienda, Alan."

# game/scriptday2.rpy:729
translate Paloslios scriptday2_f8656eb7:

    # voice "audio/MDHM_Alan voicelines/Day 2/03_Booooo.mp3"
    # a "Boo..."
    voice "audio/mdhm_alan VoicElines/Day 2/03_booooo.mp3"
    a "Abucheo..."

# game/scriptday2.rpy:731
translate Paloslios scriptday2_0580c119:

    # "Alan poked out his tongue at me, playfully of course."
    "Alan me sacó la lengua, juguetonamente, por supuesto."

# game/scriptday2.rpy:733
translate Paloslios scriptday2_11cdd1eb:

    # "I began to walk away, leaving him in the dust. His freakishly long legs only took two or three steps to catch up to me."
    "Comencé a alejarme, dejándolo en el polvo. Sus piernas extrañamente largas solo tomaron dos o tres pasos para alcanzarme."

# game/scriptday2.rpy:740
translate Paloslios scriptday2_d1bb6837:

    # "We both walked to the convenience store. It was nothing more than just a casual hangout between us. As we entered through the doors there was another employee, eyeing us suspiciously the entire time."
    "Ambos caminamos hacia la tienda de conveniencia. No era más que un lugar informal entre nosotros. Cuando entramos por las puertas había otro empleado, mirándonos sospechosamente todo el tiempo."

# game/scriptday2.rpy:741
translate Paloslios scriptday2_83c4b2d2:

    # "I wasn't sure what their deal was, I wonder if they know about Alan's shenanigans."
    "No estaba seguro de cuál era su trato, me pregunto si saben sobre las travesuras de Alan."

# game/scriptday2.rpy:742
translate Paloslios scriptday2_3340633d:

    # "They were mostly keeping an eye at him, glaring him down as Alan was invested in the rotating hot dog grill. They left us alone once I paid for my food."
    "En su mayoría lo vigilaban, mirándolo mientras Alan estaba invertido en la rotación de la parrilla de hot dog. Nos dejaron solos una vez que pagué por mi comida."

# game/scriptday2.rpy:749
translate Paloslios scriptday2_a24d14d7:

    # "We got to my place, bags in hand. Quite the walk but nothing we couldn't handle. Doomsbury was ideal to walk around and go to places that were easily accessible."
    "Llegamos a mi casa, bolsas en la mano. Bastante caminata pero nada que no pudiéramos manejar. Doomsbury era ideal para caminar e ir a lugares que eran fácilmente accesibles."

# game/scriptday2.rpy:750
translate Paloslios scriptday2_be86d61b:

    # "They say Fall was the best time of year in this little town. I can already see some bright yellow and orange leaves cascading down from the trees before resting on the ground."
    "Dicen que el otoño fue la mejor época del año en esta pequeña ciudad. Ya puedo ver algunas hojas de color amarillo y naranja brillantes en cascada de los árboles antes de descansar en el suelo."

# game/scriptday2.rpy:751
translate Paloslios scriptday2_528d534d:

    # "It was pleasant to see the seasons change right before your eyes as time swiftly went by."
    "Fue agradable ver que las estaciones cambiaran justo antes de sus ojos a medida que pasaba el tiempo rápidamente."

# game/scriptday2.rpy:752
translate Paloslios scriptday2_b0525ee0:

    # "Alan was right behind me, he awkwardly stood at the doorstep, his lips were pulled into a thin line as he seemed hesitant to enter."
    "Alan estaba justo detrás de mí, se paró torpemente en la puerta, sus labios fueron arrastrados en una delgada línea cuando parecía dudar de entrar."

# game/scriptday2.rpy:753
translate Paloslios scriptday2_f7ad71de_1:

    # u "Don't be shy, come in."
    u "No seas tímido, entra."

# game/scriptday2.rpy:755
translate Paloslios scriptday2_ff096e98_1:

    # "I beckoned him to take the first step. It was like trying to let in a cautious, stray animal, lost and confused. Alan finally stepped in, the creaky floorboards of the house releasing a soft groan under him."
    "Lo llamé para dar el primer paso. Era como tratar de dejar entrar a un animal cauteloso y callejero, perdido y confundido. Alan finalmente entró, las tablas de piso crujientes de la casa liberaron un gemido suave debajo de él."

# game/scriptday2.rpy:757
translate Paloslios scriptday2_80dcfef2:

    # "Alan seemed to settle himself in immediately. Heading to the kitchen first before I could even tell him where it was."
    "Alan parecía establecerse de inmediato. Primero se dirige a la cocina antes de que pudiera decirle dónde estaba."

# game/scriptday2.rpy:758
translate Paloslios scriptday2_53a1925c:

    # "... I guess he was as hungry as I was."
    "... Supongo que tenía tan hambre como yo."

# game/scriptday2.rpy:759
translate Paloslios scriptday2_6a679f2a_1:

    # u "Yeah... This place is older than the town itself but hey. It's home for now."
    u "Sí ... este lugar es más antiguo que la ciudad en sí, pero bueno. Está en casa por ahora."

# game/scriptday2.rpy:760
translate Paloslios scriptday2_e880ea65:

    # a "I don't mind. Ya work with what you got."
    a "No me importa. Trabajas con lo que tienes."

# game/scriptday2.rpy:767
translate Paloslios scriptday2_555bd28b:

    # "I dropped the bags of food on the counter and Alan followed suit. I rummaged through, taking out the key ingredients to make breakfast."
    "Dejé caer las bolsas de comida en el mostrador y Alan hizo lo mismo. Hojeé pasar, sacando los ingredientes clave para preparar el desayuno."

# game/scriptday2.rpy:768
translate Paloslios scriptday2_41049581:

    # "Or brunch by technicality now."
    "O brunch por tecnicismo ahora."

# game/scriptday2.rpy:769
translate Paloslios scriptday2_99b8e0f4:

    # "I was surprised how much food I was taking out of the bags. I didn't realize my eyes are bigger than my stomach."
    "Me sorprendió cuánta comida estaba sacando de las bolsas. No me di cuenta de que mis ojos son más grandes que mi estómago."

# game/scriptday2.rpy:770
translate Paloslios scriptday2_99de5183:

    # "Shopping hungry isn't really the best idea first thing in the morning, Especially when you haven't eaten in a while."
    "Comprar hambriento no es realmente la mejor idea a primera hora de la mañana, especialmente cuando no has comido en mucho tiempo."

# game/scriptday2.rpy:772
translate Paloslios scriptday2_42b896f8:

    # "So..."
    "Entonces..."

# game/scriptday2.rpy:773
translate Paloslios scriptday2_05c59ba9:

    # a "What are ya in the mood for?"
    a "¿Para qué estás de humor?"

# game/scriptday2.rpy:778
translate Paloslios scriptday2_03152cbd:

    # u "I'm in the mood for pancakes. You cool with that?"
    u "Estoy de humor para los panqueques. ¿Te refreses con eso?"

# game/scriptday2.rpy:780
translate Paloslios scriptday2_220f17bb:

    # "Alan smiled, seemingly happy with what I picked."
    "Alan sonrió, aparentemente feliz con lo que elegí."

# game/scriptday2.rpy:781
translate Paloslios scriptday2_6e74d29b:

    # a "I could go for some pancakes."
    a "Podría ir por algunos panqueques."

# game/scriptday2.rpy:782
translate Paloslios scriptday2_7d4fcc94:

    # u "Anything specific you want to add? I don't think I have much on toppings but..."
    u "¿Algo específico que quiera agregar? No creo que tenga mucho en los ingredientes pero ..."

# game/scriptday2.rpy:783
translate Paloslios scriptday2_37cfc007:

    # "Before I could finish my sentence, I pulled out a small, plastic box."
    "Antes de que pudiera terminar mi oración, saqué una pequeña caja de plástico."

# game/scriptday2.rpy:784
translate Paloslios scriptday2_8e4456c2:

    # u "Blueberries? I don't remember getting these."
    u "Arándanos? No recuerdo haberlo recibido."

# game/scriptday2.rpy:786
translate Paloslios scriptday2_83d24bb7:

    # "I look back to Alan, who, in return, gave me a cheeky look. There is nothing else to say on the matter."
    "Miro hacia atrás a Alan, quien, a cambio, me dio una mirada descarada. No hay nada más que decir al respecto."

# game/scriptday2.rpy:789
translate Paloslios scriptday2_243cf676:

    # u "I'm in the mood for a breakfast burrito. They are really easy to make and I'm so used to them."
    u "Estoy de humor para un burrito de desayuno. Son realmente fáciles de hacer y estoy tan acostumbrado a ellos."

# game/scriptday2.rpy:791
translate Paloslios scriptday2_324a6fd6:

    # a "Well, that's not surprising. I think it's one of those staple foods every college kid gets, I assume."
    a "Bueno, eso no es sorprendente. Creo que es uno de esos alimentos básicos que recibe cada niño universitario, supongo."

# game/scriptday2.rpy:792
translate Paloslios scriptday2_50997633:

    # u "Anything specific you want to add? I'm not one to brag but I get real 'fancy' with my burritos. You could say I mastered my craft."
    u "¿Algo específico que quiera agregar? No soy uno para presumir, pero me pongo realmente 'elegante' con mis burritos. Se podría decir que dominé mi oficio."

# game/scriptday2.rpy:794
translate Paloslios scriptday2_a06baf06:

    # a "Fancy?"
    a "¿Elegante?"

# game/scriptday2.rpy:795
translate Paloslios scriptday2_7f4c913a:

    # "Alan cocked an eyebrow at me, curious about what I meant. I flashed him a smile, rushing to the fridge and pulling out some ingredients to make the perfect breakfast burrito."
    "Alan me arrojó una ceja, curiosidad por lo que quise decir. Le mostré una sonrisa, corrí hacia el refrigerador y sacando algunos ingredientes para hacer el burrito de desayuno perfecto."

# game/scriptday2.rpy:796
translate Paloslios scriptday2_b7a56eb5:

    # a "What's all this?"
    a "¿Qué es todo esto?"

# game/scriptday2.rpy:797
translate Paloslios scriptday2_6a60dd6d:

    # u "Prepare to have the best breakfast that my tiny little hands can conjure up!"
    u "¡Prepárese para tomar el mejor desayuno para que mis pequeñas manos puedan conjurar!"

# game/scriptday2.rpy:801
translate Paloslios scriptday2_109c445e:

    # u "Eggs in a basket?"
    u "¿Huevos de canasta?"

# game/scriptday2.rpy:802
translate Paloslios scriptday2_1b3e4f77:

    # a "Sounds good to me!"
    a "¡Me suena bien!"

# game/scriptday2.rpy:804
translate Paloslios scriptday2_f2f29e29:

    # "My feet took me to the fridge, prying open the door, still struggling with the stubborn handle. I managed to do it, thankfully."
    "Mis pies me llevaron a la nevera, abre la puerta, aún luchando con el obstinado mango. Logré hacerlo, afortunadamente."

# game/scriptday2.rpy:805
translate Paloslios scriptday2_39185986:

    # "I turned my back to get anything else I needed for our breakfast. I could hear some shuffling from behind me followed by Alan positioning himself next to me."
    "Le di la espalda para conseguir cualquier otra cosa que necesitara para el desayuno. Podía escuchar algunos de detrás de mí seguido de Alan posicionándose a mi lado."

# game/scriptday2.rpy:807
translate Paloslios scriptday2_ca872dc6:

    # a "Lemme help ya there, Doe-eyes."
    a "Déjame ayudarte allí, Doe-Eyes."

# game/scriptday2.rpy:808
translate Paloslios scriptday2_7e24f91e:

    # "I jolted, startled by how close he was but nodded as he settled in."
    "Me sacudí, sorprendido por lo cerca que estaba pero asintió mientras se instalaba."

# game/scriptday2.rpy:809
translate Paloslios scriptday2_8e64ebac:

    # u "Ya know how to cook Alan?"
    u "¿Sabes cocinar Alan?"

# game/scriptday2.rpy:812
translate Paloslios scriptday2_6c56ed9c:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Yes.mp3"
    # a "Yeah, actually! I don't really eat or make much food at home, but breakfast was always my specialty."
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_yes.mp3"
    a "¡Sí, en realidad! Realmente no como ni hago mucha comida en casa, pero el desayuno siempre fue mi especialidad."

# game/scriptday2.rpy:816
translate Paloslios scriptday2_8c81ae9b:

    # "Alan turned up the heat from the stove and placed a pan on top. He extended his hand out and I proceeded to give him the ingredients for our pancakes. I could use this type of teamwork around."
    "Alan subió el fuego de la estufa y colocó una sartén en la parte superior. Extendió su mano y procedí a darle los ingredientes para nuestros panqueques. Podría usar este tipo de trabajo en equipo."

# game/scriptday2.rpy:818
translate Paloslios scriptday2_6116bda8:

    # "Alan turned up the heat from the stove and placed a pan on top. He extended his hand out and I proceeded to give him the ingredients for our burritos. I could use this type of teamwork around."
    "Alan subió el fuego de la estufa y colocó una sartén en la parte superior. Extendió su mano y procedí a darle los ingredientes para nuestros burritos. Podría usar este tipo de trabajo en equipo."

# game/scriptday2.rpy:820
translate Paloslios scriptday2_a987edd4:

    # "Alan turned up the heat from the stove and placed a pan on top. He extended his hand out and I proceeded to give him the ingredients for our eggs. I could use this type of teamwork around."
    "Alan subió el fuego de la estufa y colocó una sartén en la parte superior. Extendió su mano y procedí a darle los ingredientes para nuestros huevos. Podría usar este tipo de trabajo en equipo."

# game/scriptday2.rpy:824
translate Paloslios scriptday2_b6cb0d83:

    # u "Speciality, huh? Am I in a presence of the finest breakfast chefs in town?"
    u "Especialidad, ¿eh? ¿Estoy en presencia de los mejores chefs de desayuno de la ciudad?"

# game/scriptday2.rpy:827
translate Paloslios scriptday2_7504e568:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Laugh.mp3"
    # a "Well, I learned from one of the best types of teachers?"
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_laugh.mp3"
    a "Bueno, ¿aprendí de uno de los mejores tipos de maestros?"

# game/scriptday2.rpy:830
translate Paloslios scriptday2_06938334:

    # u "Oh? And who would that be?"
    u "¿Oh? ¿Y quién sería eso?"

# game/scriptday2.rpy:832
translate Paloslios scriptday2_a20cefa7_7:

    # "..."
    "..."

# game/scriptday2.rpy:833
translate Paloslios scriptday2_f8385c82:

    # a "I wouldn't want to bore you with that."
    a "No me gustaría aburrirte con eso."

# game/scriptday2.rpy:834
translate Paloslios scriptday2_45990071:

    # "I let out an offended noise, placing a hand to my chest in a dramatic fashion."
    "Dejé escapar un ruido ofendido, colocando una mano en mi pecho de manera dramática."

# game/scriptday2.rpy:835
translate Paloslios scriptday2_97a5b5ff:

    # u "You're not going to tell me? Come ooon! You can't just say that and not expect me to be intrigued."
    u "¿No me vas a decirme? ¡Ven ooon! No puedes decir eso y no esperar que me intriga."

# game/scriptday2.rpy:836
translate Paloslios scriptday2_a20cefa7_8:

    # "..."
    "..."

# game/scriptday2.rpy:837
translate Paloslios scriptday2_10dc958b:

    # "He's not gonna tell me."
    "No me va a decir."

# game/scriptday2.rpy:838
translate Paloslios scriptday2_4b2cf12a:

    # "That's something that I noticed. Alan seems to know a lot more about me than I do of him."
    "Eso es algo que noté. Alan parece saber mucho más sobre mí que yo."

# game/scriptday2.rpy:843
translate Paloslios scriptday2_b0ea5a5a:

    # u "Being mysterious all of the sudden?"
    u "Ser misterioso de repente?"

# game/scriptday2.rpy:844
translate Paloslios scriptday2_563e897f:

    # "I quipped, crossing my arms across my chest while Alan kept silent."
    "Bromeé, cruzando los brazos por mi pecho mientras Alan permanecía en silencio."

# game/scriptday2.rpy:849
translate Paloslios scriptday2_96c51a34:

    # "I caught wind of a frown on his face."
    "Me enteré del ceño fruncido en su rostro."

# game/scriptday2.rpy:850
translate Paloslios scriptday2_bb8e4b4e:

    # a "..."
    a "..."

# game/scriptday2.rpy:851
translate Paloslios scriptday2_b574e34c:

    # "It appeared I might've touched something sensitive that Alan doesn't want to talk about. Maybe I should lay off of him."
    "Parecía que podría haber tocado algo sensible de lo que Alan no quiere hablar. Tal vez debería despedirme de él."

# game/scriptday2.rpy:858
translate Paloslios scriptday2_8ebd9e6e:

    # "Alan kept an eye on the food as we continued with our conversation. The smell of the food fills the air and the sound of the hot pan sizzling was more than tantalizing."
    "Alan vigiló la comida mientras continuamos con nuestra conversación. El olor de la comida llena el aire y el sonido de la sartén caliente fue más que tentador."

# game/scriptday2.rpy:859
translate Paloslios scriptday2_02286ff7:

    # a "I guess you could say I'm a breakfast guy."
    a "Supongo que se podría decir que soy un tipo de desayuno."

# game/scriptday2.rpy:861
translate Paloslios scriptday2_3ca465e8:

    # "Alan says as he flips the eggs."
    "Alan dice mientras voltea los huevos."

# game/scriptday2.rpy:863
translate Paloslios scriptday2_bade108c:

    # "Alan says as he flips the pancake."
    "Alan dice mientras voltea el panqueque."

# game/scriptday2.rpy:864
translate Paloslios scriptday2_1f326aef:

    # u "Is that all you eat? Just breakfast and no other meal to fuel your day?"
    u "¿Eso es todo lo que comes? ¿Solo desayuno y ninguna otra comida para alimentar su día?"

# game/scriptday2.rpy:866
translate Paloslios scriptday2_0790ef5c:

    # a "You're making it sound bad."
    a "Estás haciendo que suene mal."

# game/scriptday2.rpy:867
translate Paloslios scriptday2_2949caf5:

    # u "You're the one being insane with your one meal."
    u "Eres el que está loco con tu única comida."

# game/scriptday2.rpy:869
translate Paloslios scriptday2_4ff300f4:

    # a "Look who's talking."
    a "Mira quién está hablando."

# game/scriptday2.rpy:871
translate Paloslios scriptday2_77f68e3e:

    # "Alan pointed the spatula at me, with a smug expression. He had a point there. He returned to pay attention to the sizzling eggs, inspecting it to see if it was cooked to perfection."
    "Alan me apuntó la espátula, con una expresión petulante. Tenía un punto allí. Regresó para prestar atención a los huevos chisporroteantes, inspeccionando para ver si estaba cocinado a la perfección."

# game/scriptday2.rpy:873
translate Paloslios scriptday2_36458dec:

    # "Alan pointed the spatula at me, with a smug expression. He had a point there. He returned to pay attention to the fluffy pancake, inspecting it to see if it was cooked to perfection."
    "Alan me apuntó la espátula, con una expresión petulante. Tenía un punto allí. Regresó para prestar atención al panqueque esponjoso, inspeccionando para ver si estaba cocinado a la perfección."

# game/scriptday2.rpy:875
translate Paloslios scriptday2_67eb1792:

    # "I ran around the kitchen floors, getting the only paper plates I had in the cupboards. I should add dishware to the shopping list too..."
    "Corrí por los pisos de la cocina, obteniendo las únicas placas de papel que tenía en los armarios. También debería agregar vajilla a la lista de compras ..."

# game/scriptday2.rpy:876
translate Paloslios scriptday2_758d920c:

    # a "It's not all I eat, when I have the time I do eat more meals, but I don't know..."
    a "No es todo lo que como, cuando tengo tiempo como comidas, pero no lo sé ..."

# game/scriptday2.rpy:877
translate Paloslios scriptday2_4b2e07a8:

    # "He trailed off. Alan's eyes now focused on the food from the pan. I tilted my head, awaiting what else he would say."
    "Se fue. Los ojos de Alan ahora se centraron en la comida de la sartén. Incliné mi cabeza, esperando qué más diría."

# game/scriptday2.rpy:879
translate Paloslios scriptday2_52469b62:

    # a "There is a ritual to it, yeah? I enjoy the process, it's a very... Special feeling for me. That and you could eat just about anything for breakfast."
    a "Hay un ritual, ¿sí? Disfruto del proceso, es una sensación muy ... especial para mí. Eso y podrías comer casi cualquier cosa para el desayuno."

# game/scriptday2.rpy:880
translate Paloslios scriptday2_ce12f9c2:

    # "Alan softly smiled at me and I gladly returned one back."
    "Alan me sonrió suavemente y con mucho gusto devolví uno."

# game/scriptday2.rpy:881
translate Paloslios scriptday2_7ab91550:

    # u "Okay, Alan Ramsay, enough of your sensitive monologue. I gotta assemble our food."
    u "De acuerdo, Alan Ramsay, suficiente de tu monólogo sensible. Tengo que reunir nuestra comida."

# game/scriptday2.rpy:882
translate Paloslios scriptday2_4bc598c3:

    # "I playfully shooed Alan away, motioning my hand to back him out of the position. Alan laughed, shifting himself just slightly to the right, and motioned me as if to say, 'All yours'."
    "Le dije juguetonamente a Alan, señalando mi mano para que lo respalde fuera de la posición. Alan se rió, cambiándose ligeramente hacia la derecha, y me indicó como si dijera 'todo tuyo'."

# game/scriptday2.rpy:883
translate Paloslios scriptday2_5395717a:

    # "Instinctively, I reached out to the handle of the pan. I was about to take it off the heat until I felt Alan's hand on top of mine, stopping me."
    "Instintivamente, contacté al mango de la sartén. Estaba a punto de quitarlo del calor hasta que sentí la mano de Alan encima de la mía, deteniéndome."

# game/scriptday2.rpy:885
translate Paloslios scriptday2_20226072:

    # voice "audio/MDHM_Alan voicelines/Day 2/05_I could get used to this.mp3"
    # a "I could get used to this."
    voice "audio/mdhm_alan VoicElines/Day 2/05_i podría acostumbrarse a esto.mp3"
    a "Podría acostumbrarme a esto."

# game/scriptday2.rpy:887
translate Paloslios scriptday2_94004a03_1:

    # "Oh."
    "Oh."

# game/scriptday2.rpy:888
translate Paloslios scriptday2_1fdfe0c9:

    # "He leaned in closer to me."
    "Se inclinó más cerca de mí."

# game/scriptday2.rpy:890
translate Paloslios scriptday2_d652c575:

    # a "Cooking together, of course."
    a "Cocinando juntos, por supuesto."

# game/scriptday2.rpy:891
translate Paloslios scriptday2_07fe5224:

    # u "Y-Yeah."
    u "Y-yeah."

# game/scriptday2.rpy:892
translate Paloslios scriptday2_5c396bba:

    # "What else could I even say? He had just caught me off guard and he was so casual over his flirting. Was that what this was? Was he hitting on me? I guess some stuff just flew over my head until now."
    "¿Qué más podría decir? Acababa de tomar por sorpresa y era tan informal por su coqueteo. ¿Fue eso lo que era esto? ¿Me estaba golpeando? Supongo que algunas cosas solo volaron sobre mi cabeza hasta ahora."

# game/scriptday2.rpy:893
translate Paloslios scriptday2_3acc910e:

    # u "Does cooking really make you this up close and personal?"
    u "¿La cocción realmente te hace esto de cerca y de cerca?"

# game/scriptday2.rpy:894
translate Paloslios scriptday2_d97ef8cf:

    # "I nervously laughed, trying to ease myself from this. I'm tempted to tug at my collar uncomfortably to let some cool air hit my warm skin."
    "Me reí nerviosamente, tratando de aliviarme de esto. Estoy tentado a tirar de mi collar incómodamente para dejar que un aire frío golpee mi piel cálida."

# game/scriptday2.rpy:895
translate Paloslios scriptday2_9e99d3f6:

    # a "Is that a bad thing?"
    a "¿Es eso algo malo?"

# game/scriptday2.rpy:896
translate Paloslios scriptday2_a5ce7611:

    # u "Umm..."
    u "Umm ..."

# game/scriptday2.rpy:897
translate Paloslios scriptday2_c5277b53:

    # "I didn't know how to answer that."
    "No sabía cómo responder eso."

# game/scriptday2.rpy:898
translate Paloslios scriptday2_4f26a780:

    # "I tried to avoid Alan's stare. His eyes were intense and engrossed in whatever caught his attention. Did I happen to catch it?"
    "Traté de evitar la mirada de Alan. Sus ojos eran intensos y absortos en lo que llamó su atención. ¿Lo atrapé?"

# game/scriptday2.rpy:899
translate Paloslios scriptday2_a20cefa7_9:

    # "..."
    "..."

# game/scriptday2.rpy:900
translate Paloslios scriptday2_c37d5f6c:

    # u "... Yeah, cooking with someone is nice. I'm not very used to it since- Ya know."
    u "... Sí, cocinar con alguien es bueno. No estoy muy acostumbrado, ya que sabes."

# game/scriptday2.rpy:901
translate Paloslios scriptday2_b292c6f4:

    # "I gestured my hand, signifying that I was pretty much alone in this college house. I could feel some weight mounting on me. Alan was getting closer, his chest pressing up to my back."
    "Hice un gesto de mi mano, significando que estaba prácticamente solo en esta casa de la universidad. Pude sentir algo de peso para mí. Alan se estaba acercando, su pecho presionando hacia mi espalda."

# game/scriptday2.rpy:902
translate Paloslios scriptday2_1f084e0c:

    # "I look down, attempting to think of something to say."
    "Miro hacia abajo, intentando pensar en algo que decir."

# game/scriptday2.rpy:907
translate Paloslios scriptday2_a005b8ac:

    # "Those words came out softer than I intended as I began to fix up our plates. I even made sure to give Alan a little more food."
    "Esas palabras salieron más suaves de lo que pretendía cuando comencé a arreglar nuestros platos. Incluso me aseguré de darle a Alan un poco más de comida."

# game/scriptday2.rpy:908
translate Paloslios scriptday2_c9f1526f:

    # u "I always looked forward to it the least. I wasn't allowed to skip the most important meal of the day and I had to sit at the table. The food was never quite right either..."
    u "Siempre lo esperaba menos. No se me permitía omitir la comida más importante del día y tuve que sentarme a la mesa. La comida nunca estuvo bien tampoco ..."

# game/scriptday2.rpy:910
translate Paloslios scriptday2_0c4ffc87:

    # "A beat of silence filled in for the two of us. I didn't want to bring down the mood at all. Even the action of cooking something as simple as eggs would give me such unpleasant memories."
    "Un ritmo de silencio completó para los dos. No quería reducir el estado de ánimo. Incluso la acción de cocinar algo tan simple como los huevos me daría recuerdos tan desagradables."

# game/scriptday2.rpy:912
translate Paloslios scriptday2_e4107c12:

    # "A beat of silence filled in for the two of us. I didn't want to bring down the mood at all. Even the action of cooking something as simple as pancakes would give me such unpleasant memories."
    "Un ritmo de silencio completó para los dos. No quería reducir el estado de ánimo. Incluso la acción de cocinar algo tan simple como los panqueques me daría recuerdos tan desagradables."

# game/scriptday2.rpy:914
translate Paloslios scriptday2_7247793e:

    # voice "audio/MDHM_Alan voicelines/Day 2/04_Happy to clean up.mp3"
    # a "Well, I'd be more than happy to clean up."
    voice "audio/mdhm_alan VoicElines/Day 2/04_Happy para limpiar.mp3"
    a "Bueno, estaría más que feliz de limpiar."

# game/scriptday2.rpy:919
translate Paloslios scriptday2_a005b8ac_1:

    # "Those words came out softer than I intended as I began to fix up our plates. I even made sure to give Alan a little more food."
    "Esas palabras salieron más suaves de lo que pretendía cuando comencé a arreglar nuestros platos. Incluso me aseguré de darle a Alan un poco más de comida."

# game/scriptday2.rpy:920
translate Paloslios scriptday2_97f2aec5:

    # u "I remember waking up to many mornings, having food already prepared. Sitting at the table and just listening to family. It wasn't much but no matter what I've always felt full."
    u "Recuerdo haber despertado a muchas mañanas, tener comida ya preparada. Sentado a la mesa y solo escuchando a la familia. No fue mucho, pero no importa lo que siempre haya sentido lleno."

# game/scriptday2.rpy:922
translate Paloslios scriptday2_ef5f270e:

    # a "Sounds like a cozy life."
    a "Suena como una vida acogedora."

# game/scriptday2.rpy:923
translate Paloslios scriptday2_36ab65c6:

    # "I was almost taken by surprise by Alan's comment. Not realizing I was deep in thought over the simple concept of breakfast."
    "Casi me sorprendió el comentario de Alan. Sin darme cuenta de que tenía un pensamiento profundo sobre el simple concepto de desayuno."

# game/scriptday2.rpy:925
translate Paloslios scriptday2_5c1d011b:

    # u "It is! Or... It was before it was taken away."
    u "¡Es! O ... fue antes de que lo quitaran."

# game/scriptday2.rpy:926
translate Paloslios scriptday2_49735aa5:

    # "A beat of silence filled in for the two of us. I didn't want to bring down the mood at all. I never even realized I was homesick, despite doing everything to get away from my old place."
    "Un ritmo de silencio completó para los dos. No quería reducir el estado de ánimo. Nunca me di cuenta de que era nostalgia, a pesar de hacer todo para alejarme de mi antiguo lugar."

# game/scriptday2.rpy:928
translate Paloslios scriptday2_30951d5b:

    # a "Do you have any favorite foods I should keep in mind for next time?"
    a "¿Tienes alguna comida favorita que deba tener en cuenta la próxima vez?"

# game/scriptday2.rpy:930
translate Paloslios scriptday2_b7350446:

    # "The familiar voice of Alan interrupts my thoughts. He was leaning in closer by the second, I could practically feel his breath on my face. Practically inches away."
    "La voz familiar de Alan interrumpe mis pensamientos. Se estaba inclinando más cerca por el segundo, prácticamente podía sentir su aliento en mi rostro. Prácticamente a centímetros de distancia."

# game/scriptday2.rpy:931
translate Paloslios scriptday2_91c26067:

    # "He was getting closer."
    "Se estaba acercando."

# game/scriptday2.rpy:937
translate Paloslios scriptday2_2a3f1470:

    # "I pressed my lips to his and he leaned in. Alan seemed like he had been longing for it. His hand raised to my cheek, craving more. He was nearly devouring my face, like a starving dog."
    "Presioné mis labios para los suyos y él se inclinó. Alan parecía que había estado anhelando. Su mano levantó a mi mejilla, ansiando más. Casi estaba devorando mi cara, como un perro hambriento."

# game/scriptday2.rpy:938
translate Paloslios scriptday2_80e17fa3:

    # "It's getting hard to breathe. I tried to pull my lips away, just for a moment to catch my breath."
    "Es difícil respirar. Traté de alejar mis labios, solo por un momento para recuperar el aliento."

# game/scriptday2.rpy:939
translate Paloslios scriptday2_e7b156f3:

    # u "Al-"
    u "Alabama-"

# game/scriptday2.rpy:940
translate Paloslios scriptday2_3d0c9308:

    # "He smashed his lips again."
    "Se estrelló sus labios nuevamente."

# game/scriptday2.rpy:941
translate Paloslios scriptday2_711c105d:

    # "I began to shudder, my hands made their way to his chest. It was a pathetic attempt to try and pry him away, the kiss was magnetic and I only wanted more."
    "Comencé a estremecerme, mis manos se dirigieron a su pecho. Fue un intento patético para intentar acudirlo, el beso era magnético y solo quería más."

# game/scriptday2.rpy:946
translate Paloslios scriptday2_a00338dd:

    # "Our hot breaths hit the other's skin. Who knew Alan could take my breath away?"
    "Nuestras respiraciones calientes golpearon la piel del otro. ¿Quién sabía que Alan podría dejar mi aliento?"

# game/scriptday2.rpy:947
translate Paloslios scriptday2_ce377322:

    # voice "audio/MDHM_Alan voicelines/Day 2/06_Was that good.mp3"
    # a "Was that... Good?"
    voice "audio/mdhm_alan VoicElines/Day 2/06_was that Good.mp3"
    a "¿Fue eso ... bueno?"

# game/scriptday2.rpy:949
translate Paloslios scriptday2_a13f1786:

    # "I only let out a breathy, short laugh."
    "Solo dejé escapar una risa breve y respirada."

# game/scriptday2.rpy:950
translate Paloslios scriptday2_b59626e7:

    # u "I think you're rather greedy..."
    u "Creo que eres bastante codicioso ..."

# game/scriptday2.rpy:951
translate Paloslios scriptday2_bb6b06c9:

    # "Alan's thumb ran across my cheek affectionately. His touch felt warm and comforting."
    "El pulgar de Alan corrió por mi mejilla cariñosamente. Su toque se sintió cálido y reconfortante."

# game/scriptday2.rpy:952
translate Paloslios scriptday2_2aa9a8d8:

    # u "But I think I could also get used to this too..."
    u "Pero creo que también podría acostumbrarme a esto ..."

# game/scriptday2.rpy:958
translate Paloslios scriptday2_9e1ef80f:

    # "I clamped up and locked my mouth shut. I wasn't sure if I wanted to go even further than this. My whole body went rigid."
    "Alojé y cerré la boca. No estaba seguro de si quería ir aún más allá de esto. Todo mi cuerpo se volvió rígido."

# game/scriptday2.rpy:960
translate Paloslios scriptday2_dc62597a:

    # "Alan's face dropped, but he seemed to get the idea."
    "La cara de Alan cayó, pero parecía tener la idea."

# game/scriptday2.rpy:962
translate Paloslios scriptday2_1d80c3ee:

    # voice "audio/MDHM_Alan voicelines/Noises/Sad/Alan_Sorry.mp3"
    # a "Sorry..."
    voice "audio/mdhm_alan VoicElines/ruidos/sad/alan_sorry.mp3"
    a "Lo siento..."

# game/scriptday2.rpy:964
translate Paloslios scriptday2_6fab6ecc:

    # u "It's fine."
    u "Está bien."

# game/scriptday2.rpy:966
translate Paloslios scriptday2_a5ba883f:

    # "There was a pause of silence between us, but the sound of my heart beating against my chest roared through my ears."
    "Hubo una pausa de silencio entre nosotros, pero el sonido de mi corazón latiendo contra mi pecho rugió a través de mis oídos."

# game/scriptday2.rpy:967
translate Paloslios scriptday2_5dc1bbae:

    # "I couldn't read Alan's expression, his eyes only staring into mine. What could he be thinking about?"
    "No podía leer la expresión de Alan, sus ojos solo miraban a los míos. ¿En qué podría estar pensando?"

# game/scriptday2.rpy:968
translate Paloslios scriptday2_2e54345d:

    # u "I... I think we should eat now, huh? We don't want the food to get cold."
    u "Yo ... Creo que deberíamos comer ahora, ¿eh? No queremos que la comida se enfríe."

# game/scriptday2.rpy:969
translate Paloslios scriptday2_5684cb88:

    # "I awkwardly said, writhing within Alan's arms to the counter."
    "Dije torpemente, retorciéndose dentro de los brazos de Alan hasta el mostrador."

# game/scriptday2.rpy:970
translate Paloslios scriptday2_d0a263d0:

    # u "and um... Sorry I didn't mention this sooner but I have to meet up with a friend later."
    u "Y um ... lo siento, no mencioné esto antes, pero tengo que reunirme con un amigo más tarde."

# game/scriptday2.rpy:972
translate Paloslios scriptday2_7891e355:

    # a "Oh."
    a "Oh."

# game/scriptday2.rpy:973
translate Paloslios scriptday2_f7308947:

    # "Alan's face seemed to fall, all the joy and positivity now sucked out of him."
    "La cara de Alan parecía caer, toda la alegría y la positividad ahora lo chuparon."

# game/scriptday2.rpy:974
translate Paloslios scriptday2_a3839b56:

    # u "Y-You can come if ya want! I'm sure Erika wouldn't mind!"
    u "¡Puedes venir si quieres! ¡Estoy seguro de que a Erika no le importaría!"

# game/scriptday2.rpy:975
translate Paloslios scriptday2_24a0682b:

    # "His face didn't seem to change expression. Not even an eye twitch."
    "Su rostro no parecía cambiar la expresión. Ni siquiera una contracción ocular."

# game/scriptday2.rpy:976
translate Paloslios scriptday2_a95d6aac:

    # a "Erika."
    a "Erika."

# game/scriptday2.rpy:977
translate Paloslios scriptday2_e4cd6b44:

    # "He mumbled under his breath, carefully considering the invite."
    "Murmuró por lo bajo, considerando cuidadosamente la invitación."

# game/scriptday2.rpy:978
translate Paloslios scriptday2_47b41387:

    # u "If you don't want to then that's ok-"
    u "Si no quieres, eso está bien"

# game/scriptday2.rpy:979
translate Paloslios scriptday2_5fbbd455:

    # a "No. I'm going."
    a "No. Voy."

# game/scriptday2.rpy:980
translate Paloslios scriptday2_634dfd66:

    # "I blinked at him."
    "Parpadeé sobre él."

# game/scriptday2.rpy:981
translate Paloslios scriptday2_f526d617:

    # u "Well- If you're sure."
    u "Bien si estás seguro."

# game/scriptday2.rpy:983
translate Paloslios scriptday2_38e5b81b:

    # "Alan smiled at me as I grabbed our plates. That was a little strange from him. I hope I didn't make him feel obligated to come with me."
    "Alan me sonrió mientras agarraba nuestros platos. Eso fue un poco extraño de él. Espero no haberlo hecho sentir obligado a venir conmigo."

# game/scriptday2.rpy:990
translate Paloslios scriptday2_ea4a4aaf:

    # "After some time, I was able to remember where the park actually was. I don't visit much, only came for the occasional walk."
    "Después de un tiempo, pude recordar dónde estaba realmente el parque. No visito mucho, solo vine para caminar ocasionalmente."

# game/scriptday2.rpy:991
translate Paloslios scriptday2_015dcf92:

    # "It wasn't too busy around this time. There was the occasional kid here and there, the place was often taken over by old people feeding the pigeons or students from the campus."
    "No estaba demasiado ocupado en esta época. Hubo un niño ocasional aquí y allá, el lugar a menudo fue tomado por personas mayores que alimentaban a las palomas o estudiantes del campus."

# game/scriptday2.rpy:992
translate Paloslios scriptday2_4cd47ad6:

    # "If I was really lucky, I would listen to some live music from music groups and get tips from the locals."
    "Si tuviera mucha suerte, escucharía música en vivo de grupos de música y obtendría consejos de los lugareños."

# game/scriptday2.rpy:993
translate Paloslios scriptday2_397de54a:

    # "I even heard about really late night college parties being hosted, but I wasn't usually invited to any of them. The tell-tale signs if a party did happen, the park would be littered with those typical red solo cups."
    "Incluso escuché que las fiestas universitarias realmente nocturnas fueron organizadas, pero generalmente no me invitaron a ninguno de ellos. Las señales reveladoras si se produjo una fiesta, el parque estaría lleno de esas típicas copas solas rojas."

# game/scriptday2.rpy:994
translate Paloslios scriptday2_7537cee8:

    # "I looked over to Alan, expecting him to have something to say but I was met with an unpleasant look from him."
    "Miré a Alan, esperando que tuviera algo que decir, pero me encontré con una mirada desagradable de él."

# game/scriptday2.rpy:999
translate Paloslios scriptday2_2c716b2c:

    # "He seemed... Off. His eyes scanned around, almost like he was on guard."
    "Parecía ... fuera. Sus ojos se escanearon, casi como si estuviera en guardia."

# game/scriptday2.rpy:1000
translate Paloslios scriptday2_a20cefa7_10:

    # "..."
    "..."

# game/scriptday2.rpy:1005
translate Paloslios scriptday2_829368b1:

    # "He saw that I was looking at him and instantly smiled at me, trying to come off that he wasn't bothered at all."
    "Vio que lo estaba mirando e instantáneamente me sonrió, tratando de salir de que no se le molestaba en absoluto."

# game/scriptday2.rpy:1006
translate Paloslios scriptday2_9e930c9c:

    # "I nervously flashed him back a grin in return."
    "Lo devolví nerviosamente una sonrisa a cambio."

# game/scriptday2.rpy:1008
translate Paloslios scriptday2_10c8f107_1:

    # e "[name]."
    e "[name]."

# game/scriptday2.rpy:1009
translate Paloslios scriptday2_ffd0c649_1:

    # "I hear my name through the whole commotion of the park. There, sat Erika on a bed of green grass, an intricate lacey pink blanket spread on the ground."
    "Escucho mi nombre a través de toda la conmoción del parque. Allí, se sentó Erika en una cama de hierba verde, una intrincada manta rosa lacey extendida en el suelo."

# game/scriptday2.rpy:1010
translate Paloslios scriptday2_631eaa6f:

    # "Did she set up this study date like a picnic? She even packed snacks and drinks. "
    "¿Estableció esta fecha de estudio como un picnic? Incluso empacó bocadillos y bebidas. "

# game/scriptday2.rpy:1017
translate Paloslios scriptday2_d894f123:

    # e "You made it."
    e "Lo hiciste."

# game/scriptday2.rpy:1018
translate Paloslios scriptday2_5273bae0:

    # "I briefly waved at Erika as we both approached her. Her usual, apathetic face never faltered, even when she caught a glance at the sight of Alan."
    "Salí brevemente a Erika cuando ambos nos acercamos a ella. Su cara habitual y apática nunca vaciló, incluso cuando miró a la vista de Alan."

# game/scriptday2.rpy:1019
translate Paloslios scriptday2_6005dd48:

    # e "Oh. You brought... A friend?"
    e "Oh. Trajiste ... ¿un amigo?"

# game/scriptday2.rpy:1021
translate Paloslios scriptday2_eb1ca283:

    # "She looked over to Alan. She seemed a little taken aback. In all fairness, I probably should've advised her beforehand."
    "Ella miró a Alan. Ella parecía un poco desconcertada. Para ser justos, probablemente debería haberle aconsejado de antemano."

# game/scriptday2.rpy:1022
translate Paloslios scriptday2_3b5a4cb7:

    # u "You don't mind? Hopefully?"
    u "¿No te importa? ¿Con un poco de suerte?"

# game/scriptday2.rpy:1024
translate Paloslios scriptday2_e526240d:

    # "There was an awkward pause, Erika nervously adjusted her skirt before giving a response but she still kept a cool head."
    "Hubo una pausa incómoda, Erika ajustó nerviosamente su falda antes de dar una respuesta, pero todavía mantuvo una cabeza fría."

# game/scriptday2.rpy:1025
translate Paloslios scriptday2_f81764c9:

    # e "... No. That's fine, but this means I didn't bring enough food to feed all four of us."
    e "... No. Eso está bien, pero esto significa que no traje suficiente comida para alimentarnos a los cuatro."

# game/scriptday2.rpy:1026
translate Paloslios scriptday2_6b7f477c:

    # u "Four?"
    u "¿Cuatro?"

# game/scriptday2.rpy:1027
translate Paloslios scriptday2_f9e64bbf:

    # s "[name]!"
    s "[name]!"

# game/scriptday2.rpy:1028
translate Paloslios scriptday2_46657b43_1:

    # "I heard a voice coming to my right, and I was met with a bright, cheerful face."
    "Escuché una voz que llegaba a mi derecha, y me encontré con una cara brillante y alegre."

# game/scriptday2.rpy:1033
translate Paloslios scriptday2_a2a23130_1:

    # u "!!!"
    u "!"

# game/scriptday2.rpy:1036
translate Paloslios scriptday2_3c501fa9_1:

    # voice "audio/MDHM_Stu voicelines/noises/Happy/Stu_Hey.mp3"
    # s "Hey [name]!"
    voice "audio/mdhm_stu VoicElines/ruidos/happy/stu_hey.mp3"
    s "Hola [name]!"

# game/scriptday2.rpy:1039
translate Paloslios scriptday2_ad6989fb_1:

    # "I recognize that dorky smile from anywhere."
    "Reconozco esa sonrisa tonta desde cualquier lugar."

# game/scriptday2.rpy:1040
translate Paloslios scriptday2_2e46191d_1:

    # u "... Stu?"
    u "... Stu?"

# game/scriptday2.rpy:1042
translate Paloslios scriptday2_42ed152c_1:

    # "My eyes slowly blinked and the hamster wheels in my head quickly started to turn."
    "Mis ojos parpadearon lentamente y las ruedas de hámster en mi cabeza rápidamente comenzaron a girar."

# game/scriptday2.rpy:1045
translate Paloslios scriptday2_3ced9b32:

    # voice "audio/MDHM_Stu voicelines/noises/Happy/Stu_Laugh 1.mp3"
    # voice "audio/MDHM_Stu voicelines/Day 2/02_It_s been so long.mp3"
    # s "You're here! It's been so long!"
    voice "audio/mdhm_stu VoicElines/ruidos/happy/stu_laugh 1.mp3"
    voice "audio/mdhm_stu VoicElines/Day 2/02_IT_S ha sido tan largo.mp3"
    s "¡Estás aquí! ¡Ha pasado tanto tiempo!"

# game/scriptday2.rpy:1049
translate Paloslios scriptday2_4f968345:

    # "I stood there for a couple of seconds in complete shock. The bastard I haven't seen since high school. I couldn't help but smile at him."
    "Me quedé allí durante un par de segundos en completo shock. El bastardo que no he visto desde la secundaria. No pude evitar sonreírle."

# game/scriptday2.rpy:1050
translate Paloslios scriptday2_88034e53:

    # u "What the hell are you even doing here? You didn't tell me you were around!"
    u "¿Qué diablos estás haciendo aquí? ¡No me dijiste que estabas cerca!"

# game/scriptday2.rpy:1052
translate Paloslios scriptday2_16bfe7f1:

    # s "I wanted to surprise you! Isn't that cool? Erika said she knew you and agreed to invite me to the study date so we could see each other."
    s "¡Quería sorprenderte! ¿No es genial? Erika dijo que te conocía y aceptó invitarme a la fecha del estudio para que pudiéramos vernos."

# game/scriptday2.rpy:1054
translate Paloslios scriptday2_9445b0e3:

    # e "Hesitantly agreed."
    e "Acordó vacilante."

# game/scriptday2.rpy:1055
translate Paloslios scriptday2_fadfed93:

    # s "Y-Yeah!"
    s "¡Y-Yeah!"

# game/scriptday2.rpy:1057
translate Paloslios scriptday2_1be249b7:

    # "I didn't think to realize me and Stu were letting our conversation get in the way of the study date until Erika cut it short, clearing her throat sternly."
    "No pensé en darme cuenta de que STU y yo estábamos dejando que nuestra conversación se interpusiera en la fecha del estudio hasta que Erika la interrumpiera, aclarando su garganta severamente."

# game/scriptday2.rpy:1058
translate Paloslios scriptday2_14058108:

    # e "Mind telling me that change of plans, [name]?"
    e "¿Te importa decirme ese cambio de planes, [name]?"

# game/scriptday2.rpy:1059
translate Paloslios scriptday2_df5ab2b0:

    # u "Oh! Right..."
    u "¡Oh! Bien..."

# game/scriptday2.rpy:1060
translate Paloslios scriptday2_2b4813a1:

    # "I nervously rubbed the back of my neck and gestured to Alan, who was standing right behind me. I didn't take into account that Alan was being left out of our chit-chat and my reunion."
    "Me froté nerviosamente la parte posterior de mi cuello y le hizo un gesto a Alan, que estaba parado detrás de mí. No tuve en cuenta que Alan estaba fuera de nuestro chit-chat y mi reunión."

# game/scriptday2.rpy:1061
translate Paloslios scriptday2_5f673526:

    # u "This is Alan! We crossed paths not too long ago."
    u "¡Este es Alan! Nos cruzamos no hace mucho tiempo."

# game/scriptday2.rpy:1067
translate Paloslios scriptday2_6fdd6c70:

    # "As soon as I introduced him, I was met with silence. Erika and Stu looked baffled."
    "Tan pronto como lo presenté, me encontré con silencio. Erika y Stu parecían desconcertados."

# game/scriptday2.rpy:1068
translate Paloslios scriptday2_769daa59:

    # "Alan hasn't even uttered a word."
    "Alan ni siquiera ha pronunciado una palabra."

# game/scriptday2.rpy:1069
translate Paloslios scriptday2_a20cefa7_11:

    # "..."
    "..."

# game/scriptday2.rpy:1070
translate Paloslios scriptday2_571277cd:

    # a "Hi."
    a "Hola."

# game/scriptday2.rpy:1071
translate Paloslios scriptday2_c8f70e58:

    # "Alan's voice shook me up a bit, I couldn't help but let out a nervous laugh."
    "La voz de Alan me sacudió un poco, no pude evitar dejar escapar una risa nerviosa."

# game/scriptday2.rpy:1076
translate Paloslios scriptday2_831f89f2:

    # e "'Pleasure."
    e "'Placer."

# game/scriptday2.rpy:1077
translate Paloslios scriptday2_3d9b1200:

    # s "... Hey."
    s "... Ey."

# game/scriptday2.rpy:1078
translate Paloslios scriptday2_bb8e4b4e_1:

    # a "..."
    a "..."

# game/scriptday2.rpy:1079
translate Paloslios scriptday2_a20cefa7_12:

    # "..."
    "..."

# game/scriptday2.rpy:1080
translate Paloslios scriptday2_e40d0530:

    # "Everyone falls into an awkward silence, only the natural folly of the park filling the dead air. I have to think of a conversation starter, quick."
    "Todos caen en un silencio incómodo, solo la locura natural del parque llena el aire muerto. Tengo que pensar en un iniciador de conversación, rápido."

# game/scriptday2.rpy:1085
translate Paloslios scriptday2_b7107b60:

    # u "Soooo... What did you have planned for this study date?"
    u "Entonces ... ¿qué habías planeado para esta fecha de estudio?"

# game/scriptday2.rpy:1088
translate Paloslios scriptday2_d91b9db8:

    # "Everyone's attention was now drawn to me as I called out for Erika. It only seemed fair to ask her what she wanted to do originally, right? It was her idea to meet up."
    "La atención de todos ahora me atrajo cuando llamé a Erika. Solo parecía justo preguntarle qué quería hacer originalmente, ¿verdad? Fue su idea reunirse."

# game/scriptday2.rpy:1089
translate Paloslios scriptday2_e3e4dc83:

    # e "Right. Well, the idea was to study for our English assignment."
    e "Bien. Bueno, la idea era estudiar para nuestra tarea de inglés."

# game/scriptday2.rpy:1090
translate Paloslios scriptday2_59cf4ad4:

    # "She trailed off with her words and daintily held her chin with her hand, trying to think."
    "Se quedó con sus palabras y sostuvo su barbilla con la mano, tratando de pensar."

# game/scriptday2.rpy:1091
translate Paloslios scriptday2_2607ec19:

    # e "If these two don't mind boring lessons that is."
    e "Si a estos dos no les importa lecciones aburridas."

# game/scriptday2.rpy:1093
translate Paloslios scriptday2_fba54cf3:

    # "Erika pointed at both Stu and Alan. One of them only smiled."
    "Erika señaló tanto a Stu como a Alan. Uno de ellos solo sonrió."

# game/scriptday2.rpy:1094
translate Paloslios scriptday2_85e5b856:

    # s "I don't mind!"
    s "¡No me importa!"

# game/scriptday2.rpy:1097
translate Paloslios scriptday2_0c233f5e:

    # u "Sooo Stu, Why are you even here?"
    u "Sooo Stu, ¿por qué estás aquí?"

# game/scriptday2.rpy:1100
translate Paloslios scriptday2_e67d4220:

    # s "Well, it's my job to bother you, is it not?"
    s "Bueno, es mi trabajo molestarte, ¿no?"

# game/scriptday2.rpy:1101
translate Paloslios scriptday2_46b7b77a_1:

    # "I roll my eyes."
    "Me pongo los ojos."

# game/scriptday2.rpy:1102
translate Paloslios scriptday2_bf7b4741_1:

    # u "That's not what I meant! I thought you said you didn't have a chance to move here. So..."
    u "¡Eso no es lo que quise decir! Pensé que dijiste que no tenías la oportunidad de mudarte aquí. Entonces..."

# game/scriptday2.rpy:1104
translate Paloslios scriptday2_ab343aa7_1:

    # "As my words trailed off, Stu scratched the back of his head uncomfortably, letting out a nervous laugh."
    "Mientras mis palabras se apagaban, Stu se rascó la parte posterior de su cabeza incómoda, dejando escapar una risa nerviosa."

# game/scriptday2.rpy:1105
translate Paloslios scriptday2_50942370_1:

    # voice "audio/MDHM_Stu voicelines/Day 2/04_Guess.mp3"
    # s "Your guess is as good as mine. I don't know what the forces of the universe are doing, but I'll be sure to thank them!"
    voice "audio/mdhm_stu VoicElines/Day 2/04_Guess.mp3"
    s "Tu suposición es tan buena como la mía. No sé qué están haciendo las fuerzas del universo, ¡pero me aseguraré de agradecerles!"

# game/scriptday2.rpy:1107
translate Paloslios scriptday2_d0a7bf74:

    # "I rolled my eyes at that, but churtle out a laugh."
    "Puse los ojos en manos de eso, pero me ríe."

# game/scriptday2.rpy:1108
translate Paloslios scriptday2_686066c8:

    # u "Loser."
    u "Perdedor."

# game/scriptday2.rpy:1110
translate Paloslios scriptday2_481781ba:

    # s "Dork."
    s "Dork."

# game/scriptday2.rpy:1111
translate Paloslios scriptday2_a50fa505:

    # u "Idiot!"
    u "¡Estúpido!"

# game/scriptday2.rpy:1112
translate Paloslios scriptday2_ba997e1d:

    # s "Jackass!"
    s "¡Burro!"

# game/scriptday2.rpy:1114
translate Paloslios scriptday2_43e73256:

    # e "Ahem."
    e "Ejem."

# game/scriptday2.rpy:1116
translate Paloslios scriptday2_28fab2d3:

    # "Before me and Stu could continue playfully throwing insults at each other, Erika interrupted."
    "Antes de que yo y Stu pudimos continuar lanzándose juguetonamente los insultos el uno al otro, Erika interrumpió."

# game/scriptday2.rpy:1118
translate Paloslios scriptday2_932a71fd:

    # e "Sorry to ruin your little reunion here, but [name], have you forgotten why we're even here, in the first place?"
    e "Lamento arruinar su pequeña reunión aquí, pero [name], ¿has olvidado por qué estamos aquí, en primer lugar?"

# game/scriptday2.rpy:1119
translate Paloslios scriptday2_7ff79e84:

    # u "Oh. Right."
    u "Oh. Bien."

# game/scriptday2.rpy:1120
translate Paloslios scriptday2_6884992e:

    # "I nervously laugh and rub the back of my neck. It felt a little humiliating to be scolded like a child by Erika."
    "Me río nerviosamente y me froto la parte posterior de mi cuello. Se sintió un poco humillante ser regañado como un niño por Erika."

# game/scriptday2.rpy:1124
translate Paloslios scriptday2_22bb1337:

    # u "Sooo, Alan- I hope you don't mind me just studying. Today was probably the most boring hang out for us."
    u "Entonces, Alan, espero que no te importe que solo estudie. Hoy fue probablemente el pasto más aburrido para nosotros."

# game/scriptday2.rpy:1126
translate Paloslios scriptday2_5f52cad4:

    # "Alan's face brightened up when I talked to him, it was like all his nerves completely melted away."
    "La cara de Alan se iluminó cuando hablé con él, era como si todos sus nervios se derritieran por completo."

# game/scriptday2.rpy:1127
translate Paloslios scriptday2_ce38bedb:

    # voice "audio/MDHM_Alan voicelines/Day 2/07_Don_t mind at all.mp3"
    # a "I don't mind at all. Anything for you, Doe-Eyes."
    voice "audio/mdhm_alan VoicElines/Day 2/07_don_t Mind en absoluto.mp3"
    a "No me importa en absoluto. Cualquier cosa para ti, Doe-Eyes."

# game/scriptday2.rpy:1134
translate Paloslios scriptday2_45bcd48e:

    # "Oh. He was using that nickname still. In front of them."
    "Oh. Todavía estaba usando ese apodo. Frente a ellos."

# game/scriptday2.rpy:1136
translate Paloslios scriptday2_5f37f6d1:

    # "I could hear Stu muttering something to himself, but I was unable to pick up anything intelligible."
    "Podía escuchar a Stu murmurando algo para sí mismo, pero no pude recoger nada inteligible."

# game/scriptday2.rpy:1141
translate Paloslios scriptday2_dde82a00:

    # "Maybe I was worrying too much. It was just a harmless nickname."
    "Tal vez me estaba preocupando demasiado. Era solo un apodo inofensivo."

# game/scriptday2.rpy:1144
translate Paloslios scriptday2_6121931b:

    # "I shook my head at him, not saying anything but my actions were speaking for me. While he could call 'doe-eyes' if he wanted, I wasn't too keen on him saying it in front of others."
    "Le sacudí la cabeza hacia él, sin decir nada, pero mis acciones estaban hablando por mí. Si bien podría llamar a 'Doe-Eyes' si quisiera, no estaba demasiado interesado en que lo dijera frente a los demás."

# game/scriptday2.rpy:1147
translate Paloslios scriptday2_bb5f74f6:

    # "It's no issue. I thought it was kinda cute."
    "No es un problema. Pensé que era un poco lindo."

# game/scriptday2.rpy:1150
translate Paloslios scriptday2_c82ffe81:

    # "I looked back to Stu and Erika, who we all silently agreed to continue with the plan of the study date."
    "Regresé a Stu y Erika, a quienes todos acordamos en silencio continuar con el plan de la fecha del estudio."

# game/scriptday2.rpy:1151
translate Paloslios scriptday2_e67d7f7f:

    # e "We can study for a few minutes and have the rest of the hour to finish up the assignment. How does that sound?"
    e "Podemos estudiar durante unos minutos y tener el resto de la hora para terminar la tarea. ¿Cómo suena eso?"

# game/scriptday2.rpy:1153
translate Paloslios scriptday2_b256eb12:

    # "There's that then! I look over to Alan, smiling up to him."
    "¡Ahí entonces! Miro a Alan, sonriendo hacia él."

# game/scriptday2.rpy:1155
translate Paloslios scriptday2_9ce2b0d3:

    # "Only to be met with an unpleasant scowl. He was staring daggers to the two in front of him but once his eyes met me-"
    "Solo para ser encontrado con un desagradable fruncido. Estaba mirando dagas a los dos frente a él, pero una vez que sus ojos me encontraron"

# game/scriptday2.rpy:1160
translate Paloslios scriptday2_ea9f4ac8:

    # "His expression softened."
    "Su expresión se suavizó."

# game/scriptday2.rpy:1161
translate Paloslios scriptday2_7a74dd8a:

    # "Unease fell to the pit of my stomach. Usually Alan was more or less talkative with me but then again, he told me he never really interacted with anyone else. I'm the only one he had spoken to."
    "La inquietud cayó al pozo de mi estómago. Por lo general, Alan era más o menos hablador conmigo, pero de nuevo, me dijo que nunca interactuó con nadie más. Soy el único con el que había hablado."

# game/scriptday2.rpy:1162
translate Paloslios scriptday2_27bfec8c:

    # "Quite frankly, I thought he was kinda exaggerating. I mean, Doomsbury was a small college town, almost everyone knew each other, even if it was through a friend of a friend."
    "Francamente, pensé que estaba un poco exagerado. Quiero decir, Doomsbury era una pequeña ciudad universitaria, casi todos se conocían, incluso si era a través de un amigo de un amigo."

# game/scriptday2.rpy:1166
translate Paloslios scriptday2_8a491479:

    # "We all sat down together, all in a neat little circle, the basket of food perfectly sat in the middle. Alan sat the closest to me, dropping down to the grass and positioned his knees up to his chest."
    "Todos nos sentamos juntos, todo en un pequeño círculo ordenado, la canasta de comida se sentó perfectamente en el medio. Alan se sentó más cerca de mí, cayendo hacia la hierba y colocó las rodillas hacia su pecho."

# game/scriptday2.rpy:1167
translate Paloslios scriptday2_49d91275:

    # "I saw Erika take out some assignments and a book we had been assigned."
    "Vi a Erika sacar algunas tareas y un libro que nos habían asignado."

# game/scriptday2.rpy:1168
translate Paloslios scriptday2_d7df23a8_1:

    # e "Should I go over the lesson for you?"
    e "¿Debería revisar la lección por ti?"

# game/scriptday2.rpy:1169
translate Paloslios scriptday2_57733e32_1:

    # u "That would be nice."
    u "Eso sería bueno."

# game/scriptday2.rpy:1170
translate Paloslios scriptday2_b3563dac:

    # "Erika nodded at me, graciously placing a pencil right behind her ear while flipping through the textbook. Throughout the day, we mostly talked amongst ourselves, while Alan and Stu sat in awkward silence."
    "Erika me asintió, colocando gentilmente un lápiz justo detrás de la oreja mientras hojeaba el libro de texto. Durante todo el día, hablamos principalmente entre nosotros, mientras Alan y Stu se sentaron en un silencio incómodo."

# game/scriptday2.rpy:1171
translate Paloslios scriptday2_60e40fa7_1:

    # "I looked over to Erika, noting how her fingers lightly trace over the text on the surface of the page."
    "Miré a Erika, notando cómo sus dedos trazan ligeramente sobre el texto en la superficie de la página."

# game/scriptday2.rpy:1172
translate Paloslios scriptday2_435a8126_1:

    # "The book Erika was holding caught my attention. It looked rather old, the edges already fading from its original color, and the paper crinkled with every movement."
    "El libro que Erika estaba sosteniendo me llamó la atención. Parecía bastante viejo, los bordes ya se desvanecían de su color original, y el papel se arrugó con cada movimiento."

# game/scriptday2.rpy:1173
translate Paloslios scriptday2_71cc3f02_1:

    # u "So, what book did you pick for our assignment?"
    u "Entonces, ¿qué libro elegiste para nuestra tarea?"

# game/scriptday2.rpy:1174
translate Paloslios scriptday2_f640de4c_1:

    # "Erika turned over to the cover of the book, and I read its title."
    "Erika dio la vuelta a la portada del libro, y leí su título."

# game/scriptday2.rpy:1175
translate Paloslios scriptday2_da73751d_1:

    # u "Whispers of the Hanged?"
    u "Susurros del ahorcado?"

# game/scriptday2.rpy:1176
translate Paloslios scriptday2_13734d0e_1:

    # "The title sounded a little gruesome."
    "El título sonaba un poco horrible."

# game/scriptday2.rpy:1177
translate Paloslios scriptday2_310311ba_1:

    # u "Sooo what's it about?"
    u "Entonces, ¿de qué se trata?"

# game/scriptday2.rpy:1178
translate Paloslios scriptday2_9ac9fffb_1:

    # e "The actual history of the Salem Witch Trials. It goes through all the grim details of what women of that time went through. The excruciating executions-"
    e "La historia real de los juicios de bruja de Salem. Pasa por todos los detalles sombríos de lo que pasaron las mujeres de esa época. Las ejecuciones insoportables-"

# game/scriptday2.rpy:1180
translate Paloslios scriptday2_f544372b:

    # a "That's a bit barbaric, eh?"
    a "Eso es un poco bárbaro, ¿eh?"

# game/scriptday2.rpy:1181
translate Paloslios scriptday2_4dc006f0:

    # "There was a beat of silence."
    "Hubo un ritmo de silencio."

# game/scriptday2.rpy:1183
translate Paloslios scriptday2_72a33094:

    # e "..."
    e "..."

# game/scriptday2.rpy:1184
translate Paloslios scriptday2_2abd0262:

    # "Erika gave him a look. I wasn't sure what to describe it. Was that anger, surprise or both?"
    "Erika le miró. No estaba seguro de qué describirlo. ¿Fue esa ira, sorpresa o ambos?"

# game/scriptday2.rpy:1185
translate Paloslios scriptday2_0a096277:

    # "I feel like I should say something but-"
    "Siento que debería decir algo pero"

# game/scriptday2.rpy:1189
translate Paloslios scriptday2_986dec65:

    # "My lips stayed sealed shut. I think it's better if I don't say anything. However, the tension lingered."
    "Mis labios permanecieron sellados cerrados. Creo que es mejor si no digo nada. Sin embargo, la tensión permaneció."

# game/scriptday2.rpy:1192
translate Paloslios scriptday2_d4af3733:

    # u "It is barbaric but that's history, ya know?"
    u "Es bárbaro pero eso es historia, ¿sabes?"

# game/scriptday2.rpy:1195
translate Paloslios scriptday2_10dd9c01_1:

    # voice "audio/MDHM_Stu voicelines/noises/Happy/Stu_Laugh 1.mp3"
    voice "audio/mdhm_stu VoicElines/ruidos/happy/stu_laugh 1.mp3"

# game/scriptday2.rpy:1199
translate Paloslios scriptday2_de6845a7:

    # "I forced out a laugh, trying to get others to join. The only one that did so was Stu. Alan simply crossed his arms and Erika remained silent, but looked down at her book."
    "Foré reír, tratando de que otros se unieran. El único que lo hizo fue Stu. Alan simplemente cruzó los brazos y Erika permaneció en silencio, pero miró su libro."

# game/scriptday2.rpy:1200
translate Paloslios scriptday2_1728aab1:

    # a "'Not a fan of real life violent crimes."
    a "'No es fanático de los crímenes violentos de la vida real."

# game/scriptday2.rpy:1201
translate Paloslios scriptday2_92765a6c:

    # a "Or reading it for that matter."
    a "O leerlo para el caso."

# game/scriptday2.rpy:1202
translate Paloslios scriptday2_a20cefa7_13:

    # "..."
    "..."

# game/scriptday2.rpy:1203
translate Paloslios scriptday2_62ee0e55:

    # voice "audio/MDHM_Erika voicelines/Day 2/04_Assignment.mp3"
    # e "Good thing it's not your assignment then."
    voice "audio/mdhm_erika VoicElines/Day 2/04_Assignment.mp3"
    e "Menos mal que no es tu tarea entonces."

# game/scriptday2.rpy:1205
translate Paloslios scriptday2_0003f7b9:

    # "Well, so much for that plan. I did the best I could. The tension was so thick you could cut it."
    "Bueno, mucho para ese plan. Hice lo mejor que pude. La tensión era tan gruesa que podías cortarla."

# game/scriptday2.rpy:1208
translate Paloslios scriptday2_6bcdf416:

    # s "H-Hey, [name]!"
    s "H-hey, [name]!"

# game/scriptday2.rpy:1209
translate Paloslios scriptday2_ac71e891:

    # "Stu waved in front of me, graciously saving me from this awkward moment."
    "Stu saludó frente a mí, gentilmente salvándome de este incómodo momento."

# game/scriptday2.rpy:1210
translate Paloslios scriptday2_7cf75a2c:

    # s "I hope you didn't replace me already! Look at you making friends!"
    s "¡Espero que no me hayas reemplazado aún! ¡Mira te hace amigos!"

# game/scriptday2.rpy:1213
translate Paloslios scriptday2_10dd9c01_2:

    # voice "audio/MDHM_Stu voicelines/noises/Happy/Stu_Laugh 1.mp3"
    voice "audio/mdhm_stu VoicElines/ruidos/happy/stu_laugh 1.mp3"

# game/scriptday2.rpy:1217
translate Paloslios scriptday2_4edc277a:

    # "I let out a sigh of relief, and I was sure that Erika did so too."
    "Dejé escapar un suspiro de alivio, y estaba seguro de que Erika también lo hizo."

# game/scriptday2.rpy:1218
translate Paloslios scriptday2_f16359c1:

    # "All attention was now on Stu, if I knew him well enough, he would try his best NOT to appear socially awkward. Hopefully he can ramble his way out of this one."
    "Ahora toda la atención estaba en Stu, si lo conociera lo suficientemente bien, él haría todo lo posible para no parecer socialmente incómodo. Esperemos que pueda salir de este."

# game/scriptday2.rpy:1219
translate Paloslios scriptday2_5d76ad8f:

    # s "This takes me back when we used to do homework together, r-remember?"
    s "¿Esto me lleva de regreso cuando solíamos hacer la tarea juntos, R-Recuerdas?"

# game/scriptday2.rpy:1221
translate Paloslios scriptday2_11113196:

    # u "Oh yeah. You copied off of me."
    u "Oh sí. Me copiaste."

# game/scriptday2.rpy:1223
translate Paloslios scriptday2_69f19395:

    # s "Y-You- You let me! And not all the time..."
    s "Y-yo- ¡me dejas! Y no todo el tiempo ..."

# game/scriptday2.rpy:1224
translate Paloslios scriptday2_11ce89f2:

    # "Stu stumbled on his words and let out a pout."
    "Stu tropezó con sus palabras y dejó escapar un puchero."

# game/scriptday2.rpy:1225
translate Paloslios scriptday2_bc7a3ce0:

    # u "We would 'study' in that old treehouse of yours."
    u "'Estudiaríamos' en esa antigua casa del árbol tuya."

# game/scriptday2.rpy:1227
translate Paloslios scriptday2_89d309ac:

    # s "When in reality we would watch anime..."
    s "Cuando en realidad veríamos anime ..."

# game/scriptday2.rpy:1228
translate Paloslios scriptday2_7c88d275:

    # "I smiled at him, memories flooding back and with so much warmth still lingering in them. I was pretty sure Stu's parents knew we weren't even studying but they didn't stop us."
    "Le sonreí, los recuerdos se inundaron y con tanta calidez aún permaneciendo en ellos. Estaba bastante seguro de que los padres de Stu sabían que ni siquiera estábamos estudiando, pero no nos detuvieron."

# game/scriptday2.rpy:1230
translate Paloslios scriptday2_0182205a:

    # "Stu gave me a smile, shuffling closer to me, naturally drawn to me again."
    "Stu me dio una sonrisa, arrastrándome más cerca de mí, naturalmente atraído por mí nuevamente."

# game/scriptday2.rpy:1232
translate Paloslios scriptday2_fbaf789b:

    # a "Anime...?"
    a "Anime ...?"

# game/scriptday2.rpy:1234
translate Paloslios scriptday2_ee767e56:

    # "I jumped, startled by Alan speaking. Stu appeared so as well, his face going white as he looked over my shoulder. I didn't even know Alan stood right behind me, his hot breath at my neck."
    "Salté, sorprendido por Alan hablando. Stu también apareció así, su rostro se volvió blanco mientras miraba por encima del hombro. Ni siquiera sabía que Alan estaba justo detrás de mí, su aliento caliente en el cuello."

# game/scriptday2.rpy:1235
translate Paloslios scriptday2_d40bfcc1:

    # s "Y-Yeah... Do you watch it too...?"
    s "S-si-... ¿Lo ves también ...?"

# game/scriptday2.rpy:1236
translate Paloslios scriptday2_bb8e4b4e_2:

    # a "..."
    a "..."

# game/scriptday2.rpy:1237
translate Paloslios scriptday2_2a06e27a:

    # "Alan wasn't planning on replying anytime soon. He was like an on and off switch, only replying with as little to no words as possible and became silent again."
    "Alan no estaba planeando responder pronto. Era como un interruptor de encendido y apagado, solo respondía con la menor o ninguna palabras posible y se quedó en silencio nuevamente."

# game/scriptday2.rpy:1238
translate Paloslios scriptday2_05100371:

    # "Everytime someone tried to calm down the situation, the atmosphere would become hostile again. I'm starting to regret bringing Alan with me."
    "Cada vez que alguien intentaba calmar la situación, la atmósfera volvería a ser hostil. Estoy empezando a arrepentirme de traer a Alan conmigo."

# game/scriptday2.rpy:1239
translate Paloslios scriptday2_fd69c0fb:

    # "I tried to speak to again-"
    "Traté de hablar de nuevo"

# game/scriptday2.rpy:1241
translate Paloslios scriptday2_17dc7289:

    # voice "audio/MDHM_Stu voicelines/Day 2/08_Friendly.mp3"
    # s "L-Listen man, I'm trying to be as friendly as I can with you."
    voice "audio/mdhm_stu VoicElines/Day 2/08_friendly.mp3"
    s "L-Listen Hombre, estoy tratando de ser lo más amigable posible contigo."

# game/scriptday2.rpy:1243
translate Paloslios scriptday2_31eb292e:

    # "Stu spoke up before me. There was still some hesitation with the way he spoke."
    "Stu habló delante de mí. Todavía había algunas dudas con la forma en que hablaba."

# game/scriptday2.rpy:1244
translate Paloslios scriptday2_61d992dd:

    # s "WE'RE trying."
    s "Lo estamos intentando."

# game/scriptday2.rpy:1245
translate Paloslios scriptday2_b3b0edeb:

    # "He proceeded to gesture to both him and Erika, much to her surprise."
    "Se dirigió a un gesto para él y Erika, para su sorpresa."

# game/scriptday2.rpy:1246
translate Paloslios scriptday2_88a8e46a:

    # voice "audio/MDHM_Stu voicelines/Day 2/09_Don_t have to be here.mp3"
    # s "I get that you are also a friend of [name], a-and we don't have to be your friends, but throw us a friggin' b-bone! You don't have to be here."
    voice "audio/mdhm_stu VoicElines/Day 2/09_don_t debe estar aquí.mp3"
    s "Entiendo que también eres un amigo de [name], A-y no tenemos que ser tus amigos, ¡pero lánzanos un maldito B-Bone! No tienes que estar aquí."

# game/scriptday2.rpy:1249
translate Paloslios scriptday2_a20cefa7_14:

    # "..."
    "..."

# game/scriptday2.rpy:1250
translate Paloslios scriptday2_79bc48c3:

    # "There was a beat of silence. My heart could stop right then and there."
    "Hubo un ritmo de silencio. Mi corazón podría detenerse en ese momento."

# game/scriptday2.rpy:1251
translate Paloslios scriptday2_dde00f53:

    # a "Who are you again? Do you even have plans after this whole college thing? From what I've seen, I can't really see you having a stable career. Any back up plans if it goes south?"
    a "¿Quién eres de nuevo? ¿Tiene incluso planes después de todo este asunto de la universidad? Por lo que he visto, realmente no puedo verte tener una carrera estable. ¿Algún plan de respaldo si va al sur?"

# game/scriptday2.rpy:1252
translate Paloslios scriptday2_e1554201_1:

    # s "..."
    s "..."

# game/scriptday2.rpy:1254
translate Paloslios scriptday2_78486633:

    # voice "audio/MDHM_Erika voicelines/Day 2/05_That_s it.mp3"
    # e "Okay then. That's it."
    voice "audio/mdhm_erika VoicElines/Day 2/05_That_S it.mp3"
    e "Bien entonces. Eso es todo."

# game/scriptday2.rpy:1256
translate Paloslios scriptday2_85af2ebe_1:

    # "Erika closed the textbook she was currently reading."
    "Erika cerró el libro de texto que estaba leyendo actualmente."

# game/scriptday2.rpy:1258
translate Paloslios scriptday2_d3dbf506:

    # e "I think we should call it off from here."
    e "Creo que deberíamos cancelarlo desde aquí."

# game/scriptday2.rpy:1259
translate Paloslios scriptday2_fa925644_1:

    # "I blinked, a little taken aback by Erika's abrupt leave."
    "Parpadeé, un poco desconcertado por la abrupta clase de Erika."

# game/scriptday2.rpy:1260
translate Paloslios scriptday2_0d005037:

    # u "Erika?"
    u "Erika?"

# game/scriptday2.rpy:1262
translate Paloslios scriptday2_8a238b07_1:

    # e "I can't concentrate like this. We could try to plan out another day to study. Hopefully with no other interruptions."
    e "No puedo concentrarme así. Podríamos tratar de planificar otro día para estudiar. Ojalá sin otras interrupciones."

# game/scriptday2.rpy:1264
translate Paloslios scriptday2_8b12a3a4:

    # "There was a beat of silence as Erika gave Alan a side eye. Alan only drilled holes in her in return."
    "Hubo un ritmo de silencio cuando Erika le dio a Alan un ojo lateral. Alan solo perforó agujeros en ella a cambio."

# game/scriptday2.rpy:1265
translate Paloslios scriptday2_55c289cb_1:

    # "Without a moment to lose, Erika packed everything, but let us keep the snacks she brought."
    "Sin un momento que perder, Erika empacó todo, pero mantengamos los bocadillos que trajo."

# game/scriptday2.rpy:1267
translate Paloslios scriptday2_890e5fb3:

    # e "See ya, around [name]. Later, Stu."
    e "Nos vemos, alrededor de [name]. Más tarde, Stu."

# game/scriptday2.rpy:1268
translate Paloslios scriptday2_fe6d0784:

    # "I watched her leave, feeling a bit defeated."
    "La vi irse, sintiéndome un poco derrotada."

# game/scriptday2.rpy:1272
translate Paloslios scriptday2_44ac8215:

    # s "I guess this is also my cue to leave, huh...?"
    s "Supongo que esta es también mi señal para irse, ¿eh ...?"

# game/scriptday2.rpy:1273
translate Paloslios scriptday2_c0655153:

    # "I looked back to Stu, blades of grass falling from his pants as he patted himself down."
    "Miré de regreso a Stu, hojas de hierba que caían de sus pantalones mientras él se dio una palmada."

# game/scriptday2.rpy:1275
translate Paloslios scriptday2_4e5f2df3:

    # s "Sorry things got out of hand. We could hang out next time when you're free."
    s "Lo siento, las cosas se salieron de control. Podríamos pasar el rato la próxima vez cuando estés libre."

# game/scriptday2.rpy:1276
translate Paloslios scriptday2_9f8d4e53:

    # "Stu gave me a reassuring smile and bid farewell. He didn't even bother to say anything to Alan."
    "Stu me dio una sonrisa tranquilizadora y despedida. Ni siquiera se molestó en decirle nada a Alan."

# game/scriptday2.rpy:1278
translate Paloslios scriptday2_df992147:

    # "I mean, I don't blame him with how things turned out."
    "Quiero decir, no lo culpo por cómo resultaron las cosas."

# game/scriptday2.rpy:1284
translate Paloslios scriptday2_14c4c425:

    # "Well, that was a disaster. I couldn't stop replaying what happened over and over again in my head. Seeing Stu and Erika's faces be so upset and even unsettled. I wanted everyone to get along but-"
    "Bueno, eso fue un desastre. No pude dejar de reproducir lo que sucedió una y otra vez en mi cabeza. Ver los rostros de Stu y Erika estar tan molestos e incluso inquietos. Quería que todos se llevaran bien pero"

# game/scriptday2.rpy:1285
translate Paloslios scriptday2_dd56cf28:

    # a "Doe-eyes...? Are ya mad?"
    a "Doe-Eyes ...? ¿Estás enojado?"

# game/scriptday2.rpy:1286
translate Paloslios scriptday2_67d371c7:

    # "Alan didn't seem to get it."
    "Alan no parecía conseguirlo."

# game/scriptday2.rpy:1291
translate Paloslios scriptday2_5498d955:

    # u "Really? What makes you think that?"
    u "¿En realidad? ¿Qué te hace pensar eso?"

# game/scriptday2.rpy:1296
translate Paloslios scriptday2_b4838b7a:

    # "I snapped at him, rubbing the bridge of my nose in frustration. I just wanted to go home, and here is Alan walking behind me like a lost dog."
    "Le pisé, frotando el puente de mi nariz con frustración. Solo quería ir a casa, y aquí está Alan caminando detrás de mí como un perro perdido."

# game/scriptday2.rpy:1297
translate Paloslios scriptday2_c0d79774:

    # a "I didn't mean to upset ya..."
    a "No quise molestarte ..."

# game/scriptday2.rpy:1298
translate Paloslios scriptday2_8c635db1:

    # u "Oh so upsetting Erika and Stu was with intent, right?"
    u "Oh, molesto, Erika y Stu tenían intención, ¿verdad?"

# game/scriptday2.rpy:1299
translate Paloslios scriptday2_f733075c:

    # "He winced as we both reached the door at the front of my house."
    "Hizo una mueca cuando ambos llegamos a la puerta al frente de mi casa."

# game/scriptday2.rpy:1300
translate Paloslios scriptday2_3c59224a:

    # a "Well, ya did invite me..."
    a "Bueno, me invitaste ..."

# game/scriptday2.rpy:1301
translate Paloslios scriptday2_9b067fef:

    # "He spoke in a mumbling, soft tone. Alan looked down at the ground, anxiously hitting it with the tip of his shoe. His eyes looked at me, like if I just kicked a puppy."
    "Él habló en un tono suave y murmurativo. Alan miró hacia el suelo, golpeándolo ansiosamente con la punta de su zapato. Sus ojos me miraban, como si acabara de patear a un cachorro."

# game/scriptday2.rpy:1302
translate Paloslios scriptday2_09366944:

    # "Ugh... He had a point. I did drag him to the park. But how was I supposed to know he would've pulled a stunt like that? I felt like Erika was beginning to enjoy my company. Stu was there for me after so long."
    "Ugh ... tenía un punto. Lo arrastré al parque. Pero, ¿cómo se suponía que debía saber que habría logrado un truco como ese? Sentí que Erika estaba empezando a disfrutar de mi compañía. Stu estaba allí para mí después de tanto tiempo."

# game/scriptday2.rpy:1303
translate Paloslios scriptday2_575cd979:

    # "Was this whole thing my fault...?"
    "¿Fue todo esto mi culpa ...?"

# game/scriptday2.rpy:1305
translate Paloslios scriptday2_2bd9412e:

    # voice "audio/MDHM_Alan voicelines/Day 2/08_They shouldn_t have left you.mp3"
    # a "They shouldn't have left you..."
    voice "audio/mdhm_alan VoicElines/Day 2/08_They debería haberte dejado.mp3"
    a "No deberían haberte dejado ..."

# game/scriptday2.rpy:1307
translate Paloslios scriptday2_8b258704:

    # u "Huh?"
    u "¿Eh?"

# game/scriptday2.rpy:1308
translate Paloslios scriptday2_3ce6d4c3:

    # voice "audio/MDHM_Alan voicelines/Day 2/09_They left you.mp3"
    # a "They left you. I know I'm not the best to be around other people, but that doesn't mean they can leave ya behind when things get intense."
    voice "audio/mdhm_alan VoicElines/Day 2/09_They te dejó.mp3"
    a "Te dejaron. Sé que no soy el mejor para estar cerca de otras personas, pero eso no significa que puedan dejarte atrás cuando las cosas se vuelven intensas."

# game/scriptday2.rpy:1310
translate Paloslios scriptday2_a20cefa7_15:

    # "..."
    "..."

# game/scriptday2.rpy:1312
translate Paloslios scriptday2_41c4e3a7:

    # a "I didn't."
    a "No lo hice."

# game/scriptday2.rpy:1313
translate Paloslios scriptday2_2940b23f:

    # "I stared at him and as he did so with me. It only hit me that unlike Stu and Erika, he stood by my side. I'm still upset, just a bit less on him."
    "Lo miré y mientras lo hacía conmigo. Solo me golpeó que, a diferencia de Stu y Erika, se paró a mi lado. Todavía estoy molesto, solo un poco menos de él."

# game/scriptday2.rpy:1314
translate Paloslios scriptday2_b07f563f:

    # "I don't know why I didn't expect him, a woodsman all isolated by himself in some cabin, wouldn't get along with other people."
    "No sé por qué no lo esperaba, un leñador, todo aislado por él mismo en una cabaña, no se llevaba bien con otras personas."

# game/scriptday2.rpy:1315
translate Paloslios scriptday2_a20cefa7_16:

    # "..."
    "..."

# game/scriptday2.rpy:1320
translate Paloslios scriptday2_eacc53a3:

    # "Then why is it when I interact with him, he's so easy to talk to?"
    "Entonces, ¿por qué es cuando interactúo con él, es muy fácil hablar?"

# game/scriptday2.rpy:1321
translate Paloslios scriptday2_a20cefa7_17:

    # "..."
    "..."

# game/scriptday2.rpy:1322
translate Paloslios scriptday2_2c34ed1a:

    # "I sighed."
    "Suspiré."

# game/scriptday2.rpy:1323
translate Paloslios scriptday2_be598b2a:

    # a "Mind if I stay?"
    a "¿Te importa si me quedo?"

# game/scriptday2.rpy:1324
translate Paloslios scriptday2_87e77595:

    # u "Whatever."
    u "Lo que sea."

# game/scriptday2.rpy:1332
translate Paloslios scriptday2_14659794:

    # u "I'll be right back, I'm gonna get some extra blankets and a pillow for you."
    u "Volveré, voy a conseguir algunas mantas adicionales y una almohada para ti."

# game/scriptday2.rpy:1334
translate Paloslios scriptday2_22a54f9d:

    # a "Oh! You don't have to, Doe-eyes!"
    a "¡Oh! ¡No tienes que hacerlo, Doe-Eyes!"

# game/scriptday2.rpy:1335
translate Paloslios scriptday2_9d4c23db:

    # u "I can't leave you pillowless, Alan. Besides, I'm kinda cold."
    u "No puedo dejarte sin almohada, Alan. Además, estoy un poco frío."

# game/scriptday2.rpy:1340
translate Paloslios scriptday2_487efdbd:

    # "I quickly ran upstairs to my bedroom, leaving Alan by his lonesome for now. Luckily for him, my bed was swarmed with multiple blankets and pillows. It was like my own little comfortable nest where I could rot away."
    "Rápidamente corrí a mi habitación, dejando a Alan por su solitario por ahora. Afortunadamente para él, mi cama estaba llena de múltiples mantas y almohadas. Era como mi propio pequeño nido cómodo donde podía pudrerme."

# game/scriptday2.rpy:1341
translate Paloslios scriptday2_2a1cee20:

    # "I picked up a decently thick, cozy blanket and a pillow, bundling up in my arms, the corners dragging across the floor as I awkwardly made my way downstairs again."
    "Recogí una manta decentemente gruesa y acogedora y una almohada, que abarca en mis brazos, las esquinas se arrastraban por el piso mientras volvía torpemente hacia abajo nuevamente."

# game/scriptday2.rpy:1342
translate Paloslios scriptday2_d57734db:

    # "I couldn't even see the steps of the stairs with this blanket wrapped around me like some sort of cocoon, but I managed to make it out alive."
    "Ni siquiera podía ver los escalones de las escaleras con esta manta envuelta a mi alrededor como una especie de capullo, pero logré salir con vida."

# game/scriptday2.rpy:1349
translate Paloslios scriptday2_19d66207:

    # "Alan gave me a smile, still sitting on my couch, looking like a dog waiting for its owner."
    "Alan me dio una sonrisa, todavía sentada en mi sofá, luciendo como un perro esperando a su dueño."

# game/scriptday2.rpy:1354
translate Paloslios scriptday2_b93311ce:

    # u "Hey Alan! Think fast!"
    u "¡Hola Alan! ¡Piensa rápido!"

# game/scriptday2.rpy:1355
translate Paloslios scriptday2_91c26057:

    # "I threw my pillow at him, with all the force I've got. I expected him to be caught off guard, and watch him be hit on the face."
    "Le arrojé mi almohada, con toda la fuerza que tengo. Esperaba que fuera atrapado desprevenido y lo viera a ser golpeado en la cara."

# game/scriptday2.rpy:1358
translate Paloslios scriptday2_14ad8281:

    # "However, to my shock, he quickly caught the pillow with his hand. A soft hit sound could be heard from his palm. Alan simply gave me a smile after placing the pillow on his lap."
    "Sin embargo, para mi sorpresa, rápidamente atrapó la almohada con la mano. Se escuchó un sonido suave de su palma. Alan simplemente me dio una sonrisa después de colocar la almohada en su regazo."

# game/scriptday2.rpy:1360
translate Paloslios scriptday2_bb27f140:

    # a "Thank you, Doe."
    a "Gracias, Doe."

# game/scriptday2.rpy:1361
translate Paloslios scriptday2_dc5dfe41:

    # "He said cheekily, sticking his tongue out."
    "Dijo descaradamente, sacando la lengua."

# game/scriptday2.rpy:1362
translate Paloslios scriptday2_73e68693:

    # u "Booooo!"
    u "¡Booooo!"

# game/scriptday2.rpy:1365
translate Paloslios scriptday2_40b3678a:

    # "I decided to be nice, walking over to him and simply handed him the pillow. He gladly took it off my hands and placed it on his lap."
    "Decidí ser amable, caminar hacia él y simplemente le entregué la almohada. Con mucho gusto me lo quitó las manos y lo colocó en su regazo."

# game/scriptday2.rpy:1367
translate Paloslios scriptday2_bb02c42d:

    # "I plopped myself beside him on the couch, throwing the blanket across the couch. It slowly landed on both me and Alan, taking its warmth."
    "Me dejé caer a su lado en el sofá, arrojando la manta a través del sofá. Lentamente aterrizó tanto en Alan como en Alan, tomando su calidez."

# game/scriptday2.rpy:1368
translate Paloslios scriptday2_d60a907c:

    # "Now it was just us. Opposite sides of the couch, in the cozy glow from the TV. In silence."
    "Ahora solo éramos nosotros. Lados opuestos del sofá, en el acogedor brillo de la televisión. En silencio."

# game/scriptday2.rpy:1369
translate Paloslios scriptday2_a20cefa7_18:

    # "..."
    "..."

# game/scriptday2.rpy:1370
translate Paloslios scriptday2_402ba2b6:

    # "Yeah. Just us."
    "Sí. Solo nosotros."

# game/scriptday2.rpy:1378
translate Paloslios scriptday2_a20cefa7_19:

    # "..."
    "..."

# game/scriptday2.rpy:1379
translate Paloslios scriptday2_0fd4d656:

    # "......"
    "......"

# game/scriptday2.rpy:1380
translate Paloslios scriptday2_c383f876:

    # a "Hey."
    a "Ey."

# game/scriptday2.rpy:1381
translate Paloslios scriptday2_8686e81c:

    # u "Hey."
    u "Ey."

# game/scriptday2.rpy:1382
translate Paloslios scriptday2_d3db5e03:

    # "I smiled warmly at him, but there was this dreadful awkward silence between us. My eyes wandered off, panicking on what to say next."
    "Le sonreí calurosamente, pero había este terrible silencio incómodo entre nosotros. Mis ojos se alejaron, en pánico en qué decir a continuación."

# game/scriptday2.rpy:1383
translate Paloslios scriptday2_bbb3b39c:

    # a "It's been a while since I've watched some TV."
    a "Ha pasado un tiempo desde que vi algo de televisión."

# game/scriptday2.rpy:1384
translate Paloslios scriptday2_e49be2d5:

    # "Thankfully, Alan brought up a topic."
    "Afortunadamente, Alan presentó un tema."

# game/scriptday2.rpy:1385
translate Paloslios scriptday2_de31d73e:

    # u "Same. I haven't sat down in my living room and watched something in a while."
    u "Mismo. No me he sentado en mi sala de estar y he visto algo en mucho tiempo."

# game/scriptday2.rpy:1390
translate Paloslios scriptday2_e57a1903:

    # "I heard some shuffling from the couch. He was getting closer."
    "Escuché algunos arrastrando el sofá. Se estaba acercando."

# game/scriptday2.rpy:1391
translate Paloslios scriptday2_0c035d26:

    # u "Ya know... Haha. We're kinda having a Netflix & Chill session."
    u "Ya sabes ... jaja. Estamos teniendo una sesión de Netflix & Chill."

# game/scriptday2.rpy:1392
translate Paloslios scriptday2_ca8bb5c4:

    # "I nervously laughed, scratching the side of my cheek."
    "Me reí nerviosamente, rascando el costado de mi mejilla."

# game/scriptday2.rpy:1394
translate Paloslios scriptday2_1a6bdc6f:

    # a "What's that?"
    a "¿Qué es eso?"

# game/scriptday2.rpy:1395
translate Paloslios scriptday2_a77a6a3d:

    # "Alan looked at me with those big, confused eyes of his."
    "Alan me miró con esos grandes y confundidos ojos suyos."

# game/scriptday2.rpy:1396
translate Paloslios scriptday2_6a0ecb65:

    # u "You... Don't know?"
    u "Tu ... no lo sabes?"

# game/scriptday2.rpy:1397
translate Paloslios scriptday2_45ffbf30:

    # "Alan shook his head, leaving me dumbfounded. I guess that makes some sense? He lives out in the woods, he wasn't exactly someone I would take to understand modern slang but he must have some knowledge? Right?"
    "Alan sacudió la cabeza, dejándome estupefacto. ¿Supongo que eso tiene sentido? Vive en el bosque, no era exactamente alguien a quien tomaría para entender la jerga moderna, pero ¿debe tener algún conocimiento? ¿Bien?"

# game/scriptday2.rpy:1398
translate Paloslios scriptday2_c80fc8d5:

    # "God, now I have to explain what that means."
    "Dios, ahora tengo que explicar lo que eso significa."

# game/scriptday2.rpy:1399
translate Paloslios scriptday2_e388022f:

    # u "W-Well... Um it's like a thing people do... It's sorta a casual date or hook-up thing, ya know?"
    u "Bu-Bueno ... Um es como algo que la gente hace ... es una cita informal o una conexión de conexión, ¿sabes?"

# game/scriptday2.rpy:1400
translate Paloslios scriptday2_e059953a:

    # "That was a terrible explanation, [name]."
    "Esa fue una explicación terrible, [name]."

# game/scriptday2.rpy:1402
translate Paloslios scriptday2_2e1ea808:

    # a "So do you want to call this a date? I mean, it's on the casual side like you said. If it's too casual or something we can just say we're hanging out..."
    a "Entonces, ¿quieres llamar a esto una cita? Quiero decir, está en el lado informal como dijiste. Si es demasiado informal o algo que podemos decir que estamos pasando el rato ..."

# game/scriptday2.rpy:1403
translate Paloslios scriptday2_d1bf6649:

    # "I could only look at him, too stunned to speak but I sense he was waiting for a response. For me to hint at something... More."
    "Solo podía mirarlo, demasiado aturdido para hablar, pero siento que estaba esperando una respuesta. Para que yo insinúe algo ... más."

# game/scriptday2.rpy:1404
translate Paloslios scriptday2_6d3cbbcc:

    # u "I don't know... It's hard to tell."
    u "No sé ... es difícil saberlo."

# game/scriptday2.rpy:1405
translate Paloslios scriptday2_a2eccb1b:

    # "Alan tilted his head to the side like a confused dog. He had his whole focus on me, he shifted closer."
    "Alan inclinó la cabeza hacia un lado como un perro confundido. Tenía todo su enfoque en mí, se acercó."

# game/scriptday2.rpy:1406
translate Paloslios scriptday2_45952885:

    # a "Well, think about it."
    a "Bueno, piénsalo."

# game/scriptday2.rpy:1407
translate Paloslios scriptday2_63ea1b18:

    # "I gave it some thought, huddling my legs together. I was hesitant to answer, what could I even say to him? I wasn't even sure how to feel about this situation. Alan just walked into my life and he was just kinda..."
    "Lo pensé un poco, acurrucando mis piernas juntas. Dudaba en responder, ¿qué podría decirle? Ni siquiera estaba seguro de cómo sentir sobre esta situación. Alan acaba de entrar en mi vida y él era un poco ..."

# game/scriptday2.rpy:1408
translate Paloslios scriptday2_fc14bf3b:

    # "Here now."
    "Aquí ahora."

# game/scriptday2.rpy:1409
translate Paloslios scriptday2_7f5b667a:

    # "Like a pesky stray following me around and refusing to leave."
    "Como una molestia que me sigue y se niega a irse."

# game/scriptday2.rpy:1410
translate Paloslios scriptday2_ce8f172e:

    # "I occasionally looked back to Alan, those hopeful, puppy-like eyes staring back at me."
    "De vez en cuando volví a mirar a Alan, esos ojos esperanzados y como cachorros que me miraban."

# game/scriptday2.rpy:1411
translate Paloslios scriptday2_d8c6ccfa:

    # u "I can't put my finger on it. It gets hard to befriend people as you get older, especially when you don't have a group to back you up."
    u "No puedo decirle mi dedo. Se hace difícil hacerse amigo de la gente a medida que envejeces, especialmente cuando no tienes un grupo para respaldarte."

# game/scriptday2.rpy:1412
translate Paloslios scriptday2_a41e11e0:

    # "As I spoke, I didn't face him, my eyes stayed glued to the ground, piecing together whatever my mind thought of."
    "Mientras hablaba, no lo enfrenté, mis ojos se mantuvieron pegados al suelo, juntando lo que mi mente pensara."

# game/scriptday2.rpy:1413
translate Paloslios scriptday2_17f38741:

    # u "But having someone like you immediately click feels freeing."
    u "Pero tener a alguien como usted hace clic inmediatamente se siente liberador."

# game/scriptday2.rpy:1418
translate Paloslios scriptday2_f6d71853:

    # "There was a beat of silence before I felt some weight shifting on the other side. Next thing I knew, I was being pushed down to my back, Alan slowly creeping towards me."
    "Hubo un ritmo de silencio antes de sentir algo de peso cambiando al otro lado. Lo siguiente que supe es que estaba siendo empujado hacia mi espalda, Alan se arrastraba lentamente hacia mí."

# game/scriptday2.rpy:1420
translate Paloslios scriptday2_afbfe0db:

    # a "Then... That's a good thing, right?"
    a "Entonces ... eso es algo bueno, ¿verdad?"

# game/scriptday2.rpy:1421
translate Paloslios scriptday2_358a8aae:

    # "He had me cornered, the most I could do was just to lie there, stunned."
    "Me tenía acorralado, lo máximo que pude hacer era acostarse allí, aturdido."

# game/scriptday2.rpy:1428
translate Paloslios scriptday2_9384b50a:

    # voice "audio/MDHM_Alan voicelines/Day 2/11_Get rid of everything.mp3"
    # a "I could get rid of everything for you, Doe. If you let me."
    voice "audio/mdhm_alan VoicElines/Day 2/11_get Rid of Everything.mp3"
    a "Podría deshacerme de todo para ti, Doe. Si me dejas."

# game/scriptday2.rpy:1430
translate Paloslios scriptday2_80d270aa:

    # "I swallowed nervously. I couldn't speak, like something was stuck in my throat. His eyes pierced mine. It was almost uncanny that I couldn't guess what he was thinking. What should I even say?"
    "Me tragué nerviosamente. No podía hablar, como si algo estuviera atascado en mi garganta. Sus ojos perforaron los míos. Era casi extraño que no podía adivinar lo que estaba pensando. ¿Qué debo decir?"

# game/scriptday2.rpy:1431
translate Paloslios scriptday2_e92d5283:

    # "It felt like an eternity of nothing but silence, and my heart beating like a drum. I wanted to stay quiet, as if silence would take me out of this situation."
    "Se sintió como una eternidad de nada más que silencio, y mi corazón latía como un tambor. Quería quedarme callado, como si el silencio me sacara de esta situación."

# game/scriptday2.rpy:1432
translate Paloslios scriptday2_03388ef8:

    # a "Well...?"
    a "Bien...?"

# game/scriptday2.rpy:1433
translate Paloslios scriptday2_956b6507:

    # "But Alan is not letting go without an answer."
    "Pero Alan no está dejando ir sin una respuesta."

# game/scriptday2.rpy:1438
translate Paloslios scriptday2_ec7db9b6:

    # "My mouth felt like it was wired shut."
    "Mi boca se sentía como si estuviera cerrada."

# game/scriptday2.rpy:1439
translate Paloslios scriptday2_9daf6117:

    # voice "audio/MDHM_Alan voicelines/Day 2/12_Answer it for ya.mp3"
    # a "'Guess I'll answer it for ya."
    voice "audio/mdhm_alan VoicElines/Day 2/12_answer It for Ya.mp3"
    a "Supongo que lo responderé por ti."

# game/scriptday2.rpy:1441
translate Paloslios scriptday2_f4f6ed0c:

    # "I felt Alan's hand slowly snake its way at the back of my head, brushing his fingers through my hair. "
    "Sentí que la mano de Alan se abrió paso lentamente en la parte posterior de mi cabeza, cepillándome los dedos por mi cabello. "

# game/scriptday2.rpy:1442
translate Paloslios scriptday2_422acb60:

    # "He then closed the gap between us. His lips stealing a kiss."
    "Luego cerró la brecha entre nosotros. Sus labios roban un beso."

# game/scriptday2.rpy:1445
translate Paloslios scriptday2_800edc97:

    # u "Maybe I would like that. Maybe I like you..."
    u "Tal vez me gustaría eso. Quizás me gustes ..."

# game/scriptday2.rpy:1446
translate Paloslios scriptday2_7c1e635a:

    # "Alan huffed out a short, breathy laugh."
    "Alan resopló una risa corta y respirable."

# game/scriptday2.rpy:1447
translate Paloslios scriptday2_729af2a1:

    # voice "audio/MDHM_Alan voicelines/Day 2/13_What i wanted to hear.mp3"
    # a "That's what I wanted to hear."
    voice "audio/mdhm_alan VoicElines/Day 2/13_ lo que quería escuchar.mp3"
    a "Eso es lo que quería escuchar."

# game/scriptday2.rpy:1449
translate Paloslios scriptday2_95b4a9f3:

    # "I felt his calloused hands reach for my face and he leaned in. Sealing both of us into a kiss."
    "Sentí que sus manos insensibles alcanzaron mi cara y se inclinó. Sellándonos a los dos en un beso."

# game/scriptday2.rpy:1452
translate Paloslios scriptday2_91fec498:

    # u "I don't know. Surprise me."
    u "No sé. Sorpréntame."

# game/scriptday2.rpy:1453
translate Paloslios scriptday2_6093fc36:

    # "He hummed."
    "Él tarareó."

# game/scriptday2.rpy:1454
translate Paloslios scriptday2_1803c794:

    # voice "audio/MDHM_Alan voicelines/Day 2/14_With pleasure.mp3"
    # a "With pleasure, Doe-eyes."
    voice "audio/mdhm_alan VoicElines/Day 2/14_With Pleasure.mp3"
    a "Con placer, Doe-Eyes."

# game/scriptday2.rpy:1456
translate Paloslios scriptday2_e0d4f503:

    # "Swiftly, Alan took a hold of my legs and pulled me closer to him, letting himself be entrapped between my legs. He dove straight onto my mouth, hungry for a kiss."
    "Rápidamente, Alan se apoderó de mis piernas y me acercó a él, dejándose ser atrapado entre mis piernas. Se zambulló directamente sobre mi boca, hambriento de un beso."

# game/scriptday2.rpy:1458
translate Paloslios scriptday2_a5fbfa51:

    # "It was desperate and needy, Alan clung to me like his life depended on it and I didn't try to pull away. I couldn't help but find it intoxicating."
    "Era desesperado y necesitado, Alan se aferró a mí como si su vida dependiera de ello y no intenté alejarme. No pude evitar encontrarlo intoxicante."

# game/scriptday2.rpy:1459
translate Paloslios scriptday2_2b4cb1c3:

    # "I can barely breathe-"
    "Apenas puedo respirar"

# game/scriptday2.rpy:1460
translate Paloslios scriptday2_1c09991d:

    # u "Alan-"
    u "Alan-"

# game/scriptday2.rpy:1461
translate Paloslios scriptday2_2bfceda5:

    # "I gasped out to breathe some air, leaving Alan breathing heavily and looking at me. Those eyes gawking at me like fresh meat, starved."
    "Jadeé para respirar un poco de aire, dejando a Alan respirando mucho y mirándome. Esos ojos me miran como carne fresca, hambrientada."

# game/scriptday2.rpy:1462
translate Paloslios scriptday2_33092f81:

    # "Immediately Alan attacked the crook of my neck. Peppering kisses and nibbling at my sensitive skin."
    "Inmediatamente, Alan atacó el ladrón de mi cuello. Besos salpicantes y mordisqueos en mi piel sensible."

# game/scriptday2.rpy:1463
translate Paloslios scriptday2_2019f6df:

    # "Then he bit down."
    "Luego se mordió."

# game/scriptday2.rpy:1464
translate Paloslios scriptday2_c97bbd44:

    # u "W-Wait! I know it's not the most romantic setting, but are we really doing this?"
    u "¡Q-QUE?! Sé que no es el entorno más romántico, pero ¿realmente estamos haciendo esto?"

# game/scriptday2.rpy:1465
translate Paloslios scriptday2_daf7b4b5:

    # a "Do you want to?"
    a "¿Quieres?"

# game/scriptday2.rpy:1466
translate Paloslios scriptday2_a20cefa7_20:

    # "..."
    "..."

# game/scriptday2.rpy:1470
translate Paloslios scriptday2_e7f02402:

    # u "Can we maybe... not?"
    u "¿Podemos tal vez ... no?"

# game/scriptday2.rpy:1471
translate Paloslios scriptday2_74cbe7b0:

    # "Alan's eyes softened before peeling them away from me."
    "Los ojos de Alan se suavizaron antes de despegarlos de mí."

# game/scriptday2.rpy:1472
translate Paloslios scriptday2_8d933134:

    # a "Yeah-! Um sorry. We can stop."
    a "Sí-! Um lo siento. Podemos parar."

# game/scriptday2.rpy:1473
translate Paloslios scriptday2_22c28b26:

    # "Alan pulled himself away from me, letting me sit up on the couch normally."
    "Alan se alejó de mí, dejándome sentarme en el sofá normalmente."

# game/scriptday2.rpy:1481
translate Paloslios scriptday2_3d7141bd:

    # a "I might have gotten a lil' carried away there..."
    a "Podría haber dejado llevar a un lil allí ..."

# game/scriptday2.rpy:1482
translate Paloslios scriptday2_1ab0c249:

    # "His voice sounded almost pained and disappointed. I awkwardly rubbed my arm and shifted uncomfortably."
    "Su voz sonaba casi dolida y decepcionada. Froté incómodamente mi brazo y me moví incómodo."

# game/scriptday2.rpy:1483
translate Paloslios scriptday2_a0031798:

    # "Alan finally looked at me, his eyes widening with a puppy-like stare. I couldn't help but feel a little bad for him. I should at least make it up to him, right?"
    "Alan finalmente me miró, sus ojos se abrieron con una mirada parecida a un cachorro. No pude evitar sentirme un poco mal por él. Al menos debería invitarlo, ¿verdad?"

# game/scriptday2.rpy:1484
translate Paloslios scriptday2_7e1b65a3:

    # u "Let's just take things slow, okay? Here."
    u "Vamos a tomar las cosas con calma, ¿de acuerdo? Aquí."

# game/scriptday2.rpy:1488
translate Paloslios scriptday2_fbbec1e0:

    # "I softly patted the cushion next to me, to get him to move closer. Alan looked a little hesitant but he followed suit, scooching over."
    "Leí suavemente el cojín a mi lado, para que se acercara. Alan parecía un poco vacilante, pero siguió su ejemplo, rasgando."

# game/scriptday2.rpy:1489
translate Paloslios scriptday2_b9c0f43a:

    # "I laid my head on his shoulder, it was a little awkward but I soon warmed up to it."
    "Puse mi cabeza sobre su hombro, fue un poco incómodo, pero pronto me calenté."

# game/scriptday2.rpy:1490
translate Paloslios scriptday2_cb44eb25:

    # u "Comfy?"
    u "¿Confortable?"

# game/scriptday2.rpy:1492
translate Paloslios scriptday2_0ac06e0d:

    # "Alan nodded and we both sat in peaceful silence again. The TV softly drowned out our surroundings and my eyes began to grow heavy."
    "Alan asintió y ambos nos sentamos en silencio pacífico nuevamente. La televisión ahogó suavemente nuestro entorno y mis ojos comenzaron a crecer pesados."

# game/scriptday2.rpy:1496
translate Paloslios scriptday2_49ecc69e:

    # "END OF DAY 2"
    "Fin del día 2"

# game/scriptday2.rpy:1500
translate Paloslios scriptday2_4e578130:

    # "I straightened my posture and softly patted my lap. Alan looked a little hesitant but he followed suit, like a good dog."
    "Enderezé mi postura y le dio unas palmaditas suaves a mi regazo. Alan parecía un poco vacilante, pero siguió su ejemplo, como un buen perro."

# game/scriptday2.rpy:1501
translate Paloslios scriptday2_b850040a:

    # "He rested his head on my legs and I slowly stroked his hair. It was a little awkward but we both warmed up to it."
    "Descansó la cabeza sobre mis piernas y lentamente me acaricié el cabello. Era un poco incómodo, pero ambos nos calentamos."

# game/scriptday2.rpy:1502
translate Paloslios scriptday2_cb44eb25_1:

    # u "Comfy?"
    u "¿Confortable?"

# game/scriptday2.rpy:1504
translate Paloslios scriptday2_0ac06e0d_1:

    # "Alan nodded and we both sat in peaceful silence again. The TV softly drowned out our surroundings and my eyes began to grow heavy."
    "Alan asintió y ambos nos sentamos en silencio pacífico nuevamente. La televisión ahogó suavemente nuestro entorno y mis ojos comenzaron a crecer pesados."

# game/scriptday2.rpy:1508
translate Paloslios scriptday2_49ecc69e_1:

    # "END OF DAY 2"
    "Fin del día 2"

# game/scriptday2.rpy:1512
translate Paloslios scriptday2_09dd868c:

    # u "Yeah. I do."
    u "Sí. Sí."

# game/scriptday2.rpy:1513
translate Paloslios scriptday2_a63c4b4a:

    # "A devilish smirk appeared on Alan's face."
    "Una sonrisa diabólica apareció en la cara de Alan."

# game/scriptday2.rpy:1514
translate Paloslios scriptday2_2690e1ce:

    # a "What a good Doe..."
    a "Qué buena cierva ..."

# game/scriptday2.rpy:1515
translate Paloslios scriptday2_3adafe55:

    # "He went for the same spot on my neck as before, to properly leave a mark on me this time. I felt a sting of pain as Alan sank his teeth. It wasn't deep enough to puncture skin, but enough to leave an impression."
    "Fue por el mismo lugar en mi cuello que antes, para dejarme una marca adecuada esta vez. Sentí un aguijón de dolor cuando Alan hundió los dientes. No era lo suficientemente profundo como para perforar la piel, pero lo suficiente como para dejar una impresión."

# game/scriptday2.rpy:1516
translate Paloslios scriptday2_a357fbf5:

    # "His head slowly dove further down. From my neck, to my chest and then to my stomach."
    "Su cabeza lentamente se zambulló más abajo. Desde mi cuello, hasta mi pecho y luego hasta mi estómago."

# game/scriptday2.rpy:1521
translate Paloslios scriptday2_ac95ca1b:

    # "Alan struggled a bit to get my clothing off, leaving my legs bare and vulnerable to the cold."
    "Alan luchó un poco para quitarse la ropa, dejando mis piernas desnudas y vulnerables al frío."

# game/scriptday2.rpy:1526
translate Paloslios scriptday2_e8b6414f:

    # voice "audio/MDHM_Alan voicelines/Day 2/15_Ya know.mp3"
    # a "Ya know, I could get used to this view."
    voice "audio/mdhm_alan VoicElines/Day 2/15_ya Know.mp3"
    a "Ya sabes, podría acostumbrarme a esta vista."

# game/scriptday2.rpy:1528
translate Paloslios scriptday2_83c9d917:

    # "Alan settled between my legs, both of his needy hands up for grabs on each thigh."
    "Alan se estableció entre mis piernas, sus dos manos necesitadas para agarrar en cada muslo."

# game/scriptday2.rpy:1529
translate Paloslios scriptday2_885e4f5a:

    # u "You would like that, wouldn't you?"
    u "Te gustaría eso, ¿no?"

# game/scriptday2.rpy:1534
translate Paloslios scriptday2_8063ca6c:

    # "Alan let out a soft giggle, rubbing his cheek against my thigh."
    "Alan dejó escapar una suave risita, frotando su mejilla contra mi muslo."

# game/scriptday2.rpy:1535
translate Paloslios scriptday2_85fafe20:

    # a "Can you blame me?"
    a "¿Puedes culparme?"

# game/scriptday2.rpy:1536
translate Paloslios scriptday2_415a5e20:

    # "I simply rolled my eyes, letting him indulge himself as he pleased. However, I couldn't deny that seeing him between my inner thighs was about the most tantalizing thing anyone has ever done to me."
    "Simplemente puse los ojos en blanco, dejándolo disfrutar de lo que quisiera. Sin embargo, no podía negar que verlo entre mis muslos internos era sobre lo más tentador que alguien me ha hecho."

# game/scriptday2.rpy:1541
translate Paloslios scriptday2_5f1c6433:

    # "My body jolted at the sharp sting again. However, this was more than welcomed. I couldn't help but moan a little, encouraging Alan to go further. My body started to grow hot."
    "Mi cuerpo se sacudió en el aguijón afilado nuevamente. Sin embargo, esto fue más que bienvenido. No pude evitar gemir un poco, alentando a Alan a ir más allá. Mi cuerpo comenzó a calentarse."

# game/scriptday2.rpy:1542
translate Paloslios scriptday2_4a3731bd:

    # a "'Nother one here..."
    a "'No hay uno aquí ..."

# game/scriptday2.rpy:1543
translate Paloslios scriptday2_70042924:

    # "Alan mumbled to himself, marking up my thighs with hickeys, hungrily searching for any missed spots. This time he wasn't holding back."
    "Alan murmuró para sí mismo, marcando mis muslos con hicetes, buscando hambrientos de lugares perdidos. Esta vez no estaba conteniendo."

# game/scriptday2.rpy:1544
translate Paloslios scriptday2_913bbf7b:

    # u "Alan... C-Can you- Ow!"
    u "Alan... ¿P-Puedes...? ¡Ay!"

# game/scriptday2.rpy:1545
translate Paloslios scriptday2_05de7cac:

    # "That one hurt. He sank his teeth in more and more. I could see Alan's eyes peering over to me, trying to see my reaction."
    "Ese duele. Hundió sus dientes en cada vez más. Pude ver los ojos de Alan mirándome, tratando de ver mi reacción."

# game/scriptday2.rpy:1546
translate Paloslios scriptday2_b3377b14:

    # "He let out a satisfied chuckle as I felt something warm pooling around that certain area he just bit."
    "Él dejó escapar una risita satisfecha cuando sentí algo cálido acumulando esa cierta área en la que solo mordió."

# game/scriptday2.rpy:1547
translate Paloslios scriptday2_09089fff:

    # "Then his tongue licked it. Wiping it clean."
    "Entonces su lengua lo lamió. Limpiándolo limpio."

# game/scriptday2.rpy:1548
translate Paloslios scriptday2_b58672ae:

    # u "D-Did... Did you just draw blood?"
    u "T-tu ... ¿Acabas de extraer sangre?"

# game/scriptday2.rpy:1551
translate Paloslios scriptday2_0c95a1d9:

    # voice "audio/MDHM_Alan voicelines/Noises/Happy/Alan_Laugh.mp3"
    # "He looked far too pleased with himself. Before I could get another word out. I felt something hot and wet licking me. It felt like I was melting on his tongue."
    voice "audio/mdhm_alan VoicElines/ruidos/happy/alan_laugh.mp3"
    "Parecía demasiado satisfecho consigo mismo. Antes de que pudiera dar una palabra más. Sentí algo caliente y mojado lamiéndome. Se sentía como si estuviera derritiéndose en su lengua."

# game/scriptday2.rpy:1554
translate Paloslios scriptday2_d392179c:

    # u "Good boys don't bite too hard..."
    u "Los buenos chicos no muerden demasiado ..."

# game/scriptday2.rpy:1555
translate Paloslios scriptday2_adf6dfbe:

    # "I yanked on Alan's hair on impulse, hitching my breath. That seemed to get a reaction from him."
    "Tiré sobre el cabello de Alan en el impulso, enganchando mi aliento. Eso pareció recibir una reacción de él."

# game/scriptday2.rpy:1556
translate Paloslios scriptday2_a2084beb:

    # u "Oh Sorry."
    u "Oh, lo siento."

# game/scriptday2.rpy:1557
translate Paloslios scriptday2_54844cbf:

    # a "No, you can do it again. Actually..."
    a "No, puedes hacerlo de nuevo. De hecho..."

# game/scriptday2.rpy:1558
translate Paloslios scriptday2_4208fe2f:

    # a "Could you pull a bit harder this time?"
    a "¿Podrías tirar un poco más fuerte esta vez?"

# game/scriptday2.rpy:1559
translate Paloslios scriptday2_94004a03_2:

    # "Oh."
    "Oh."

# game/scriptday2.rpy:1560
translate Paloslios scriptday2_a8966b91:

    # u "Yeah-"
    u "Sí-"

# game/scriptday2.rpy:1561
translate Paloslios scriptday2_e70c2906:

    # "Alan continued to let his tongue do wonders, I gave his hair a second tug, a lot harder like he requested. The living room filled up with a chorus of moans and groans."
    "Alan continuó dejando que su lengua hiciera maravillas, le di un segundo tirón, mucho más duro como él solicitó. La sala de estar llena con un coro de gemidos y gemidos."

# game/scriptday2.rpy:1562
translate Paloslios scriptday2_365ee942:

    # voice "audio/MDHM_Alan voicelines/Day 2/16_So Happy.mp3"
    # a "You sound so happy... I hope I'm doing a good job?"
    voice "audio/mdhm_alan VoicElines/Day 2/16_so Happy.mp3"
    a "Suenas tan feliz ... Espero estar haciendo un buen trabajo."

# game/scriptday2.rpy:1564
translate Paloslios scriptday2_901e52ff:

    # u "You're doing so good. You'll be great if you keep your mouth there until I say otherwise."
    u "Lo estás haciendo bien. Serás genial si mantienes tu boca allí hasta que diga lo contrario."

# game/scriptday2.rpy:1565
translate Paloslios scriptday2_bcb84fc0:

    # "I could tell that got a rise out of Alan. He lapped up like a hungry dog eating its last meal. He was going faster, each flick or swirl of his tongue caused my mind to feel dizzy."
    "Me di cuenta de que obtuvo un aumento de Alan. Se lamió como un perro hambriento comiendo su última comida. Iba más rápido, cada película o giratorio de su lengua hizo que mi mente se sintiera mareado."

# game/scriptday2.rpy:1566
translate Paloslios scriptday2_4c3eed1a:

    # u "A-Al... Wait-!"
    u "A-Al ... ¡Espera-!"

# game/scriptday2.rpy:1567
translate Paloslios scriptday2_98a353bf:

    # "My begging fell on deaf ears, then again, I was starting to become a mumbling mess, with Alan not even giving time to process."
    "Mi mendicidad cayó en oídos sordos, de nuevo, estaba empezando a convertirme en un desastre murmurado, ya que Alan ni siquiera dio tiempo para procesar."

# game/scriptday2.rpy:1568
translate Paloslios scriptday2_03518d52:

    # "My mind went blank, a wave of pleasure crushing me under its weight and my body left quivering. "
    "Mi mente se quedó en blanco, una ola de placer aplastándome bajo su peso y mi cuerpo se fue temblando. "

# game/scriptday2.rpy:1569
translate Paloslios scriptday2_f4c36689:

    # "Alan gave one last, long lap. Savoring every drop before licking his lips."
    "Alan dio una última vuelta larga. Saboreando cada gota antes de lamerse los labios."

# game/scriptday2.rpy:1570
translate Paloslios scriptday2_4b03ea05:

    # a "Tastes so good..."
    a "Sabe tan bien ..."

# game/scriptday2.rpy:1571
translate Paloslios scriptday2_2ef058ab:

    # "I breathed heavily, Alan got on top of me. He licked his lips seductively, a satisfied smirk permanent on his face."
    "Respiré mucho, Alan se puso encima de mí. Se lamió los labios seductoramente, una sonrisa satisfecha permanente en su rostro."

# game/scriptday2.rpy:1572
translate Paloslios scriptday2_ede73d2f:

    # a "Someone looks pretty happy. You have experience with this kind of stuff? Maybe you can guide me through the whole thing?"
    a "Alguien se ve muy feliz. ¿Tienes experiencia con este tipo de cosas? ¿Quizás puedas guiarme a través de todo el asunto?"

# game/scriptday2.rpy:1573
translate Paloslios scriptday2_5dc8de7c:

    # u "Maybe next time, Alan but..."
    u "Tal vez la próxima vez, Alan pero ..."

# game/scriptday2.rpy:1574
translate Paloslios scriptday2_36243c90:

    # "I let out a yawn."
    "Dejé escapar un bostezo."

# game/scriptday2.rpy:1575
translate Paloslios scriptday2_3b151dfd:

    # u "Thanks... I really needed that actually."
    u "Gracias ... realmente necesitaba eso en realidad."

# game/scriptday2.rpy:1576
translate Paloslios scriptday2_e0f23588:

    # "We both sat in peaceful silence again. The TV softly drowned out our surroundings and my eyes began to grow heavy. I felt soft kisses to my jaw trailing up to my cheek."
    "Ambos nos sentamos en silencio pacífico nuevamente. La televisión ahogó suavemente nuestro entorno y mis ojos comenzaron a crecer pesados. Sentí suaves besos a mi mandíbula hasta mi mejilla."

# game/scriptday2.rpy:1577
translate Paloslios scriptday2_7e94060d:

    # voice "audio/MDHM_Alan voicelines/Day 2/17_ Looking forward.mp3"
    # a "I'm looking forward to 'next time'. G'night, Doe-Eyes..."
    voice "audio/mdhm_alan VoicElines/Day 2/17_ Mirando hacia adelante.mp3"
    a "Estoy deseando que llegue 'la próxima vez'. G'night, Doe-Eyes ..."

# game/scriptday2.rpy:1581
translate Paloslios scriptday2_49ecc69e_2:

    # "END OF DAY 2"
    "Fin del día 2"

